/**
 * The kernel: the modules installed on a desktop, in layers; the journal of
 * every change a person made, with undo and a recovery boot; and the one bus
 * between modules — contract operations, checked against grants and written
 * to a ledger. It holds no DOM and no key, so it runs and is tested in Node.
 */
import { applyJSONPatch, createJSONPatch } from '@jarenjs/json/patch';
import { cloneJson } from '@jarenjs/core/object';
import { compileContract } from '@jarenjs/contract';
import { servePortLazily, openPortClientLazily } from "./ports.js";
import { openLocalClient } from '@jarenjs/contract/local';
import { validateManifest } from "./manifest.js";
import { JarenValidator } from '@jarenjs/validate';
import { systemContracts, PROPOSAL_SCHEMA } from "./contracts.js";
import { HEADER_CONTRACT, HEADER_SCHEMA, activateHeader, duplicateHeaderId, headerFor } from "./header.js";
import { DOCK_SCHEMA, arrangeDock, dockChanges, dockIcons, folderTitles, normalizeDock } from "./dock.js";
import { STATE_CONTRACT, contractStore, memoryStore } from "./state.js";
import { fileAnswer, fileBase64ToBytes } from "./files.js";
import { CAPABILITY_SCHEMA, capabilityIssues } from "./capability.js";
import { APPS_KEY, consentNeeded, originOf, scopesOf } from "./consent.js";
/** The ids no module may take: the shell's own hand, the person, and the desktop that files its own proposals. */
export const RESERVED_IDS = ['shell', 'person', 'desktop'];
/** How much of a text file the assistant reads at once: tool results are cut at 8,000 characters. */
const ASSISTANT_TEXT = 6000;
const LOCATION = { type: 'string', pattern: '^[A-Za-z_][A-Za-z0-9_-]*$' };
/**
 * `tangle_os_files`: the kernel's own contract over every file location, for
 * the assistant. It lists, searches and reads (text, capped; a binary file as
 * its description), and never writes, moves or deletes; a location marked
 * `assistant: false` is not in it.
 */
export const FILES_CONTRACT = {
    $contract: '0.1',
    id: 'tangle_os_files',
    operations: {
        'files.locations': { kind: 'read', doc: 'The file locations: each application\'s files, and the person\'s own.', input: { type: 'object', additionalProperties: false, properties: {} }, output: { type: 'object' } },
        'files.list': {
            kind: 'read', doc: 'The files and folders in one folder of a location (no folder for its top), a page at a time.',
            input: { type: 'object', additionalProperties: false, required: ['location'], properties: { location: LOCATION, folder: { anyOf: [{ type: 'string', maxLength: 1024 }, { type: 'null' }] }, cursor: { type: 'string', maxLength: 1024 } } },
            output: { type: 'object' },
        },
        'files.search': {
            kind: 'read', doc: 'Files and folders whose name contains the query, in one location or in all of them.',
            input: { type: 'object', additionalProperties: false, required: ['query'], properties: { location: LOCATION, query: { type: 'string', minLength: 1, maxLength: 200 } } },
            output: { type: 'object' },
        },
        'files.read': {
            kind: 'read', doc: 'One file: the text of a text file (the first 6,000 characters), or what a binary file is.',
            input: { type: 'object', additionalProperties: false, required: ['location', 'id'], properties: { location: LOCATION, id: { type: 'string', maxLength: 1024 } } },
            output: { type: 'object' },
        },
    },
};
const textual = (type = '') => /^text\/|\/(json|xml|csv|markdown|x-yaml|yaml|javascript)$|\+json$|\+xml$/.test(type);
/** `tangle_os_dock`: the kernel's own contract over the person's dock, for the assistant and granted modules. */
export const DOCK_CONTRACT = {
    $contract: '0.1',
    id: 'tangle_os_dock',
    operations: {
        'dock.read': {
            kind: 'read',
            doc: 'The person\'s dock: its icons in order (an id is a module, or <module>/<entry> for one of its screens), its folders with their icons, the hidden icons, every icon\'s title, and the layout\'s revision.',
            input: { type: 'object', additionalProperties: false, properties: {} },
            output: { type: 'object' },
        },
        'dock.suggest': {
            kind: 'command',
            doc: 'Suggest a new arrangement of the dock (a layout document, as dock.read returns it). It goes to the person\'s inbox as a proposal they accept or reject; a new suggestion replaces your earlier one. Nothing changes until they accept.',
            input: { type: 'object', additionalProperties: false, required: ['layout'], properties: { layout: DOCK_SCHEMA } },
            output: { type: 'object', properties: { id: { type: 'string' } } },
        },
    },
};
/** A tool's name: `<contract>__<operation>` with every character outside [A-Za-z0-9_-] as `_`, at most 64. */
export const toolName = (contract, op) => `${contract}__${op.replace(/[^A-Za-z0-9_-]/g, '_')}`.slice(0, 64);
/** Callers the kernel trusts as the person's own hand: the shell's chrome. */
const TRUSTED = new Set(['shell']);
const refusal = (code, message) => ({ ok: false, error: { code, message } });
/** The member a built-in operation's refusal travels in through the contract client. */
const REFUSED = '__tangle_os_refused';
const scopeOf = (contract, op) => [`${contract}.${op}`, `${contract}.*`];
/**
 * `assistantGrants`: what the assistant may call — `'all'`, or scopes
 * (`contract.op`, `contract.*`). Nothing by default: a host decides.
 */
export function createKernel(options = {}) {
    const now = options.now ?? (() => Date.now());
    const recovery = options.recovery === true;
    const entries = new Map();
    const journal = [];
    const grants = new Map();
    /** Per contract, its registrations in order; the last one answers. Each belongs to one module and one owner (a window). */
    const providers = new Map();
    const ledger = [];
    const mail = [];
    const listeners = new Set();
    let seq = 0, mailSeq = 0;
    /** Per module, the windows that can carry a decision to it, most recent last. */
    const deciders = new Map();
    let proposalCheck = null;
    const answerCheckers = new Map();
    /** The installed capabilities, by id: the kinds their modules file and those kinds' review policies. */
    const capabilities = new Map();
    let capabilityCheck = null;
    const rolesOf = (module, kind) => { const manifest = kernel.effective(module); return (manifest && kindOf(manifest, kind)?.review?.roles) ?? []; };
    /** A kind a module may file, and its review policy: its own `proposals`, or a capability its manifest names. */
    function kindOf(manifest, kind) {
        if ((manifest.proposals ?? []).some(d => d.kind === kind))
            return {};
        for (const id of manifest.capabilities ?? []) {
            const declared = capabilities.get(id)?.proposals?.find(p => p.kind === kind);
            if (declared)
                return { ...(declared.review ? { review: declared.review } : {}) };
        }
        return null;
    }
    /** The compiled check of an answer schema, kept by its text. */
    function answerChecker(schema) {
        const key = JSON.stringify(schema);
        let check = answerCheckers.get(key);
        if (!check) {
            check = new JarenValidator({ skipErrors: false, collectErrors: true, unknownFormats: 'ignore' }).compile(schema);
            answerCheckers.set(key, check);
        }
        return check;
    }
    let headerCheck = null;
    let headerContract = null;
    let dockCheck = null;
    let filesContract = null;
    /** One location operation for the assistant's reading, refusals answered as values. */
    async function fileCall(location, op, input) {
        const known = kernel.fileLocations().find(l => l.contract === location);
        if (!known || !known.assistant)
            return { [REFUSED]: { code: 'OS0122', message: `'${location}' is not a file location the assistant may read` } };
        const provider = providers.get(location)?.at(-1);
        if (!provider)
            return { [REFUSED]: { code: 'OS0102', message: `no module serves '${location}' now` } };
        try {
            return fileAnswer(await provider.client.invoke(op, input));
        }
        catch (error) {
            return { [REFUSED]: { code: error?.code ?? 'OS0103', message: String(error?.message ?? error) } };
        }
    }
    let dockContract = null;
    let dockRevision = 0;
    // ── the desktop's state: a cache of documents, loaded once, saved through ──
    const cache = new Map();
    const idOf = (scope, key) => `${scope}\u0000${key}`;
    const queue = new Map();
    const inflight = new Set();
    let stateStatus = options.state ? 'loading' : 'ready';
    let failed = null;
    let activeStore = options.state && 'load' in options.state ? options.state : options.state ? null : memoryStore();
    const stateEvent = (key) => emit({ kind: 'state', ...(key ? { module: key } : {}) });
    let loading = Promise.resolve();
    function loadState(store) { return (loading = loadFrom(store)); }
    async function loadFrom(store) {
        activeStore = store;
        stateStatus = 'loading';
        stateEvent();
        try {
            const documents = await store.load();
            for (const d of documents)
                if (!queue.has(idOf(d.scope, d.key)))
                    cache.set(idOf(d.scope, d.key), d);
            stateStatus = 'ready';
            failed = null;
            restoreApps();
            if (documents.some(d => d.key === 'dock'))
                dockRevision++;
            emit({ kind: 'dock' });
            for (const id of queue.keys())
                flushKey(id);
        }
        catch (error) {
            // never write what was not read: an unreadable state stays unchangeable until it loads
            stateStatus = 'unavailable';
            failed = String(error?.message ?? error);
        }
        stateEvent();
    }
    function flushKey(id) {
        const pending = queue.get(id);
        if (!pending || inflight.has(id) || !activeStore || stateStatus !== 'ready')
            return;
        inflight.add(id);
        queue.delete(id);
        const ifRevision = cache.get(id)?.revision ?? 0;
        const store = activeStore;
        store.save({ scope: pending.scope, key: pending.key, value: pending.value }, ifRevision).then((answer) => {
            inflight.delete(id);
            if ('conflict' in answer) {
                // stored elsewhere meanwhile: the stored document wins, and a value set since it is dropped
                queue.delete(id);
                if (answer.conflict.value === null)
                    cache.delete(id);
                else
                    cache.set(id, answer.conflict);
                if (pending.key === 'dock') {
                    dockRevision++;
                    emit({ kind: 'dock' });
                }
                if (pending.key.startsWith('settings/'))
                    emit({ kind: 'settings', module: pending.key.slice(9) });
                if (pending.key === APPS_KEY)
                    restoreApps();
                stateEvent(pending.key);
                return;
            }
            const current = cache.get(id);
            if (current)
                current.revision = answer.revision;
            else if (pending.value !== null)
                cache.set(id, { scope: pending.scope, key: pending.key, value: pending.value, revision: answer.revision });
            if (failed !== null && inflight.size === 0)
                failed = null;
            stateEvent(pending.key);
            flushKey(id);
        }, (error) => {
            inflight.delete(id);
            // kept to try again, a little later each time; a newer value set meanwhile replaces it
            if (!queue.has(id))
                queue.set(id, { ...pending, attempt: pending.attempt + 1 });
            const next = queue.get(id);
            failed = String(error?.message ?? error);
            stateEvent(pending.key);
            clearTimeout(next.timer);
            next.timer = setTimeout(() => flushKey(id), Math.min(30_000, 1000 * 2 ** Math.min(next.attempt - 1, 5)));
        });
    }
    /** Change one document now, and save it in the background. */
    function writeState(scope, key, value) {
        if (stateStatus !== 'ready')
            return refusal('OS0121', stateStatus === 'loading' ? 'the desktop state is still loading' : 'the desktop state could not be loaded');
        const id = idOf(scope, key);
        const current = cache.get(id);
        if (value === null) {
            if (current)
                cache.set(id, { ...current, value: null });
        }
        else
            cache.set(id, { scope, key, value: cloneJson(value), revision: current?.revision ?? 0 });
        const earlier = queue.get(id);
        clearTimeout(earlier?.timer);
        queue.set(id, { scope, key, value: value === null ? null : cloneJson(value), attempt: 0 });
        flushKey(id);
        return { ok: true, value: {} };
    }
    const readState = (scope, key) => { const d = cache.get(idOf(scope, key)); return d && d.value !== null ? cloneJson(d.value) : undefined; };
    /** The checked shape of a layout, or null. */
    function checkDock(value) {
        dockCheck ??= new JarenValidator({ skipErrors: false, collectErrors: true, unknownFormats: 'ignore' }).compile(DOCK_SCHEMA);
        const outcome = dockCheck(value);
        return (typeof outcome === 'object' && outcome !== null ? outcome.valid : outcome === true) ? normalizeDock(value) : null;
    }
    /** Per window, its header bar and the module that set it; and where the window takes activations. */
    const headers = new Map();
    const headerHandlers = new Map();
    // a host that keeps settings itself (the earlier seam) still does; otherwise they are desktop state
    const checkers = new Map();
    /** The compiled schema of a form module's settings, compiled again only when its manifest changes it. */
    function checker(module, schema) {
        const key = JSON.stringify(schema), known = checkers.get(module);
        if (known?.key === key)
            return known.check;
        const check = new JarenValidator({ skipErrors: false, collectErrors: true, unknownFormats: 'ignore' }).compile(schema);
        checkers.set(module, { key, check });
        return check;
    }
    // ── joined applications: installed by the person's consent, kept in their state ──
    /** The joined applications as the person's state keeps them. */
    function persistApps() {
        const apps = [...entries.values()].filter(e => e.layer === 'user' && e.consent).map(e => ({ manifest: cloneJson(e.base), consent: cloneJson(e.consent) }));
        // an empty list, not a deleted document: a store may count a deleted document's revision from the start again
        return writeState('person', APPS_KEY, { apps });
    }
    /** Take the kept list as it is: install what it holds, drop joined applications it no longer holds. */
    function restoreApps() {
        const kept = readState('person', APPS_KEY)?.apps;
        const list = Array.isArray(kept) ? kept : [];
        const ids = new Set();
        for (const app of list) {
            const verdict = validateManifest(app?.manifest);
            const consent = app?.consent;
            if (!verdict.ok || !consent || !Array.isArray(consent.offered) || !Array.isArray(consent.scopes) || !Array.isArray(consent.provides))
                continue;
            const id = verdict.manifest.id;
            const existing = entries.get(id);
            if (RESERVED_IDS.includes(id) || (existing && existing.layer !== 'user'))
                continue;
            ids.add(id);
            entries.set(id, { base: verdict.manifest, layer: 'user', overlays: existing?.overlays ?? [], consent: cloneJson(consent) });
            grants.set(id, new Set(consent.scopes.filter(s => consent.offered.includes(s))));
            emit({ kind: 'modules', module: id });
        }
        for (const [id, entry] of [...entries])
            if (entry.layer === 'user' && entry.consent && !ids.has(id)) {
                entries.delete(id);
                grants.delete(id);
                emit({ kind: 'modules', module: id });
            }
    }
    /** A joined application's kept scopes follow its grants, within what it asked for. */
    function keepScopes(module) {
        const entry = entries.get(module);
        if (!entry?.consent || stateStatus !== 'ready')
            return;
        entry.consent = { ...entry.consent, scopes: [...(grants.get(module) ?? [])].filter(s => entry.consent.offered.includes(s)) };
        persistApps();
    }
    /** Whether the assistant may reach a module: a joined application only when the person allowed it. */
    function assistantMay(module) {
        const entry = entries.get(module);
        return !entry?.consent || entry.consent.assistant === true;
    }
    /** The joined application that declares a contract, if one does. */
    function joinedOwner(contract) {
        for (const [id, entry] of entries)
            if (entry.consent && (compose(entry).provides ?? []).some(c => c.id === contract))
                return id;
        return null;
    }
    const emit = (event) => { for (const listener of listeners)
        listener(event); };
    const record = (entry) => journal.push({ seq: ++seq, at: now(), ...entry });
    function visible(entry) {
        return !(recovery && entry.layer === 'user');
    }
    function compose(entry) {
        let doc = cloneJson(entry.base);
        for (const overlay of entry.overlays) {
            if (recovery && overlay.layer === 'user')
                continue;
            doc = applyJSONPatch(doc, overlay.patch);
        }
        return doc;
    }
    function grantRequires(manifest, layer) {
        if (layer === 'user')
            return; // a module a person or the assistant made asks first
        const set = grants.get(manifest.id) ?? new Set();
        for (const need of manifest.requires ?? []) {
            if (need.operations?.length)
                for (const op of need.operations)
                    set.add(`${need.contract}.${op}`);
            else
                set.add(`${need.contract}.*`);
        }
        grants.set(manifest.id, set);
    }
    /** Only the module whose manifest declares a contract may serve it, and only while no other module does. */
    function mayServe(module, id) {
        const declared = kernel.effective(module)?.provides?.some(c => c.id === id);
        const taken = (providers.get(id) ?? []).find(p => p.module !== module);
        if (!declared || taken)
            throw Object.assign(new Error(`'${module}' may not serve '${id}'${taken ? `: '${taken.module}' serves it` : ': its manifest does not declare it'}`), { code: 'OS0011' });
    }
    const kernel = {
        recovery,
        /**
         * Install a whole module in a layer. A shipped or suite module is granted
         * what it declares it requires, unless `grant: false`: a suite joined
         * from a link is installed without grants, so a link cannot hand a
         * module access. A contract another module already declares is refused.
         */
        install(value, layer = 'shipped', install = {}) {
            const verdict = validateManifest(value);
            if (!verdict.ok)
                return verdict;
            const { manifest } = verdict;
            if (RESERVED_IDS.includes(manifest.id))
                return { ok: false, issues: [{ code: 'OS0012', path: '/id', message: `'${manifest.id}' is the desktop's own; a module takes another id` }] };
            const existing = entries.get(manifest.id);
            if (existing && existing.layer !== layer) {
                return { ok: false, issues: [{ code: 'OS0004', path: '/id', message: `'${manifest.id}' is already installed in the ${existing.layer} layer; change it with a patch instead` }] };
            }
            for (const [index, contract] of (manifest.provides ?? []).entries()) {
                const other = [...entries.values()].find(e => e.base.id !== manifest.id && (e.base.provides ?? []).some(c => c.id === contract.id));
                if (other)
                    return { ok: false, issues: [{ code: 'OS0011', path: `/provides/${index}/id`, message: `the contract '${contract.id}' is already provided by '${other.base.id}'` }] };
            }
            entries.set(manifest.id, { base: manifest, layer, overlays: existing?.overlays ?? [] });
            if (install.grant !== false)
                grantRequires(manifest, layer);
            if (layer === 'user')
                record({ layer, module: manifest.id, kind: 'install' });
            emit({ kind: 'modules', module: manifest.id });
            return { ok: true, manifest };
        },
        /**
         * Change an installed module with an RFC 6902 patch in a layer above its
         * own. The shipped document is never written; the result must still be a
         * valid manifest, or the patch is refused and nothing changes.
         */
        patch(id, patch, layer = 'user') {
            const entry = entries.get(id);
            if (!entry)
                return refusal('OS0005', `no module '${id}'`);
            const before = compose(entry);
            let after;
            try {
                after = applyJSONPatch(before, patch);
            }
            catch (error) {
                return refusal('OS0006', `the patch does not apply: ${error?.message ?? error}`);
            }
            const verdict = validateManifest(after);
            if (!verdict.ok)
                return refusal('OS0007', `the patched module is not valid: ${verdict.issues.map(i => `${i.path} ${i.message}`).join('; ')}`);
            if (after.id !== id)
                return refusal('OS0008', 'a patch cannot change a module\'s id');
            entry.overlays.push({ layer, patch: cloneJson(patch) });
            record({ layer, module: id, kind: 'patch', patch: cloneJson(patch), inverse: createJSONPatch(after, before) });
            emit({ kind: 'modules', module: id });
            return { ok: true, value: verdict.manifest };
        },
        /** Remove a module a person installed. Shipped and suite modules are not removable, only hidden by a patch. */
        remove(id) {
            const entry = entries.get(id);
            if (!entry)
                return refusal('OS0005', `no module '${id}'`);
            if (entry.layer !== 'user')
                return refusal('OS0009', `'${id}' belongs to the ${entry.layer} layer and cannot be removed`);
            if (entry.consent && stateStatus !== 'ready')
                return refusal('OS0121', 'the desktop state is not ready to change the installed applications');
            entries.delete(id);
            grants.delete(id);
            record({ layer: 'user', module: id, kind: 'remove', patch: [], inverse: [{ op: 'add', path: '', value: cloneJson(entry.base) }], ...(entry.consent ? { consent: cloneJson(entry.consent) } : {}) });
            if (entry.consent)
                persistApps();
            emit({ kind: 'modules', module: id });
            return { ok: true, value: null };
        },
        /** Undo the person's last change. */
        undo() {
            const last = [...journal].reverse().find(e => e.layer === 'user');
            if (!last)
                return refusal('OS0010', 'nothing to undo');
            journal.splice(journal.indexOf(last), 1);
            const entry = entries.get(last.module);
            const joined = !!entry?.consent || !!last.consent;
            if (last.kind === 'install') {
                entries.delete(last.module);
                grants.delete(last.module);
            }
            else if (last.kind === 'patch' && entry) {
                const index = entry.overlays.map(o => o.layer).lastIndexOf('user');
                if (index >= 0)
                    entry.overlays.splice(index, 1);
            }
            else if (last.kind === 'remove') {
                const base = last.inverse?.[0]?.value;
                entries.set(last.module, { base, layer: 'user', overlays: [], ...(last.consent ? { consent: cloneJson(last.consent) } : {}) });
                if (last.consent)
                    grants.set(last.module, new Set(last.consent.scopes));
            }
            if (joined)
                persistApps();
            emit({ kind: 'modules', module: last.module });
            return { ok: true, value: { undone: last.seq } };
        },
        effective(id) {
            const entry = entries.get(id);
            return entry && visible(entry) ? compose(entry) : null;
        },
        modules() {
            return [...entries.values()].filter(visible).map(compose);
        },
        layerOf(id) { return entries.get(id)?.layer ?? null; },
        journal() { return cloneJson(journal); },
        grant(caller, scope) { const set = grants.get(caller) ?? new Set(); set.add(scope); grants.set(caller, set); keepScopes(caller); emit({ kind: 'modules', module: caller }); },
        revoke(caller, scope) { grants.get(caller)?.delete(scope); keepScopes(caller); emit({ kind: 'modules', module: caller }); },
        /**
         * Install an application the person joined, in their layer, with exactly
         * what they allowed: `scopes` out of what its manifest asks for (`OS0140`
         * for one it does not ask for), and whether the assistant may use what it
         * provides. Kept in the person's state, so it is there on their next visit
         * and on their other devices; refused (`OS0121`) until that state loads.
         * Only the shell's install sheet, after the person's gesture, calls this.
         */
        join(value, allow) {
            if (stateStatus !== 'ready')
                return refusal('OS0121', stateStatus === 'loading' ? 'the desktop state is still loading' : 'the desktop state could not be loaded');
            const verdict = validateManifest(value);
            if (!verdict.ok)
                return refusal('OS0007', `the application is not valid: ${verdict.issues.map(i => `${i.path} ${i.message}`).join('; ')}`);
            const offered = scopesOf(verdict.manifest);
            const extra = (allow.scopes ?? []).filter(s => !offered.includes(s));
            if (extra.length)
                return refusal('OS0140', `'${verdict.manifest.id}' does not ask for ${extra.join(', ')}`);
            const existing = entries.get(verdict.manifest.id);
            let installed;
            if (existing?.layer === 'user' && existing.consent) {
                // joined before: its manifest is updated in place, so the person's undo does not take the application away
                const taken = (verdict.manifest.provides ?? []).find(c => [...entries.values()].some(e => e !== existing && (e.base.provides ?? []).some(p => p.id === c.id)));
                if (taken)
                    return refusal('OS0011', `the contract '${taken.id}' is already provided by another module`);
                existing.base = verdict.manifest;
                installed = { ok: true, manifest: verdict.manifest };
            }
            else
                installed = kernel.install(verdict.manifest, 'user', { grant: false });
            if (!installed.ok)
                return refusal(installed.issues[0]?.code ?? 'OS0007', installed.issues.map(i => i.message).join('; '));
            const id = installed.manifest.id;
            const consent = {
                ...(allow.source ? { source: allow.source } : {}),
                origin: originOf(installed.manifest), offered, scopes: [...new Set(allow.scopes ?? [])],
                provides: (installed.manifest.provides ?? []).map(c => c.id), assistant: allow.assistant === true, at: now(),
            };
            entries.get(id).consent = consent;
            grants.set(id, new Set(consent.scopes));
            persistApps();
            emit({ kind: 'modules', module: id });
            return { ok: true, value: { manifest: installed.manifest, consent: cloneJson(consent) } };
        },
        /** What the person allowed a joined application, or null for one they did not join. */
        consentOf(id) { const c = entries.get(id)?.consent; return c ? cloneJson(c) : null; },
        /** Whether installing this manifest needs the person's consent (again), against what they allowed before. */
        consentNeeded(value) { return consentNeeded(value, entries.get(value.id)?.consent ?? null); },
        /** Change what a joined application may use, or whether the assistant may use it (`OS0141` for one not joined). */
        setConsent(id, change) {
            const entry = entries.get(id);
            if (!entry?.consent)
                return refusal('OS0141', `'${id}' was not joined with the person's consent`);
            if (stateStatus !== 'ready')
                return refusal('OS0121', 'the desktop state is not ready');
            const next = { ...entry.consent };
            if (change.scopes) {
                const extra = change.scopes.filter(s => !next.offered.includes(s));
                if (extra.length)
                    return refusal('OS0140', `'${id}' does not ask for ${extra.join(', ')}`);
                next.scopes = [...new Set(change.scopes)];
                grants.set(id, new Set(next.scopes));
            }
            if (typeof change.assistant === 'boolean')
                next.assistant = change.assistant;
            entry.consent = next;
            persistApps();
            emit({ kind: 'modules', module: id });
            return { ok: true, value: cloneJson(next) };
        },
        grants() { return Object.fromEntries([...grants].map(([k, v]) => [k, [...v].sort()])); },
        /** A `form` module's settings as the person set them (`{}` until they do); `{}` for a module that keeps its own. */
        settings(module) {
            const manifest = kernel.effective(module);
            if (manifest?.settings?.kind !== 'form')
                return {};
            return cloneJson((options.settings ? options.settings.read(module) : readState('person', `settings/${module}`)) ?? {});
        },
        /**
         * The person sets a `form` module's settings in the desktop's Settings:
         * checked against the module's schema, kept, and reported (`settings`).
         * Refused for a module that keeps its own (`OS0105`) or values its schema
         * refuses (`OS0106`).
         */
        setSettings(module, values) {
            const manifest = kernel.effective(module);
            if (manifest?.settings?.kind !== 'form')
                return refusal('OS0105', `'${module}' keeps its own settings`);
            const outcome = checker(module, manifest.settings.schema)(values);
            const valid = typeof outcome === 'object' && outcome !== null ? outcome.valid : outcome === true;
            if (!valid) {
                const first = (outcome?.errors ?? [])[0];
                return refusal('OS0106', `the settings of '${module}' are refused${first ? `: ${first.instancePath || '/'} ${first.message ?? ''}`.trimEnd() : ''}`);
            }
            if (options.settings)
                options.settings.write(module, cloneJson(values));
            else {
                const written = writeState('person', `settings/${module}`, values);
                if (!written.ok)
                    return written;
            }
            emit({ kind: 'settings', module });
            return { ok: true, value: cloneJson(values) };
        },
        allowed(caller, contract, op) {
            if (TRUSTED.has(caller))
                return true;
            // a file location is the person's: the assistant reads it through tangle_os_files, never writes it
            if (caller === 'assistant' && kernel.fileLocations().some(l => l.contract === contract))
                return false;
            // what a joined application provides reaches the assistant only when the person allowed it, whatever the host grants
            if (caller === 'assistant') {
                const owner = joinedOwner(contract);
                if (owner && !assistantMay(owner))
                    return false;
            }
            if (caller === 'assistant' && options.assistantGrants === 'all')
                return true;
            const set = caller === 'assistant' ? new Set(Array.isArray(options.assistantGrants) ? options.assistantGrants : []) : grants.get(caller);
            return !!set && scopeOf(contract, op).some(s => set.has(s));
        },
        /**
         * Make a contract callable: the client reaches the module that serves it.
         * Only the module whose manifest declares the contract may serve it
         * (`OS0011` otherwise), so one module cannot take over another's.
         */
        provide(module, contractDoc, client, owner = module) {
            const contract = compileContract(contractDoc);
            const id = contract.doc?.id ?? contractDoc.id;
            mayServe(module, id);
            providers.set(id, [...(providers.get(id) ?? []).filter(p => p.owner !== owner), { module, owner, contract, client }]);
            emit({ kind: 'providers', module });
            // the application the host named serves the desktop's state: load it from there (again, after it reconnects)
            if (id === STATE_CONTRACT.id && options.state && 'module' in options.state && options.state.module === module) {
                const store = contractStore({ invoke: (op, input) => client.invoke(op, input) });
                if (stateStatus === 'ready') {
                    activeStore = store;
                    for (const key of queue.keys())
                        flushKey(key);
                }
                else
                    void loadState(store);
            }
        },
        /** A shipped module serves a contract from inside the page. */
        provideLocal(module, contractDoc, handlers, owner = module) {
            mayServe(module, contractDoc?.id);
            const contract = compileContract(contractDoc);
            kernel.provide(module, contractDoc, openLocalClient(contract, handlers), owner);
        },
        /** Withdraw what one owner (a window) registered; another window of the same module keeps serving. */
        withdraw(module, owner = module) {
            for (const [id, list] of providers) {
                const kept = list.filter(p => !(p.module === module && p.owner === owner));
                if (kept.length)
                    providers.set(id, kept);
                else
                    providers.delete(id);
            }
            emit({ kind: 'providers', module });
        },
        providers() {
            return [...providers].map(([contract, list]) => { const p = list.at(-1); return { contract, module: p.module, operations: Object.keys(p.contract.doc?.operations ?? {}) }; });
        },
        /** The bus: one operation of one contract, for one caller, under grants, into the ledger. */
        async call(caller, contract, op, input = {}) {
            const started = now();
            const write = (outcome) => {
                ledger.push({ seq: ledger.length + 1, at: started, caller, contract, op, ok: outcome.ok, ...(outcome.ok ? {} : { code: outcome.error.code }), ms: now() - started });
                emit({ kind: 'ledger' });
                return outcome;
            };
            if (contract === FILES_CONTRACT.id) {
                if (!kernel.allowed(caller, contract, op))
                    return write(refusal('OS0101', `'${caller}' is not granted ${contract}.${op}`));
                filesContract ??= compileContract(FILES_CONTRACT);
                const client = openLocalClient(filesContract, {
                    'files.locations': () => ({ locations: kernel.fileLocations().filter(l => l.assistant && l.served).map(l => ({ location: l.contract, module: l.module, title: l.title })) }),
                    'files.list': (input) => fileCall(input.location, 'files.list', { folder: input.folder ?? null, ...(input.cursor ? { cursor: input.cursor } : {}) }),
                    'files.search': async ({ location, query }) => {
                        const where = location ? [location] : kernel.fileLocations().filter(l => l.assistant && l.served).map(l => l.contract);
                        const found = [];
                        for (const at of where) {
                            const answer = await fileCall(at, 'files.search', { query, limit: 50 });
                            if (answer[REFUSED])
                                return answer;
                            found.push(...answer.entries.map((e) => ({ ...e, location: at })));
                        }
                        return { entries: found.slice(0, 100) };
                    },
                    'files.read': async ({ location, id }) => {
                        const answer = await fileCall(location, 'files.read', { id });
                        if (answer[REFUSED])
                            return answer;
                        const entry = answer.entry;
                        if (!textual(entry.type) || !answer.data)
                            return { entry, note: `a ${entry.type ?? 'binary'} file of ${entry.size ?? '?'} bytes; only text files are read` };
                        const text = new TextDecoder().decode(fileBase64ToBytes(answer.data));
                        return { entry, text: text.slice(0, ASSISTANT_TEXT), ...(text.length > ASSISTANT_TEXT ? { truncated: text.length } : {}) };
                    },
                });
                try {
                    const outcome = await client.invoke(op, input);
                    if (!outcome?.ok)
                        return write(refusal(outcome?.error?.code ?? 'OS0103', outcome?.error?.message ?? 'the operation failed'));
                    const refused = outcome.value?.[REFUSED];
                    return write(refused ? refusal(refused.code, refused.message) : { ok: true, value: outcome.value });
                }
                catch (error) {
                    return write(refusal(error?.code ?? 'OS0103', String(error?.message ?? error)));
                }
            }
            if (contract === DOCK_CONTRACT.id) {
                if (!kernel.allowed(caller, contract, op))
                    return write(refusal('OS0101', `'${caller}' is not granted ${contract}.${op}`));
                dockContract ??= compileContract(DOCK_CONTRACT);
                const client = openLocalClient(dockContract, {
                    'dock.read': () => kernel.dockView(),
                    'dock.suggest': ({ layout }) => { const outcome = kernel.suggestDock(caller, layout); return outcome.ok ? outcome.value : { [REFUSED]: outcome.error }; },
                });
                try {
                    const outcome = await client.invoke(op, input);
                    if (!outcome?.ok)
                        return write(refusal(outcome?.error?.code ?? 'OS0103', outcome?.error?.message ?? 'the operation failed'));
                    const refused = outcome.value?.[REFUSED];
                    return write(refused ? refusal(refused.code, refused.message) : { ok: true, value: outcome.value });
                }
                catch (error) {
                    return write(refusal(error?.code ?? 'OS0103', String(error?.message ?? error)));
                }
            }
            if (contract === HEADER_CONTRACT.id) {
                if (!kernel.allowed(caller, contract, op))
                    return write(refusal('OS0101', `'${caller}' is not granted ${contract}.${op}`));
                headerContract ??= compileContract(HEADER_CONTRACT);
                // checked against the contract like any served operation, with the caller bound here
                const client = openLocalClient(headerContract, {
                    'header.list': () => ({ windows: kernel.headers(caller) }),
                    // a refusal travels as the value: a thrown error would reach the caller only as the client's own failure
                    'header.activate': async ({ window, item, value }) => {
                        const outcome = await kernel.activateHeader(caller, window, item, value);
                        return outcome.ok ? {} : { [REFUSED]: outcome.error };
                    },
                });
                try {
                    const outcome = await client.invoke(op, input);
                    if (!outcome?.ok)
                        return write(refusal(outcome?.error?.code ?? 'OS0103', outcome?.error?.message ?? 'the operation failed'));
                    const refused = outcome.value?.[REFUSED];
                    return write(refused ? refusal(refused.code, refused.message) : { ok: true, value: outcome.value });
                }
                catch (error) {
                    return write(refusal(error?.code ?? 'OS0103', String(error?.message ?? error)));
                }
            }
            const provider = providers.get(contract)?.at(-1);
            if (!provider)
                return write(refusal('OS0102', `no module serves '${contract}'`));
            if (!kernel.allowed(caller, contract, op))
                return write(refusal('OS0101', `'${caller}' is not granted ${contract}.${op}`));
            try {
                const outcome = await provider.client.invoke(op, input);
                if (outcome?.ok)
                    return write({ ok: true, value: outcome.value });
                return write(refusal(outcome?.error?.code ?? 'OS0103', outcome?.error?.message ?? 'the operation failed'));
            }
            catch (error) {
                return write(refusal('OS0103', String(error?.message ?? error)));
            }
        },
        ledger() { return cloneJson(ledger); },
        sendMail(from, envelope) {
            const item = { id: `m${++mailSeq}`, at: now(), from, to: envelope.to ?? 'person', subject: envelope.subject, ...(envelope.body !== undefined ? { body: envelope.body } : {}), ...(envelope.data !== undefined ? { data: cloneJson(envelope.data) } : {}), read: false };
            mail.push(item);
            emit({ kind: 'mail', module: from });
            return item;
        },
        mail() { return cloneJson(mail); },
        markRead(id) { const item = mail.find(m => m.id === id); if (item && !item.read) {
            item.read = true;
            emit({ kind: 'mail' });
        } },
        /**
         * File a proposal in the inbox for the person. The kind must be one the
         * module's manifest declares (`OS0107`) and the proposal must match its
         * schema (`OS0108`); filing the same id again replaces it, pending again.
         * The module keeps its proposals: the inbox lives as long as the page.
         */
        propose(module, input) {
            const manifest = kernel.effective(module);
            if (!manifest)
                return refusal('OS0108', `no module '${module}'`);
            proposalCheck ??= new JarenValidator({ skipErrors: false, collectErrors: true, unknownFormats: 'ignore' }).compile(PROPOSAL_SCHEMA);
            const outcome = proposalCheck(input);
            if (!(typeof outcome === 'object' && outcome !== null ? outcome.valid : outcome === true)) {
                const first = (outcome?.errors ?? [])[0];
                return refusal('OS0108', `the proposal is refused${first ? `: ${first.instancePath || '/'} ${first.message ?? ''}`.trimEnd() : ''}`);
            }
            const p = input;
            const declared = kindOf(manifest, p.kind);
            if (!declared)
                return refusal('OS0107', `'${module}' declares no proposals of kind '${p.kind}'`);
            const origins = declared.review?.origins;
            if (origins && !origins.includes(p.origin ?? ''))
                return refusal('OS0133', `a '${p.kind}' proposal is filed by ${origins.join(', ')}${p.origin ? `, not ${p.origin}` : '; say who files it (origin)'}`);
            if (p.answer) {
                // the answer's form is drawn from its schema: bounded, compilable, and never asking for a secret
                const text = JSON.stringify(p.answer.schema);
                if (text.length > 20_000)
                    return refusal('OS0108', 'the proposal is refused: its answer schema is larger than 20,000 characters');
                if (/"writeOnly"\s*:\s*true|"format"\s*:\s*"password"/.test(text))
                    return refusal('OS0108', 'the proposal is refused: the desktop asks for no secret');
                try {
                    answerChecker(p.answer.schema);
                }
                catch (error) {
                    return refusal('OS0108', `the proposal is refused: its answer schema does not compile (${String(error?.message ?? error).slice(0, 200)})`);
                }
            }
            const proposal = { id: p.id, kind: p.kind, status: 'pending',
                ...(p.origin !== undefined ? { origin: p.origin } : {}), ...(p.answer !== undefined ? { answer: cloneJson(p.answer) } : {}),
                ...(p.summary !== undefined ? { summary: p.summary } : {}), ...(p.payload !== undefined ? { payload: cloneJson(p.payload) } : {}),
                ...(p.evidence !== undefined ? { evidence: cloneJson(p.evidence) } : {}), ...(p.revision !== undefined ? { revision: p.revision } : {}) };
            const existing = mail.find(m => m.from === module && m.proposal?.id === p.id);
            if (existing?.proposal?.status === 'deciding')
                return refusal('OS0111', `the proposal '${p.id}' is being decided`);
            if (existing) {
                existing.subject = p.title;
                existing.proposal = proposal;
                existing.read = false;
                existing.at = now();
            }
            else
                mail.push({ id: `m${++mailSeq}`, at: now(), from: module, to: 'person', subject: p.title, read: false, proposal });
            emit({ kind: 'mail', module });
            return { ok: true, value: { id: p.id } };
        },
        /**
         * Install a capability (`CAPABILITY_SCHEMA`): its kinds and their review
         * policies become those of every module whose manifest names it. Only the
         * shipped and suite layers install one (`OS0130`): its prompt pack becomes
         * the assistant's system text, so a person's or the assistant's own layer
         * never writes it. Refused when it does not match (`OS0130`) or does not
         * agree with itself (`OS0131`).
         */
        installCapability(doc, layer = 'shipped') {
            if (layer === 'user')
                return refusal('OS0130', 'a capability is installed by the host (shipped or suite), never in the user layer');
            capabilityCheck ??= new JarenValidator({ skipErrors: false, collectErrors: true, unknownFormats: 'ignore' }).compile(CAPABILITY_SCHEMA);
            const outcome = capabilityCheck(doc);
            if (!(typeof outcome === 'object' && outcome !== null ? outcome.valid : outcome === true)) {
                const first = (outcome?.errors ?? [])[0];
                return refusal('OS0130', `the capability is refused${first ? `: ${first.instancePath || '/'} ${first.message ?? ''}`.trimEnd() : ''}`);
            }
            const issues = capabilityIssues(doc);
            if (issues.length)
                return refusal(issues[0].code, `the capability is refused: ${issues[0].path} ${issues[0].message}`);
            capabilities.set(doc.id, cloneJson(doc));
            emit({ kind: 'modules' });
            return { ok: true, value: { id: doc.id } };
        },
        /** The installed capabilities. */
        capabilities() { return [...capabilities.values()].map(c => cloneJson(c)); },
        /** The review policy of a module's kind: who may file it, and the roles that may decide it (a hint the module enforces). */
        reviewOf(module, kind) {
            const manifest = kernel.effective(module);
            return manifest ? kindOf(manifest, kind)?.review ?? {} : null;
        },
        /** Take back a module's pending proposal. */
        withdrawProposal(module, id) {
            const index = mail.findIndex(m => m.from === module && m.proposal?.id === id);
            if (index < 0)
                return refusal('OS0109', `no proposal '${id}' from '${module}'`);
            if (mail[index].proposal.status !== 'pending')
                return refusal('OS0111', `the proposal '${id}' is ${mail[index].proposal.status}`);
            mail.splice(index, 1);
            emit({ kind: 'mail', module });
            return { ok: true, value: {} };
        },
        /**
         * Where a module's decisions go while one of its windows can take them:
         * the shell registers the window's control channel. Returns the release.
         */
        registerDecider(module, owner, decide) {
            const list = (deciders.get(module) ?? []).filter(d => d.owner !== owner);
            list.push({ owner, decide });
            deciders.set(module, list);
            return () => { const kept = (deciders.get(module) ?? []).filter(d => d.owner !== owner); if (kept.length)
                deciders.set(module, kept);
            else
                deciders.delete(module); };
        },
        /**
         * The person accepts or rejects a proposal. The decision goes to the
         * module that filed it, over its own channel, never as a contract
         * operation, so neither the assistant nor another module can decide. One
         * decision at a time; a module that is not running (`OS0110`), refuses
         * (`OS0112`, e.g. its revision moved) or fails leaves the proposal pending
         * with the reason.
         */
        async decide(mailId, decision, response) {
            const item = mail.find(m => m.id === mailId);
            const p = item?.proposal;
            if (!item || !p)
                return refusal('OS0109', `no proposal '${mailId}'`);
            if (p.status !== 'pending')
                return refusal('OS0111', `the proposal is ${p.status}`);
            if (decision === 'answer') {
                if (!p.answer)
                    return refusal('OS0123', 'this proposal asks for no answer');
                const verdict = answerChecker(p.answer.schema)(response);
                if (!(typeof verdict === 'object' && verdict !== null ? verdict.valid : verdict === true)) {
                    const first = (verdict?.errors ?? [])[0];
                    return refusal('OS0124', `the answer is refused${first ? `: ${first.instancePath || '/'} ${first.message ?? ''}`.trimEnd() : ''}`);
                }
            }
            const settle = (status, reason) => {
                item.proposal = { ...item.proposal, status, ...(reason ? { reason } : {}) };
                if (!reason)
                    delete item.proposal.reason;
                emit({ kind: 'mail', module: item.from });
            };
            // the desktop's own proposal (a suggested dock) is carried out here, against the revision it was made for
            if (item.from === 'desktop' && p.kind === 'dock.layout') {
                const payload = p.payload;
                if (decision === 'accept') {
                    if (payload.revision !== dockRevision) {
                        settle('pending', { code: 'OS0112', message: 'the dock changed since this was suggested' });
                        return refusal('OS0112', 'the dock changed since this was suggested');
                    }
                    const applied = kernel.setDock(payload.layout);
                    if (!applied.ok) {
                        settle('pending', { code: 'OS0112', message: applied.error.message });
                        return refusal('OS0112', applied.error.message);
                    }
                }
                settle(decision === 'accept' ? 'accepted' : 'rejected');
                return { ok: true, value: { status: item.proposal.status } };
            }
            const target = (deciders.get(item.from) ?? []).at(-1);
            if (!target) {
                settle('pending', { code: 'OS0110', message: `'${item.from}' is not running` });
                return refusal('OS0110', `'${item.from}' is not running`);
            }
            settle('deciding');
            try {
                const answer = await target.decide({ id: p.id, kind: p.kind, decision, ...(p.revision !== undefined ? { revision: p.revision } : {}), ...(p.payload !== undefined ? { payload: cloneJson(p.payload) } : {}), ...(decision === 'answer' ? { response: cloneJson(response ?? null) } : {}), ...(rolesOf(item.from, p.kind).length ? { roles: rolesOf(item.from, p.kind) } : {}) });
                if (answer && typeof answer.refused === 'string') {
                    settle('pending', { code: 'OS0112', message: answer.refused });
                    return refusal('OS0112', answer.refused);
                }
            }
            catch (error) {
                const message = String(error?.message ?? error);
                settle('pending', { code: 'OS0112', message });
                return refusal('OS0112', message);
            }
            settle(decision === 'reject' ? 'rejected' : 'accepted');
            return { ok: true, value: { status: item.proposal.status } };
        },
        /** The modules that open a file of this type (`text/calendar`); a manifest's subtype or type may be a star. */
        openersFor(type) {
            const [major, minor] = type.toLowerCase().split(';')[0].trim().split('/');
            return kernel.modules().filter(m => (m.opens ?? []).some(o => { const [a, b] = o.type.split('/'); return (a === '*' || a === major) && (b === '*' || b === minor); }));
        },
        /** Every file location the installed modules declare: its contract, title, whether the assistant may read it, and whether it is served now. */
        fileLocations() {
            return kernel.modules().flatMap(m => m.files ? [{ module: m.id, contract: m.files.contract, title: m.files.title?.en ?? m.title.en, assistant: m.files.assistant !== false && assistantMay(m.id), served: providers.has(m.files.contract) }] : []);
        },
        /** The person's saved dock layout, or null for one they have not arranged (a recovery boot ignores it). */
        dock() {
            if (recovery)
                return null;
            return checkDock(readState('person', 'dock') ?? null);
        },
        /** A document of the desktop's state the host keeps for itself (its preferences): never a secret. */
        state(key, scope = 'person') { return readState(scope, key); },
        /** Keep a document of the host's own; refused (`OS0121`) while the state is loading or could not be loaded. */
        setState(key, value, scope = 'person') {
            if (!/^[A-Za-z0-9._:/-]{1,200}$/.test(key) || key === 'dock' || key === APPS_KEY || key.startsWith('settings/'))
                return refusal('OS0120', `'${key}' is not a key the host may set`);
            const written = writeState(scope, key, value);
            if (written.ok)
                stateEvent(key);
            return written;
        },
        /** Resolves when the state's latest load has finished (loaded, or found unavailable). */
        ready() { return loading; },
        /** Whether the state is loaded, how many saves are on their way, and the last save failure. */
        stateStatus() { return { status: stateStatus, saving: queue.size + inflight.size, failed }; },
        /** Load the state again (after it could not be loaded, or to take what another device changed). */
        reloadState() { return activeStore ? loadState(activeStore) : Promise.resolve(); },
        /** Resolves when every change made so far is saved (or has failed). */
        async flushState() {
            for (const id of [...queue.keys()])
                flushKey(id);
            while (inflight.size)
                await new Promise(resolve => setTimeout(resolve, 10));
        },
        /** The layout's revision: it moves with every change, so a suggestion made against an older dock is refused. */
        dockRevision() { return dockRevision; },
        /** Keep a new dock layout (`OS0119` when it does not match the dock schema). */
        setDock(layout) {
            const checked = checkDock(layout);
            if (!checked)
                return refusal('OS0119', 'the dock layout is refused: it does not match the dock schema');
            const written = writeState('person', 'dock', checked);
            if (!written.ok)
                return written;
            dockRevision++;
            emit({ kind: 'dock' });
            return { ok: true, value: { revision: dockRevision } };
        },
        /** The dock as the installed modules and the saved layout make it, in English titles, with its revision. */
        dockView() {
            const manifests = kernel.modules();
            const { layout, view } = arrangeDock(kernel.dock(), dockIcons(manifests), folderTitles(manifests));
            const icon = (i) => ({ id: i.id, title: i.title });
            return {
                revision: dockRevision, layout,
                items: view.items.map(i => i.kind === 'icon' ? { icon: icon(i.icon) } : { folder: i.id, title: i.title, icons: i.icons.map(icon) }),
                hidden: view.hidden.map(icon),
            };
        },
        /**
         * File a suggested dock in the person's inbox, as the desktop's own
         * proposal; nothing changes until they accept it, and it is refused then
         * if the dock moved meanwhile. One suggestion per caller: a new one
         * replaces the last. The inbox shows what would change, derived here,
         * never the caller's description of it.
         */
        suggestDock(caller, layout) {
            const checked = checkDock(layout);
            if (!checked)
                return refusal('OS0119', 'the dock layout is refused: it does not match the dock schema');
            const manifests = kernel.modules();
            const current = arrangeDock(kernel.dock(), dockIcons(manifests), folderTitles(manifests)).layout;
            const changes = dockChanges(current, checked);
            const id = `dock-${caller}`.replace(/[^A-Za-z0-9._:-]/g, '_').slice(0, 128);
            const proposal = { id, kind: 'dock.layout', status: 'pending', payload: { layout: checked, revision: dockRevision, by: caller, changes } };
            const existing = mail.find(m => m.from === 'desktop' && m.proposal?.id === id);
            if (existing?.proposal?.status === 'deciding')
                return refusal('OS0111', 'the last suggestion is being decided');
            if (existing) {
                existing.proposal = proposal;
                existing.read = false;
                existing.at = now();
            }
            else
                mail.push({ id: `m${++mailSeq}`, at: now(), from: 'desktop', to: 'person', subject: 'dock.layout', read: false, proposal });
            emit({ kind: 'mail', module: 'desktop' });
            return { ok: true, value: { id } };
        },
        /**
         * Set a window's header bar (`null` takes it away). The header must match
         * {@link HEADER_SCHEMA} with every id used once (`OS0113`); the window
         * belongs to the module that sets it.
         */
        setHeader(module, window, header) {
            const held = headers.get(window);
            if (held && held.module !== module)
                return refusal('OS0113', `the window '${window}' belongs to '${held.module}'`);
            if (header === null) {
                if (held) {
                    headers.delete(window);
                    emit({ kind: 'header', module, window });
                }
                return { ok: true, value: {} };
            }
            headerCheck ??= new JarenValidator({ skipErrors: false, collectErrors: true, unknownFormats: 'ignore' }).compile(HEADER_SCHEMA);
            const outcome = headerCheck(header);
            if (!(typeof outcome === 'object' && outcome !== null ? outcome.valid : outcome === true)) {
                const first = (outcome?.errors ?? [])[0];
                return refusal('OS0113', `the header is refused${first ? `: ${first.instancePath || '/'} ${first.message ?? ''}`.trimEnd() : ''}`);
            }
            const twice = duplicateHeaderId(header);
            if (twice !== null)
                return refusal('OS0113', `the header is refused: the id '${twice}' is used twice`);
            headers.set(window, { module, header: cloneJson(header) });
            emit({ kind: 'header', module, window });
            return { ok: true, value: {} };
        },
        /** A window's header bar now, with its state; undefined when it has none. */
        header(window) {
            const held = headers.get(window);
            return held ? cloneJson(held.header) : undefined;
        },
        /** Every window's header bar, as `caller` sees it (`assistant: false` items are kept from all but the shell). */
        headers(caller = 'shell') {
            return [...headers].filter(([, held]) => caller !== 'assistant' || assistantMay(held.module)).map(([window, held]) => ({ window, module: held.module, header: headerFor(cloneJson(held.header), caller) }));
        },
        /** Where a window's header activations go while it can take them. Returns the release. */
        registerHeaderHandler(module, window, handle) {
            const entry = { module, handle };
            headerHandlers.set(window, entry);
            emit({ kind: 'header', module, window });
            return () => { if (headerHandlers.get(window) === entry) {
                headerHandlers.delete(window);
                emit({ kind: 'header', module, window });
            } };
        },
        /** Whether a window can take header activations now (its application is connected). */
        hasHeaderHandler(window) { return headerHandlers.has(window); },
        /**
         * Use one item of a window's header bar: the one path for the person's
         * hand (`caller` `shell`) and for every granted caller. The desktop keeps
         * the item's state (a tab, a toggle, a search text) as soon as it is
         * used, and the application's next header wins. Refused when the window
         * has no header (`OS0114`), the item is absent (`OS0114`), disabled or
         * kept from this caller (`OS0115`), the value does not fit it (`OS0116`),
         * the application is not connected (`OS0117`) or it refuses (`OS0118`).
         */
        async activateHeader(caller, window, item, value) {
            const held = headers.get(window);
            if (!held)
                return refusal('OS0114', `the window '${window}' has no header`);
            if (caller === 'assistant' && !assistantMay(held.module))
                return refusal('OS0115', `the person did not let the assistant use '${held.module}'`);
            const checked = activateHeader(held.header, caller, item, value);
            if (!checked.ok)
                return refusal(checked.code, checked.message);
            const handler = headerHandlers.get(window);
            if (!handler)
                return refusal('OS0117', `'${held.module}' is not connected to take it`);
            held.header = checked.header;
            const by = caller === 'shell' ? 'person' : caller;
            emit({ kind: 'header', module: held.module, window, item, by: caller });
            try {
                const answer = await handler.handle({ item, ...(checked.value !== undefined ? { value: checked.value } : {}), by });
                if (answer && typeof answer.refused === 'string')
                    return refusal('OS0118', answer.refused.slice(0, 400));
            }
            catch (error) {
                return refusal('OS0118', String(error?.message ?? error));
            }
            return { ok: true, value: {} };
        },
        /**
         * Serve `tangle_os` to one module over its own port. The module's id is
         * bound here, by the port it was handed, never taken from its input.
         */
        serveModule(module, port, hooks = {}) {
            const { os } = systemContracts();
            return servePortLazily(os, {
                'os.call': async ({ contract, op, input }) => kernel.call(module, contract, op, input ?? {}),
                'mail.send': ({ to, subject, body, data }) => ({ id: kernel.sendMail(module, { to, subject, body, data }).id }),
                'mail.propose': (input) => { const outcome = kernel.propose(module, input); if (!outcome.ok)
                    throw Object.assign(new Error(outcome.error.message), { code: outcome.error.code }); return outcome.value; },
                'mail.withdraw': ({ id }) => { const outcome = kernel.withdrawProposal(module, id); if (!outcome.ok)
                    throw Object.assign(new Error(outcome.error.message), { code: outcome.error.code }); return {}; },
                'window.title': ({ title }) => { hooks.setTitle?.(title); emit({ kind: 'title', module, title }); return {}; },
                'settings.get': () => ({ values: kernel.settings(module) }),
                'settings.open': () => { hooks.openSettings?.(); return {}; },
                'window.header': ({ header }) => { const outcome = kernel.setHeader(module, hooks.window ?? module, header); return outcome.ok ? {} : { refused: outcome.error }; },
            }, { channel: port });
        },
        /** Open a client on a port where a module serves one of its contracts, and make it callable. */
        connectProvider(module, contractDoc, port, timeoutMs = 10_000, owner = module) {
            mayServe(module, contractDoc?.id);
            const contract = compileContract(contractDoc);
            const client = openPortClientLazily(contract, { channel: port, timeoutMs });
            port.start?.();
            kernel.provide(module, contractDoc, client, owner);
            return client;
        },
        /**
         * Every served operation `caller` may call, as plain data (tool name,
         * contract, operation, kind, description, input and output schemas): an
         * application with its own agent runtime offers these as tools and calls
         * back through `call`, so grants and the ledger still apply.
         */
        operations(caller = 'assistant') {
            const out = [];
            for (const [id, list] of providers) {
                const ops = list.at(-1).contract.doc?.operations ?? {};
                for (const [op, spec] of Object.entries(ops))
                    if (kernel.allowed(caller, id, op))
                        out.push({ tool: toolName(id, op), contract: id, op, kind: spec?.kind ?? 'read', ...(spec?.doc ? { doc: spec.doc } : {}), ...(spec?.input ? { input: spec.input } : {}), ...(spec?.output ? { output: spec.output } : {}) });
            }
            // the kernel's own contracts, under the same grants
            for (const builtin of [HEADER_CONTRACT, DOCK_CONTRACT, FILES_CONTRACT])
                for (const [op, spec] of Object.entries(builtin.operations))
                    if (kernel.allowed(caller, builtin.id, op))
                        out.push({ tool: toolName(builtin.id, op), contract: builtin.id, op, kind: spec.kind, doc: spec.doc, input: spec.input, output: spec.output });
            return out;
        },
        /**
         * The assistant's tools: every served contract the assistant may call, as
         * model tools built by the host's tool builder, each routed through `call`
         * so grants and the ledger apply. Names are {@link toolName}.
         */
        tools(caller = 'assistant') {
            if (!options.tools)
                throw new Error('OS0301: this desktop was created without a tool builder (createKernel({ tools }))');
            const toolbox = options.tools.createToolbox();
            for (const [id, list] of providers) {
                const provider = list.at(-1);
                const ops = Object.keys(provider.contract.doc?.operations ?? {}).filter(op => kernel.allowed(caller, id, op));
                if (ops.length === 0)
                    continue;
                const client = { invoke: (op, input) => kernel.call(caller, id, op, input) };
                options.tools.toolboxFromContract(provider.contract, client, { toolbox, ops, name: (op) => toolName(id, op) });
            }
            headerContract ??= compileContract(HEADER_CONTRACT);
            dockContract ??= compileContract(DOCK_CONTRACT);
            filesContract ??= compileContract(FILES_CONTRACT);
            for (const [doc, compiled] of [[HEADER_CONTRACT, headerContract], [DOCK_CONTRACT, dockContract], [FILES_CONTRACT, filesContract]]) {
                const ops = Object.keys(doc.operations).filter(op => kernel.allowed(caller, doc.id, op));
                if (!ops.length)
                    continue;
                const client = { invoke: (op, input) => kernel.call(caller, doc.id, op, input) };
                options.tools.toolboxFromContract(compiled, client, { toolbox, ops, name: (op) => toolName(doc.id, op) });
            }
            return toolbox;
        },
        subscribe(listener) { listeners.add(listener); return () => listeners.delete(listener); },
    };
    // a store the host passed loads at once; an application that serves the state loads it when it connects
    if (activeStore && options.state)
        void loadState(activeStore);
    return kernel;
}
