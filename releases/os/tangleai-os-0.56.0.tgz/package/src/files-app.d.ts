/**
 * The desktop's Files: every file location in one window. The sidebar lists
 * the locations (the person's own "This browser" when the host offers it,
 * then each application's), the window's header bar carries back, forward,
 * up, the search and the menu, and the pane shows a folder. A file opens in a
 * preview beside it: an image as an image, a PDF in the browser's own viewer,
 * text as text, and Markdown or any other type through a previewer the host
 * passes. Nothing a file holds ever runs as the desktop's own markup.
 *
 * Everything Files does goes through the location's contract as the person's
 * own hand (`shell`), into the ledger; the assistant reads files only through
 * the kernel's `tangle_os_files`.
 */
import { type ModuleManifest } from './manifest.ts';
import { type OsCatalogue } from './messages.ts';
import { type FileEntry, type FileLocationHandlers } from './files.ts';
import type { Kernel } from './kernel.ts';
import type { ShippedMount } from './shell.ts';
/** Draws a preview of a file into `node` (Markdown, say), or answers false to leave it to the next. */
export type FilePreviewer = (node: HTMLElement, file: {
    entry: FileEntry;
    bytes: Uint8Array;
    text: () => string;
}) => boolean | void;
export type FilesOptions = {
    kernel: Kernel;
    /**
     * The person's own files in this browser, when the host offers them: the
     * handlers of a location (`browserLocation` over a directory of the
     * browser's file system the host set aside for them, never its root). A
     * host whose state lives on its server leaves this out.
     */
    browser?: FileLocationHandlers;
    /** Previewers for types the desktop does not draw itself, tried in order before plain text. */
    previewers?: FilePreviewer[];
    messages?: Partial<OsCatalogue>;
    id?: string;
};
export declare const BROWSER_LOCATION = "tangle_os_files_browser";
/** The Files module: its manifest, its mount, and `serve` (call once it is installed) for "This browser". */
export declare function filesModule(options: FilesOptions): {
    manifest: ModuleManifest;
    mount: ShippedMount;
    serve(): void;
};
