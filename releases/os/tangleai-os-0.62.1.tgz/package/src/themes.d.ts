/**
 * Theme kits: each a complete look, as one JSON document — palettes for light
 * and dark, a procedural wallpaper, and a shape (corners, glass, spacing). A
 * person picks a kit and adjusts any part of it; the result is an ordinary
 * theme document, so it can be exported, shared and imported as text.
 */
import { type ThemeDocument } from './theme.ts';
export type Corners = 'sharp' | 'soft' | 'round';
export type Spacing = 'compact' | 'comfortable';
export type ThemeKit = {
    $themekit: '0.1';
    id: string;
    name: string;
    description: string;
    pattern: string;
    shape: {
        corners: Corners;
        glass: number;
        spacing: Spacing;
    };
    light: Record<string, string>;
    dark: Record<string, string>;
};
/** What a person changed on top of a kit; every member is optional. */
export type ThemeCustom = Partial<{
    accent: string;
    knot: string;
    pattern: string;
    seed: number;
    density: number;
    glass: number;
    corners: Corners;
    spacing: Spacing;
}>;
export declare const THEME_KITS: ThemeKit[];
/** The theme document for a kit, a scheme and a person's changes. Invalid changes are ignored, never applied. */
export declare function composeTheme(kitId: string, scheme: 'light' | 'dark', custom?: ThemeCustom): ThemeDocument;
