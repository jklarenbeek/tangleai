/** The desktop's sentences in Russian, formal (`вы`), key for key with the English catalogue: pass it as `messages` to the shell, Settings and Files. */
import type { OsCatalogue } from '../messages.ts';
export declare const ru: OsCatalogue;
