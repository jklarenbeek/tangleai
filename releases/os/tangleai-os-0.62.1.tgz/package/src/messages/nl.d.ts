/** The desktop's sentences in Dutch, formal (`u`), key for key with the English catalogue: pass it as `messages` to the shell, Settings and Files. */
import type { OsCatalogue } from '../messages.ts';
export declare const nl: OsCatalogue;
