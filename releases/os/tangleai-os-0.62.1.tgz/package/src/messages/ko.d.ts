/** The desktop's sentences in Korean, formal (-ㅂ니다/-습니다, requests in -세요), key for key with the English catalogue, with no sound-dependent particle (을/를, 이/가) attached to interpolated text: pass it as `messages` to the shell, Settings and Files. */
import type { OsCatalogue } from '../messages.ts';
export declare const ko: OsCatalogue;
