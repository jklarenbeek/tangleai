/** The desktop's sentences in Spanish, formal (`usted`) and neutral across Spain and Latin America, key for key with the English catalogue: pass it as `messages` to the shell, Settings and Files. */
import type { OsCatalogue } from '../messages.ts';
export declare const es: OsCatalogue;
