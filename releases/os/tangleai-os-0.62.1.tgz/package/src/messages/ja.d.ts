/** The desktop's sentences in Japanese, polite (です・ます), key for key with the English catalogue: pass it as `messages` to the shell, Settings and Files. */
import type { OsCatalogue } from '../messages.ts';
export declare const ja: OsCatalogue;
