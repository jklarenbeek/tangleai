/** The desktop's sentences in Modern Standard Arabic, formal, key for key with the English catalogue: pass it as `messages` to the shell, Settings and Files (the layout mirrors right-to-left elsewhere; these are plain text). */
import type { OsCatalogue } from '../messages.ts';
export declare const ar: OsCatalogue;
