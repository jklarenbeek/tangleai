/** The desktop's sentences in Traditional Chinese as written in Taiwan, formal (`您`), key for key with the English catalogue: pass it as `messages` to the shell, Settings and Files. */
import type { OsCatalogue } from '../messages.ts';
export declare const zhTW: OsCatalogue;
