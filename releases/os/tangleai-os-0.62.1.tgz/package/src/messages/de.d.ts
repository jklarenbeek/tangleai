/** The desktop's sentences in German, formal (`Sie`), key for key with the English catalogue: pass it as `messages` to the shell, Settings and Files. */
import type { OsCatalogue } from '../messages.ts';
export declare const de: OsCatalogue;
