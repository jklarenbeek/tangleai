/** The desktop's sentences in Turkish, formal (`siz`; buttons keep the bare verb), key for key with the English catalogue: pass it as `messages` to the shell, Settings and Files. A case suffix is attached to a fixed word, never to interpolated text. */
import type { OsCatalogue } from '../messages.ts';
export declare const tr: OsCatalogue;
