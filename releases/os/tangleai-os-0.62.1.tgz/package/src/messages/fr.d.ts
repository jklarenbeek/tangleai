/** The desktop's sentences in French, formal (`vous`), key for key with the English catalogue: pass it as `messages` to the shell, Settings and Files. A no-break space precedes the colon and the question mark, as French typography sets them. */
import type { OsCatalogue } from '../messages.ts';
export declare const fr: OsCatalogue;
