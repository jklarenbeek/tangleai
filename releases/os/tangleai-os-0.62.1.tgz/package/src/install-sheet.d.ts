/**
 * The install sheet: what a person sees before applications from a suite
 * document join their desktop. A link names the suite; nothing installs until
 * the person adds it here. Each application shows where its pages come from,
 * the contracts it provides, what it asks to use (each a choice) and whether
 * the assistant may use it (off until they say so). An application on this
 * device or the local network says that the browser may ask about it first.
 * The sheet asks only for what is new: an application joined before is
 * updated quietly unless it now asks for more or comes from another origin.
 */
import { type LocalizedText } from './manifest.ts';
import type { OsMessageKey } from './messages.ts';
import type { Kernel } from './kernel.ts';
/** A suite document: the applications one source offers a desktop. */
export type SuiteDocument = {
    $suite: '0.1';
    id: string;
    title?: LocalizedText;
    modules: unknown[];
};
/** What became of each application a suite offered. */
export type JoinResult = {
    /** Added or changed by the person's choice in the sheet. */
    installed: string[];
    /** Left out by the person (unticked, or the sheet cancelled). */
    declined: string[];
    /** Already on the desktop as allowed: updated without asking, or kept by the host. */
    unchanged: string[];
    /** Not valid, or refused by the kernel. */
    refused: {
        id: string;
        message: string;
    }[];
};
type Context = {
    kernel: Kernel;
    doc: Document;
    node: HTMLElement;
    locale: string;
    t: (key: OsMessageKey, values?: Record<string, string | number>) => string;
    desktopOrigin: string | null;
};
/** Join a suite's applications, asking the person for what is new. */
export declare function joinSuite(ctx: Context, suite: SuiteDocument, source?: string): Promise<JoinResult>;
export {};
