/**
 * A theme is a document of token values: Jaren's host vocabulary (so every
 * Jaren component inside a window follows it) plus the desktop's own tokens.
 * Values are checked before they reach a style: a theme cannot carry a URL to
 * a foreign origin, a script or an `expression()`; appearance stays CSS.
 */
export type ThemeDocument = {
    $theme: '0.1';
    name: string;
    scheme: 'light' | 'dark';
    tokens: Record<string, string>;
};
/** The previous gradient wallpapers, kept for people who chose them. */
export declare const AURORA: {
    light: string;
    dark: string;
};
export declare const DEFAULT_THEMES: Record<'light' | 'dark', ThemeDocument>;
/** Check a theme's token values; returns the problems, empty when safe to apply. */
export declare function checkTheme(theme: ThemeDocument): string[];
