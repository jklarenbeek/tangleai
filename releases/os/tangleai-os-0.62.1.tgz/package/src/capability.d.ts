/**
 * Capabilities: what an application's domain offers the assistant and the
 * inbox, declared as data instead of hand-kept lists. A capability names its
 * contract documents (the assistant's tools come from them), the reads that
 * give the assistant its context (read operations of those contracts), the
 * kinds of proposal the domain files with each kind's review policy, and a
 * prompt pack in the person's languages. One capability serves every module of
 * its domain: a module's manifest names the capabilities it files for, and
 * the kernel takes the kinds and their policies from there.
 *
 * A review policy says which origins may file a kind (`human`, `rule`,
 * `import`, `ai`), which the kernel enforces, and which roles may decide it,
 * which the desktop shows and hands to the module with the decision: the
 * owner knows who the person is and re-checks before it applies.
 */
import { type LocalizedText } from './manifest.ts';
export type CapabilityOrigin = 'human' | 'rule' | 'import' | 'ai';
export type CapabilityDocument = {
    $capability: '0.1';
    id: string;
    title: LocalizedText;
    contracts: {
        $contract: string;
        id: string;
        operations: Record<string, any>;
        [member: string]: unknown;
    }[];
    context?: {
        id: string;
        contract: string;
        op: string;
        input?: Record<string, unknown>;
        title?: LocalizedText;
    }[];
    proposals?: {
        kind: string;
        title: LocalizedText;
        review?: {
            origins?: CapabilityOrigin[];
            roles?: string[];
        };
    }[];
    prompts: {
        en: CapabilityPrompt;
    } & Partial<Record<string, CapabilityPrompt>>;
};
/** One language of a prompt pack: what the assistant is told about the domain, and about each kind it may propose. */
export type CapabilityPrompt = {
    system: string;
    kinds?: Record<string, string>;
};
/** The capability document: bounded, closed JSON. */
export declare const CAPABILITY_SCHEMA: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly required: readonly ["$capability", "id", "title", "contracts", "prompts"];
    readonly properties: {
        readonly $capability: {
            readonly const: "0.1";
        };
        readonly id: {
            readonly type: "string";
            readonly pattern: "^[a-z][a-z0-9-]{0,63}$";
        };
        readonly title: {
            type: string;
            required: string[];
            additionalProperties: {
                type: string;
                maxLength: number;
            };
            properties: {
                en: {
                    type: string;
                    minLength: number;
                    maxLength: number;
                };
            };
        };
        readonly contracts: {
            readonly type: "array";
            readonly maxItems: 16;
            readonly items: {
                readonly type: "object";
                readonly required: readonly ["$contract", "id", "operations"];
                readonly properties: {
                    readonly $contract: {
                        readonly type: "string";
                    };
                    readonly id: {
                        readonly type: "string";
                        readonly pattern: "^[A-Za-z_][A-Za-z0-9_-]*$";
                    };
                    readonly operations: {
                        readonly type: "object";
                    };
                };
            };
        };
        readonly context: {
            readonly type: "array";
            readonly maxItems: 16;
            readonly items: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["id", "contract", "op"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                        readonly pattern: "^[A-Za-z][A-Za-z0-9_-]{0,63}$";
                    };
                    readonly contract: {
                        readonly type: "string";
                    };
                    readonly op: {
                        readonly type: "string";
                        readonly maxLength: 128;
                    };
                    readonly input: {
                        readonly type: "object";
                    };
                    readonly title: {
                        type: string;
                        required: string[];
                        additionalProperties: {
                            type: string;
                            maxLength: number;
                        };
                        properties: {
                            en: {
                                type: string;
                                minLength: number;
                                maxLength: number;
                            };
                        };
                    };
                };
            };
        };
        readonly proposals: {
            readonly type: "array";
            readonly maxItems: 32;
            readonly items: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["kind", "title"];
                readonly properties: {
                    readonly kind: {
                        readonly type: "string";
                        readonly pattern: "^[a-z][a-z0-9.-]{0,63}$";
                    };
                    readonly title: {
                        type: string;
                        required: string[];
                        additionalProperties: {
                            type: string;
                            maxLength: number;
                        };
                        properties: {
                            en: {
                                type: string;
                                minLength: number;
                                maxLength: number;
                            };
                        };
                    };
                    readonly review: {
                        readonly type: "object";
                        readonly additionalProperties: false;
                        readonly properties: {
                            readonly origins: {
                                readonly type: "array";
                                readonly minItems: 1;
                                readonly uniqueItems: true;
                                readonly items: {
                                    readonly enum: readonly ["human", "rule", "import", "ai"];
                                };
                            };
                            readonly roles: {
                                readonly type: "array";
                                readonly maxItems: 16;
                                readonly uniqueItems: true;
                                readonly items: {
                                    readonly type: "string";
                                    readonly pattern: "^[A-Za-z0-9._:-]{1,64}$";
                                };
                            };
                        };
                    };
                };
            };
        };
        readonly prompts: {
            readonly type: "object";
            readonly required: readonly ["en"];
            readonly maxProperties: 12;
            readonly propertyNames: {
                readonly pattern: "^[a-z]{2}(-[A-Z]{2})?$";
            };
            readonly additionalProperties: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    system: {
                        type: string;
                        minLength: number;
                        maxLength: number;
                    };
                    kinds: {
                        type: string;
                        maxProperties: number;
                        propertyNames: {
                            pattern: string;
                        };
                        additionalProperties: {
                            type: string;
                            maxLength: number;
                        };
                    };
                };
            };
            readonly properties: {
                readonly en: {
                    type: string;
                    additionalProperties: boolean;
                    required: string[];
                    properties: {
                        system: {
                            type: string;
                            minLength: number;
                            maxLength: number;
                        };
                        kinds: {
                            type: string;
                            maxProperties: number;
                            propertyNames: {
                                pattern: string;
                            };
                            additionalProperties: {
                                type: string;
                                maxLength: number;
                            };
                        };
                    };
                };
            };
        };
    };
};
export type CapabilityIssue = {
    code: string;
    path: string;
    message: string;
};
/**
 * What the schema cannot say: every context read is a read operation of one
 * of the capability's own contracts, every kind is named once, and a prompt
 * for a kind names a kind the capability files.
 */
export declare function capabilityIssues(doc: CapabilityDocument): CapabilityIssue[];
/**
 * Whether a set of capabilities and the manifests that name them agree: each
 * named capability is installed, and each proposal kind is declared once
 * across the capabilities and the modules' own `proposals`.
 */
export declare function checkCapabilities(capabilities: readonly CapabilityDocument[], manifests: readonly {
    id: string;
    capabilities?: string[];
    proposals?: {
        kind: string;
    }[];
}[]): CapabilityIssue[];
/** A capability's prompt in a language: that language's, else English. */
export declare function capabilityPrompt(doc: CapabilityDocument, locale: string): CapabilityPrompt;
/**
 * The assistant's system text for a set of capabilities, in the person's
 * language: each capability's title and prompt, then what it may propose,
 * in the order given. Deterministic, so a prompt pack's change is visible as
 * a text change; it reads nothing and runs nothing.
 */
export declare function capabilitiesPrompt(capabilities: readonly CapabilityDocument[], locale?: string): string;
/**
 * Compose what a set of capabilities gives an assistant: its system text, a
 * toolbox of every contract's operations (through the host's tool builder and
 * clients, so the kernel's grants or the server's own checks apply), and a
 * reader that runs every declared context read through the host's `call`.
 */
export declare function composeCapabilities(capabilities: readonly CapabilityDocument[], options?: {
    locale?: string;
    tools?: {
        createToolbox: () => any;
        toolboxFromContract: (contract: any, client: {
            invoke: (op: string, input: unknown) => Promise<unknown>;
        }, options: {
            toolbox: any;
            ops: string[];
            name: (op: string) => string;
        }) => unknown;
    };
    compile?: (contract: unknown) => any;
    client?: (contract: string) => {
        invoke: (op: string, input: unknown) => Promise<unknown>;
    };
    call?: (contract: string, op: string, input: unknown) => Promise<unknown>;
}): {
    system: string;
    toolbox: unknown;
    kinds: {
        capability: string;
        kind: string;
        origins: CapabilityOrigin[] | null;
        roles: string[];
    }[];
    context: () => Promise<Record<string, unknown>>;
};
