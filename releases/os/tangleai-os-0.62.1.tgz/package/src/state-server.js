/**
 * The table the documents live in, as a `@jarenjs/db` model document: one
 * collection keyed by `<owner>\u0000<scope>\u0000<key>`, read by owner.
 */
export const DESKTOP_STATE_MODEL = {
    $model: '0.1',
    collections: {
        desktop_state: {
            schema: {
                type: 'object', additionalProperties: false, required: ['id', 'owner', 'scope', 'key', 'value', 'revision', 'updatedAt'],
                properties: {
                    id: { type: 'string', maxLength: 600 },
                    owner: { type: 'string', maxLength: 200 },
                    scope: { enum: ['person', 'application'] },
                    key: { type: 'string', maxLength: 200 },
                    value: {},
                    revision: { type: 'integer', minimum: 1 },
                    updatedAt: { type: 'string', format: 'date-time' },
                },
            },
            key: '/id',
            indexes: [{ name: 'by_owner', path: ['$.owner', '$.scope'] }],
        },
    },
};
/** The row's id in {@link DESKTOP_STATE_MODEL}. */
export const stateRowId = (owner, scope, key) => `${owner}\u0000${scope}\u0000${key}`;
/** Whose a document is: the person's id for `person`, the application's (tenant's) for `application`. */
export const ownerOf = (owner, scope) => scope === 'person' ? `person:${owner.person}` : `application:${owner.application}`;
/** A repository in memory: for tests, and the shape a database repository follows. */
export function memoryStateRepository(now = () => new Date().toISOString()) {
    const rows = new Map();
    return {
        async list(owner) {
            return [...rows.values()]
                .filter(r => r.owner === ownerOf(owner, r.scope))
                .map(r => ({ scope: r.scope, key: r.key, value: structuredClone(r.value), revision: r.revision }));
        },
        async swap(owner, document, ifRevision) {
            const who = ownerOf(owner, document.scope), id = stateRowId(who, document.scope, document.key), current = rows.get(id);
            if ((current?.revision ?? 0) !== ifRevision) {
                return { conflict: current ? { scope: current.scope, key: current.key, value: structuredClone(current.value), revision: current.revision } : { ...document, value: null, revision: 0 } };
            }
            const revision = ifRevision + 1;
            if (document.value === null)
                rows.delete(id);
            else
                rows.set(id, { owner: who, scope: document.scope, key: document.key, value: structuredClone(document.value), revision, updatedAt: now() });
            return { revision };
        },
        rows: () => [...rows.values()].map(r => structuredClone(r)),
    };
}
/**
 * The `tangle_os_state` handlers over a repository. `owner` answers who is
 * signed in for a call (from the request's session); it throws to refuse a
 * caller that is not.
 */
export function serveDesktopState(repository, owner) {
    return {
        'state.load': async (_input, context) => ({ documents: await repository.list(owner(context)) }),
        'state.save': async ({ scope, key, value, ifRevision }, context) => repository.swap(owner(context), { scope, key, value }, ifRevision),
    };
}
