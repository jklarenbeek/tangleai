/**
 * A loader that fetches once and keeps what arrived, but not a failure: the
 * next framed window, or a Retry, fetches again.
 */
export function portLoader(load) {
    let loaded = null;
    let loading = null;
    return {
        load() {
            loading ??= load().then((module) => (loaded = module), (error) => { loading = null; throw error; });
            return loading;
        },
        get: () => loaded,
    };
}
const shared = portLoader(() => import('@jarenjs/contract/port'));
/** Start loading the port transport (once) and resolve when it is there. */
export function loadPorts() { return shared.load(); }
/** Whether the port transport has been loaded. */
export function portsLoaded() { return shared.get() !== null; }
/**
 * A stand-in for `port` that holds what arrives until a listener attaches,
 * then forwards everything, held messages first. Sending goes straight to the
 * real port.
 */
function heldChannel(port) {
    const held = [];
    const listeners = new Set();
    const forward = (event) => { if (listeners.size)
        for (const l of listeners)
            l(event);
    else
        held.push(event); };
    port.addEventListener('message', forward);
    port.start?.();
    return {
        postMessage: (...args) => port.postMessage(...args),
        addEventListener(type, listener) {
            if (type !== 'message')
                return port.addEventListener(type, listener);
            listeners.add(listener);
            for (const event of held.splice(0))
                for (const l of listeners)
                    l(event);
        },
        removeEventListener(type, listener) {
            if (type !== 'message')
                return port.removeEventListener(type, listener);
            listeners.delete(listener);
        },
        start() { },
        close() { port.removeEventListener('message', forward); held.length = 0; listeners.clear(); },
    };
}
/** Serve `contract` on `options.channel`, now when the transport is loaded, else as soon as it is. */
export function servePortLazily(contract, handlers, options) {
    const ports = shared.get();
    if (ports)
        return ports.servePort(contract, handlers, options);
    const channel = heldChannel(options.channel);
    let served = null;
    let closed = false;
    loadPorts().then((loaded) => {
        if (closed)
            return;
        served = loaded.servePort(contract, handlers, { ...options, channel });
    }, () => { });
    return { close() { closed = true; served?.close?.(); channel.close(); } };
}
/** Open a client on `options.channel`; its calls wait for the transport if it is still loading. */
export function openPortClientLazily(contract, options) {
    const ports = shared.get();
    if (ports)
        return ports.openPortClient(contract, options);
    let client = null;
    let closed = false;
    const ready = loadPorts().then((loaded) => {
        if (!closed)
            client = loaded.openPortClient(contract, options);
        return client;
    });
    ready.catch(() => { });
    const lazy = {
        invoke: async (op, input, callOptions) => {
            const c = client ?? await ready;
            if (!c)
                throw new Error('the client was closed before the port transport loaded');
            return c.invoke(op, input, callOptions);
        },
        close: () => { closed = true; client?.close?.(); },
    };
    return lazy;
}
