/**
 * The desktop's state: everything the desktop keeps for a person or for the
 * application (the dock, each application's settings values, the host's own
 * preferences) as keyed JSON documents in one store the host chooses. In a
 * browser-only page that is the browser's storage; in an application with a
 * server it is that server's database, through the `tangle_os_state`
 * contract, so a person's desktop follows them to another device. Secrets
 * never go here: a provider key stays with the host.
 *
 * Every document has a revision. A save names the revision it was made on and
 * is refused when the stored one moved (another tab, another device): the
 * desktop then takes the stored document, so nothing is overwritten unseen.
 */
/** Whose a document is: the signed-in person's, or the whole application's (decided by the server, never the caller). */
export type StateScope = 'person' | 'application';
export type StateDocument = {
    scope: StateScope;
    key: string;
    value: unknown;
    revision: number;
};
/**
 * Where a desktop keeps its state. `load` answers every document the
 * desktop may read; `save` stores one when its revision is still `ifRevision`
 * (0 for a document that does not exist yet) and answers the new revision, or
 * the stored document when it moved. A `value` of null deletes the document.
 */
export type DesktopStore = {
    load(): Promise<StateDocument[]>;
    save(document: {
        scope: StateScope;
        key: string;
        value: unknown;
    }, ifRevision: number): Promise<{
        revision: number;
    } | {
        conflict: StateDocument;
    }>;
};
/** `tangle_os_state`: the desktop's state, served by the host's backend (or by the application that is signed in). */
export declare const STATE_CONTRACT: {
    readonly $contract: "0.1";
    readonly id: "tangle_os_state";
    readonly operations: {
        readonly 'state.load': {
            readonly kind: "read";
            readonly doc: "Every desktop document the signed-in person may read: their own (scope person) and the application's (scope application).";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly properties: {};
            };
            readonly output: {
                readonly type: "object";
                readonly required: readonly ["documents"];
                readonly properties: {
                    readonly documents: {
                        readonly type: "array";
                        readonly maxItems: 2000;
                        readonly items: {
                            type: string;
                            additionalProperties: boolean;
                            required: string[];
                            properties: {
                                scope: {
                                    enum: string[];
                                };
                                key: {
                                    type: string;
                                    pattern: string;
                                };
                                value: {};
                                revision: {
                                    type: string;
                                    minimum: number;
                                };
                            };
                        };
                    };
                };
            };
        };
        readonly 'state.save': {
            readonly kind: "command";
            readonly doc: "Store one document if its stored revision is still ifRevision (0 when it does not exist); null deletes it. Answers the new revision, or the stored document when it moved.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["scope", "key", "value", "ifRevision"];
                readonly properties: {
                    readonly scope: {
                        enum: string[];
                    };
                    readonly key: {
                        type: string;
                        pattern: string;
                    };
                    readonly value: {};
                    readonly ifRevision: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly properties: {
                    readonly revision: {
                        readonly type: "integer";
                    };
                    readonly conflict: {
                        type: string;
                        additionalProperties: boolean;
                        required: string[];
                        properties: {
                            scope: {
                                enum: string[];
                            };
                            key: {
                                type: string;
                                pattern: string;
                            };
                            value: {};
                            revision: {
                                type: string;
                                minimum: number;
                            };
                        };
                    };
                };
            };
        };
    };
};
/** A store that lives as long as the page: the default, and the shape of a test double. */
export declare function memoryStore(initial?: StateDocument[]): DesktopStore & {
    documents(): StateDocument[];
};
/**
 * A browser's storage as the store (one entry per document under `prefix`):
 * for a page with no server of its own. Other tabs of the same page share it.
 */
export declare function webStorageStore(storage: {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
    key(index: number): string | null;
    readonly length: number;
}, prefix?: string): DesktopStore;
/** The store as a `tangle_os_state` client: over HTTP to the host's server, or over a port to the application that serves it. */
export declare function contractStore(client: {
    invoke(op: string, input: unknown): Promise<any>;
}): DesktopStore;
