/**
 * Apply the desktop's theme and language to a root element: shared by the
 * shell and a joined module page, and free of any transport.
 */
/** Set token values as custom properties on a root element, and the colour scheme. */
export declare function applyTheme(root: any, theme: {
    tokens: Record<string, string>;
    scheme?: 'light' | 'dark';
}): void;
export declare function applyLocale(root: any, locale: {
    locale: string;
    dir: 'ltr' | 'rtl';
}): void;
