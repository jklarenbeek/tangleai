import { type LocalizedText, type ModuleManifest } from './manifest.ts';
import { type OsCatalogue } from './messages.ts';
import type { Kernel } from './kernel.ts';
import type { ShippedContext, ShippedMount } from './shell.ts';
/** What the shell calls to show a section: `module:<id>` for a module's, a host section's own id otherwise. */
export declare const SETTINGS_CONTRACT: {
    readonly $contract: "0.1";
    readonly id: "tangle_os_settings";
    readonly operations: {
        readonly 'settings.show': {
            readonly kind: "command";
            readonly doc: "Show a section of the desktop's Settings.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["section"];
                readonly properties: {
                    readonly section: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 200;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
            };
        };
    };
};
/** A host's own section: its id stays stable (a deep link, a test), its title is localized. */
export type SettingsSection = {
    id: string;
    title: LocalizedText;
    keywords?: string[];
    mount: (node: HTMLElement, context: ShippedContext) => (() => void) | void;
};
export type SettingsOptions = {
    kernel: Kernel;
    /** The host's shipped mounts, where a `mount` module's settings screen is found. */
    shipped?: Record<string, ShippedMount>;
    /** The host's own sections, first, in this order. */
    sections?: SettingsSection[];
    /** The section shown when Settings opens without one; the first by default. */
    initial?: () => string;
    /** How long a settings page has to say hello (15 s by default). */
    connectTimeoutMs?: number;
    messages?: Partial<OsCatalogue>;
    /** The language `messages` is in: the desktop's own title of Settings. */
    locale?: string;
    /** The module id of Settings itself (`settings` by default). */
    id?: string;
};
/** The Settings module: its manifest for the kernel and its mount for the shell. */
export declare function settingsModule(options: SettingsOptions): {
    manifest: ModuleManifest;
    mount: ShippedMount;
};
