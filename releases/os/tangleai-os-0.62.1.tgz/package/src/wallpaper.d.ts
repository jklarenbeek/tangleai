/**
 * The desktop's default wallpaper: threads woven across the screen, drawn as
 * an SVG from a seed and the theme's thread colours. Deterministic (the same
 * seed draws the same weave), resolution-independent and cheap: one string,
 * built once per theme.
 */
export type WeaveOptions = {
    seed?: number;
    threads?: number;
    ground: [string, string];
    colours: string[];
    knot: string;
};
export declare function weaveSvg(options: WeaveOptions): string;
/** The weave as a CSS background value. */
export declare function weaveBackground(options: WeaveOptions): string;
/** What every generator draws with: a seed, a density (0.3–2) and the theme's colours. */
export type PatternOptions = {
    seed: number;
    density: number;
    ground: [string, string];
    ink: [string, string, string];
    mark: string;
};
/** Every procedural wallpaper the desktop can draw, by name. */
export declare const PATTERNS: Record<string, (o: PatternOptions) => string>;
/** The wallpaper a theme's tokens ask for, as a CSS background value, or null when it is plain CSS. */
export declare function patternBackground(tokens: Record<string, string>): string | null;
