import type { OsMessageKey } from './messages.ts';
import type { Kernel } from './kernel.ts';
type Context = {
    kernel: Kernel;
    doc: Document;
    locale: string;
    t: (key: OsMessageKey, values?: Record<string, string | number>) => string;
    self: string;
};
export declare function mountAccess(pane: HTMLElement, ctx: Context): () => void;
export {};
