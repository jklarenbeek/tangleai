/**
 * Consent for applications a person joins: what an install sheet showed them
 * and what they allowed. A suite reached by a link installs nothing by itself;
 * the person sees each application's origin, the contracts it provides, what
 * it asks to use and whether the assistant may use it, and the kernel keeps
 * exactly that. When a later suite document asks for more than was shown (a
 * scope, a contract, another origin), the person is asked again; nothing
 * widens silently.
 */
import type { ModuleManifest } from './manifest.ts';
/** What a person allowed one joined application, bound to what they were shown. */
export type Consent = {
    /** The suite document the application came from, when it came from one. */
    source?: string;
    /** The origin its pages are served from (`null` for a document module). */
    origin: string | null;
    /** The scopes the sheet offered (`contract.op` or `contract.*`) and the ones the person allowed. */
    offered: string[];
    scopes: string[];
    /** The contracts it provides as shown; the assistant reaches these only with `assistant`. */
    provides: string[];
    assistant: boolean;
    at: number;
};
/** An application the person installed, as kept in their state: its manifest and their consent. */
export type InstalledApp = {
    manifest: ModuleManifest;
    consent: Consent;
};
/** The person's state document of joined applications. */
export declare const APPS_KEY = "apps";
/** The scopes a manifest asks for: one per named operation, or the whole contract. */
export declare function scopesOf(manifest: Pick<ModuleManifest, 'requires'>): string[];
/** Where a manifest's pages come from: an origin, or null for a document module. */
export declare function originOf(manifest: Pick<ModuleManifest, 'host'>): string | null;
/** Whether an origin is on this device or the local network, where a browser may ask the person first. */
export declare function isLocalOrigin(origin: string | null): boolean;
/**
 * Whether installing `manifest` needs the person's consent, against what they
 * allowed before: none kept (`new`), another origin (`origin`), or a scope or
 * contract they were not shown (`more`, with what is new).
 */
export declare function consentNeeded(manifest: ModuleManifest, before: Consent | null): {
    needed: false;
} | {
    needed: true;
    reason: 'new' | 'origin' | 'more';
    scopes: string[];
    provides: string[];
};
