/** The origin rule for framed applications, apart from the DOM shell so a headless check can use it. */
/**
 * Why an application page may not be framed as an origin module, or null.
 * A page on the desktop's own origin would be framed with that origin's
 * rights and could read the desktop's storage and keys (all project sites of
 * one GitHub Pages account share an origin), so it is refused.
 */
export declare function originHostProblem(url: string, desktopOrigin: string | undefined): string | null;
