/**
 * Window state as a JSON document with pure transitions: what is open, where,
 * in which order, and which window has focus. The shell renders it; the tests
 * drive it headless. Nothing here touches the DOM.
 */
export type Rect = {
    x: number;
    y: number;
    w: number;
    h: number;
};
export type WindowState = {
    id: string;
    module: string;
    title: string;
    rect: Rect;
    /** The rect to return to from maximized. */
    restore?: Rect;
    z: number;
    minimized: boolean;
    maximized: boolean;
    /** The smallest size the person may resize it to: the manifest's `minWidth` and `minHeight`. */
    min?: {
        w: number;
        h: number;
    };
    /** Maximized by the compact desktop, not by the person: restored when the desktop is wide again. */
    compacted?: boolean;
};
/**
 * `compact`: a narrow desktop (a phone): every window is maximized and only
 * the focused one is shown; the host decides the width (see the shell's
 * `compact` option).
 */
export type Desktop = {
    windows: WindowState[];
    focus: string | null;
    nextId: number;
    viewport: {
        w: number;
        h: number;
    };
    compact?: boolean;
};
export type WindowRequest = {
    module: string;
    title: string;
    width?: number;
    height?: number;
    minWidth?: number;
    minHeight?: number;
    singleton?: boolean;
};
export declare const emptyDesktop: (viewport?: {
    w: number;
    h: number;
}) => Desktop;
export declare function fit(rect: Rect, viewport: Desktop['viewport'], min?: {
    w: number;
    h: number;
}): Rect;
/**
 * Open a window, or focus the existing one of a single-instance module. New
 * windows cascade, sized to the desktop and placed wholly on it; on a compact
 * desktop they open maximized.
 */
export declare function openWindow(d: Desktop, request: WindowRequest): Desktop;
export declare function focusWindow(d: Desktop, id: string): Desktop;
export declare function closeWindow(d: Desktop, id: string): Desktop;
export declare function moveWindow(d: Desktop, id: string, x: number, y: number): Desktop;
/** Resize, never below the window's own minimum (its manifest's `minWidth` and `minHeight`) unless `min` says otherwise. */
export declare function resizeWindow(d: Desktop, id: string, width: number, height: number, min?: {
    w: number;
    h: number;
}): Desktop;
/** Maximize or restore; on a compact desktop every window stays maximized. */
export declare function toggleMaximize(d: Desktop, id: string): Desktop;
/**
 * Enter or leave the compact desktop: entering maximizes every window the
 * person had not maximized (marked `compacted`), leaving restores exactly those.
 */
export declare function setCompact(d: Desktop, compact: boolean): Desktop;
/**
 * A new desktop size, compact or not: entering compact happens before the
 * windows are fitted to the narrower desktop, so each keeps the place and size
 * it returns to.
 */
export declare function resizeDesktop(d: Desktop, viewport: Desktop['viewport'], compact?: boolean): Desktop;
/** Whether a window is on screen: not minimized, and on a compact desktop the focused one. */
export declare const isVisible: (d: Desktop, w: WindowState) => boolean;
export declare function minimizeWindow(d: Desktop, id: string): Desktop;
export declare function setTitle(d: Desktop, id: string, title: string): Desktop;
/** A new viewport keeps every window reachable and maximized windows full size. */
export declare function setViewport(d: Desktop, viewport: Desktop['viewport']): Desktop;
/** Windows in stacking order, bottom first. */
export declare const stacked: (d: Desktop) => WindowState[];
