/**
 * The server side of the desktop's state, for an application whose desktop
 * keeps its state in the application's own database. The application serves
 * `tangle_os_state` (over HTTP to its desktop page, or from its framed page
 * over the port the desktop handed it) with {@link serveDesktopState}, over a
 * repository on its own storage: a table made from
 * {@link DESKTOP_STATE_MODEL} by `@jarenjs/db` (SQLite or PostgreSQL alike),
 * or any store that can compare and set one row.
 *
 * Who owns a document is the server's to say, from its own session: a
 * person's documents (`scope: person`) belong to the signed-in person, the
 * application's (`scope: application`) to the tenant, and the caller never
 * names an owner. Nothing here imports a database driver.
 */
import type { StateDocument, StateScope } from './state.ts';
export type { StateDocument, StateScope } from './state.ts';
/** Who is asking, as the server's session knows it. */
export type StateOwner = {
    person: string;
    application: string;
};
/** One kept row: the owner it belongs to (the person, or the application), and the document. */
export type StateRow = {
    owner: string;
    scope: StateScope;
    key: string;
    value: unknown;
    revision: number;
    updatedAt: string;
};
/**
 * The storage a server gives the desktop state. `swap` must compare and set
 * in one step (a transaction, or `UPDATE … WHERE revision = ?`): it stores the
 * document only when the kept revision is still `ifRevision` (0 when there is
 * none), deleting it for a null value, and answers the row it found otherwise.
 */
export type StateRepository = {
    list(owner: StateOwner): Promise<StateDocument[]>;
    swap(owner: StateOwner, document: {
        scope: StateScope;
        key: string;
        value: unknown;
    }, ifRevision: number): Promise<{
        revision: number;
    } | {
        conflict: StateDocument;
    }>;
};
/**
 * The table the documents live in, as a `@jarenjs/db` model document: one
 * collection keyed by `<owner>\u0000<scope>\u0000<key>`, read by owner.
 */
export declare const DESKTOP_STATE_MODEL: {
    readonly $model: "0.1";
    readonly collections: {
        readonly desktop_state: {
            readonly schema: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["id", "owner", "scope", "key", "value", "revision", "updatedAt"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                        readonly maxLength: 600;
                    };
                    readonly owner: {
                        readonly type: "string";
                        readonly maxLength: 200;
                    };
                    readonly scope: {
                        readonly enum: readonly ["person", "application"];
                    };
                    readonly key: {
                        readonly type: "string";
                        readonly maxLength: 200;
                    };
                    readonly value: {};
                    readonly revision: {
                        readonly type: "integer";
                        readonly minimum: 1;
                    };
                    readonly updatedAt: {
                        readonly type: "string";
                        readonly format: "date-time";
                    };
                };
            };
            readonly key: "/id";
            readonly indexes: readonly [{
                readonly name: "by_owner";
                readonly path: readonly ["$.owner", "$.scope"];
            }];
        };
    };
};
/** The row's id in {@link DESKTOP_STATE_MODEL}. */
export declare const stateRowId: (owner: string, scope: StateScope, key: string) => string;
/** Whose a document is: the person's id for `person`, the application's (tenant's) for `application`. */
export declare const ownerOf: (owner: StateOwner, scope: StateScope) => string;
/** A repository in memory: for tests, and the shape a database repository follows. */
export declare function memoryStateRepository(now?: () => string): StateRepository & {
    rows(): StateRow[];
};
/**
 * The `tangle_os_state` handlers over a repository. `owner` answers who is
 * signed in for a call (from the request's session); it throws to refuse a
 * caller that is not.
 */
export declare function serveDesktopState(repository: StateRepository, owner: (context?: unknown) => StateOwner): {
    'state.load': (_input: unknown, context?: unknown) => Promise<{
        documents: StateDocument[];
    }>;
    'state.save': ({ scope, key, value, ifRevision }: {
        scope: StateScope;
        key: string;
        value: unknown;
        ifRevision: number;
    }, context?: unknown) => Promise<{
        revision: number;
    } | {
        conflict: StateDocument;
    }>;
};
