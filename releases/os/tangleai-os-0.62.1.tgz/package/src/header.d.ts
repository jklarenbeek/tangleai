/**
 * The header bar: what an application puts in its window's title bar, as a
 * JSON document the desktop draws. The application never paints the bar
 * itself, so every bar looks, reads and behaves alike (theme, writing
 * direction, keyboard, screen readers, narrow windows), no application can
 * draw a false close button or a false desktop dialog, and every item is plain
 * data the assistant can read and press through the kernel, under grants and
 * into the ledger, exactly as the person presses it.
 *
 * A header has a `start` and an `end` row of buttons, toggles and menus, a
 * `center` (tabs that switch the window's view, or a search field) that takes
 * the title's place, and a `subtitle` beside the title. Search may also sit
 * at the end. Ids are unique within a header. Glyphs come from the desktop's
 * own set ({@link HEADER_GLYPHS}); a label is always the item's accessible
 * name, and a `shortcut` is a hint the desktop shows, never a key it binds
 * (keys pressed inside a framed application stay in that application).
 * `assistant: false` keeps an item (or a menu entry) from the assistant: it
 * is not listed to it and it cannot press it.
 */
/** A stroke glyph on a 16×16 grid, drawn in the current colour. */
export declare const HEADER_GLYPHS: {
    readonly back: "M10 3.5 5.5 8l4.5 4.5";
    readonly forward: "M6 3.5 10.5 8 6 12.5";
    readonly add: "M8 3v10M3 8h10";
    readonly refresh: "M12.5 5.5A5 5 0 1 0 13 9M12.5 2.5v3h-3";
    readonly search: "M7 2.5a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9zM10.5 10.5 13.5 13.5";
    readonly menu: "M2.5 4.5h11M2.5 8h11M2.5 11.5h11";
    readonly more: "M3.5 8h.01M8 8h.01M12.5 8h.01";
    readonly sidebar: "M2.5 3.5h11v9h-11zM6 3.5v9";
    readonly edit: "M3 13l1-3.5 6.5-6.5 2.5 2.5L6.5 12zM9 4.5 11.5 7";
    readonly delete: "M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.5 8.5h6l.5-8.5";
    readonly share: "M8 2.5v7.5M5 5.5 8 2.5l3 3M3.5 9v4h9V9";
    readonly filter: "M2.5 3.5h11L9 8.5v4l-2 1v-5z";
    readonly sort: "M5 3v10M2.5 10.5 5 13l2.5-2.5M11 13V3M8.5 5.5 11 3l2.5 2.5";
    readonly settings: "M8 5.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5zM8 1.5v2M8 12.5v2M1.5 8h2M12.5 8h2M3.4 3.4l1.4 1.4M11.2 11.2l1.4 1.4M3.4 12.6l1.4-1.4M11.2 4.8l1.4-1.4";
    readonly star: "M8 2l1.8 3.8 4.2.5-3.1 2.9.8 4.1L8 11.3l-3.7 2 .8-4.1L2 6.3l4.2-.5z";
    readonly today: "M2.5 4h11v9.5h-11zM2.5 7h11M5.5 2.5V5M10.5 2.5V5M7 9.5h2v2H7z";
    readonly download: "M8 2.5v8M5 7.5l3 3 3-3M3 13.5h10";
    readonly upload: "M8 10.5v-8M5 5.5l3-3 3 3M3 13.5h10";
    readonly undo: "M5.5 6.5H10a3 3 0 0 1 0 6H6M5.5 6.5 8 4M5.5 6.5 8 9";
    readonly redo: "M10.5 6.5H6a3 3 0 0 0 0 6h4M10.5 6.5 8 4M10.5 6.5 8 9";
    readonly view: "M1.5 8S4 3.5 8 3.5 14.5 8 14.5 8 12 12.5 8 12.5 1.5 8 1.5 8zM8 6a2 2 0 1 1 0 4 2 2 0 0 1 0-4z";
    readonly print: "M4.5 6V2.5h7V6M4.5 11.5h-2V6h11v5.5h-2M4.5 9.5h7v4h-7z";
};
export type HeaderGlyph = keyof typeof HEADER_GLYPHS;
export type HeaderMenuEntry = {
    separator: true;
} | {
    id: string;
    label: string;
    checked?: boolean;
    disabled?: boolean;
    shortcut?: string;
    assistant?: boolean;
};
type Common = {
    id: string;
    label: string;
    glyph?: HeaderGlyph;
    disabled?: boolean;
    assistant?: boolean;
};
export type HeaderButton = Common & {
    kind: 'button';
    primary?: boolean;
    shortcut?: string;
};
export type HeaderToggle = Common & {
    kind: 'toggle';
    pressed: boolean;
    shortcut?: string;
};
export type HeaderMenu = Common & {
    kind: 'menu';
    entries: HeaderMenuEntry[];
};
export type HeaderSearch = {
    kind: 'search';
    id: string;
    label: string;
    placeholder?: string;
    value?: string;
    disabled?: boolean;
    assistant?: boolean;
};
export type HeaderTabs = {
    kind: 'tabs';
    id: string;
    label: string;
    selected: string;
    items: {
        id: string;
        label: string;
        glyph?: HeaderGlyph;
        disabled?: boolean;
    }[];
    assistant?: boolean;
};
export type HeaderItem = HeaderButton | HeaderToggle | HeaderMenu | HeaderSearch | HeaderTabs;
export type Header = {
    start?: (HeaderButton | HeaderToggle | HeaderMenu)[];
    center?: HeaderTabs | HeaderSearch;
    end?: (HeaderButton | HeaderToggle | HeaderMenu | HeaderSearch)[];
    subtitle?: string;
};
/** What reaches the application when an item is used: `by` is `person`, or the caller that pressed it (`assistant`, a module id). */
export type HeaderActivation = {
    item: string;
    value?: string | boolean;
    by: string;
};
/** Where a window's activations arrive; return `{ refused }` to say it was not done. */
export type HeaderHandler = (activation: HeaderActivation) => {
    refused?: string;
} | void | Promise<{
    refused?: string;
} | void>;
/** The header document a window carries: bounded plain JSON, drawn as text only. */
export declare const HEADER_SCHEMA: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly properties: {
        readonly start: {
            readonly type: "array";
            readonly maxItems: 4;
            readonly items: {
                readonly anyOf: readonly [{
                    type: string;
                    additionalProperties: boolean;
                    required: string[];
                    properties: {
                        primary: {
                            type: string;
                        };
                        shortcut: {
                            type: string;
                            minLength: number;
                            maxLength: number;
                        };
                        id: {
                            type: string;
                            pattern: string;
                        };
                        label: {
                            type: string;
                            minLength: number;
                            maxLength: number;
                        };
                        glyph: {
                            enum: string[];
                        };
                        disabled: {
                            type: string;
                        };
                        assistant: {
                            type: string;
                        };
                        kind: {
                            const: string;
                        };
                    };
                }, {
                    type: string;
                    additionalProperties: boolean;
                    required: string[];
                    properties: {
                        pressed: {
                            type: string;
                        };
                        shortcut: {
                            type: string;
                            minLength: number;
                            maxLength: number;
                        };
                        id: {
                            type: string;
                            pattern: string;
                        };
                        label: {
                            type: string;
                            minLength: number;
                            maxLength: number;
                        };
                        glyph: {
                            enum: string[];
                        };
                        disabled: {
                            type: string;
                        };
                        assistant: {
                            type: string;
                        };
                        kind: {
                            const: string;
                        };
                    };
                }, {
                    type: string;
                    additionalProperties: boolean;
                    required: string[];
                    properties: {
                        entries: {
                            type: string;
                            minItems: number;
                            maxItems: number;
                            items: {
                                anyOf: ({
                                    type: string;
                                    additionalProperties: boolean;
                                    required: string[];
                                    properties: {
                                        separator: {
                                            const: boolean;
                                        };
                                        id?: undefined;
                                        label?: undefined;
                                        checked?: undefined;
                                        disabled?: undefined;
                                        shortcut?: undefined;
                                        assistant?: undefined;
                                    };
                                } | {
                                    type: string;
                                    additionalProperties: boolean;
                                    required: string[];
                                    properties: {
                                        id: {
                                            type: string;
                                            pattern: string;
                                        };
                                        label: {
                                            type: string;
                                            minLength: number;
                                            maxLength: number;
                                        };
                                        checked: {
                                            type: string;
                                        };
                                        disabled: {
                                            type: string;
                                        };
                                        shortcut: {
                                            type: string;
                                            minLength: number;
                                            maxLength: number;
                                        };
                                        assistant: {
                                            type: string;
                                        };
                                        separator?: undefined;
                                    };
                                })[];
                            };
                        };
                        id: {
                            type: string;
                            pattern: string;
                        };
                        label: {
                            type: string;
                            minLength: number;
                            maxLength: number;
                        };
                        glyph: {
                            enum: string[];
                        };
                        disabled: {
                            type: string;
                        };
                        assistant: {
                            type: string;
                        };
                        kind: {
                            const: string;
                        };
                    };
                }];
            };
        };
        readonly center: {
            readonly anyOf: readonly [{
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    kind: {
                        const: string;
                    };
                    id: {
                        type: string;
                        pattern: string;
                    };
                    label: {
                        type: string;
                        minLength: number;
                        maxLength: number;
                    };
                    selected: {
                        type: string;
                        pattern: string;
                    };
                    assistant: {
                        type: string;
                    };
                    items: {
                        type: string;
                        minItems: number;
                        maxItems: number;
                        items: {
                            type: string;
                            additionalProperties: boolean;
                            required: string[];
                            properties: {
                                id: {
                                    type: string;
                                    pattern: string;
                                };
                                label: {
                                    type: string;
                                    minLength: number;
                                    maxLength: number;
                                };
                                glyph: {
                                    enum: string[];
                                };
                                disabled: {
                                    type: string;
                                };
                            };
                        };
                    };
                };
            }, {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    kind: {
                        const: string;
                    };
                    id: {
                        type: string;
                        pattern: string;
                    };
                    label: {
                        type: string;
                        minLength: number;
                        maxLength: number;
                    };
                    placeholder: {
                        type: string;
                        minLength: number;
                        maxLength: number;
                    };
                    value: {
                        type: string;
                        maxLength: number;
                    };
                    disabled: {
                        type: string;
                    };
                    assistant: {
                        type: string;
                    };
                };
            }];
        };
        readonly end: {
            readonly type: "array";
            readonly maxItems: 4;
            readonly items: {
                readonly anyOf: readonly [{
                    type: string;
                    additionalProperties: boolean;
                    required: string[];
                    properties: {
                        primary: {
                            type: string;
                        };
                        shortcut: {
                            type: string;
                            minLength: number;
                            maxLength: number;
                        };
                        id: {
                            type: string;
                            pattern: string;
                        };
                        label: {
                            type: string;
                            minLength: number;
                            maxLength: number;
                        };
                        glyph: {
                            enum: string[];
                        };
                        disabled: {
                            type: string;
                        };
                        assistant: {
                            type: string;
                        };
                        kind: {
                            const: string;
                        };
                    };
                }, {
                    type: string;
                    additionalProperties: boolean;
                    required: string[];
                    properties: {
                        pressed: {
                            type: string;
                        };
                        shortcut: {
                            type: string;
                            minLength: number;
                            maxLength: number;
                        };
                        id: {
                            type: string;
                            pattern: string;
                        };
                        label: {
                            type: string;
                            minLength: number;
                            maxLength: number;
                        };
                        glyph: {
                            enum: string[];
                        };
                        disabled: {
                            type: string;
                        };
                        assistant: {
                            type: string;
                        };
                        kind: {
                            const: string;
                        };
                    };
                }, {
                    type: string;
                    additionalProperties: boolean;
                    required: string[];
                    properties: {
                        entries: {
                            type: string;
                            minItems: number;
                            maxItems: number;
                            items: {
                                anyOf: ({
                                    type: string;
                                    additionalProperties: boolean;
                                    required: string[];
                                    properties: {
                                        separator: {
                                            const: boolean;
                                        };
                                        id?: undefined;
                                        label?: undefined;
                                        checked?: undefined;
                                        disabled?: undefined;
                                        shortcut?: undefined;
                                        assistant?: undefined;
                                    };
                                } | {
                                    type: string;
                                    additionalProperties: boolean;
                                    required: string[];
                                    properties: {
                                        id: {
                                            type: string;
                                            pattern: string;
                                        };
                                        label: {
                                            type: string;
                                            minLength: number;
                                            maxLength: number;
                                        };
                                        checked: {
                                            type: string;
                                        };
                                        disabled: {
                                            type: string;
                                        };
                                        shortcut: {
                                            type: string;
                                            minLength: number;
                                            maxLength: number;
                                        };
                                        assistant: {
                                            type: string;
                                        };
                                        separator?: undefined;
                                    };
                                })[];
                            };
                        };
                        id: {
                            type: string;
                            pattern: string;
                        };
                        label: {
                            type: string;
                            minLength: number;
                            maxLength: number;
                        };
                        glyph: {
                            enum: string[];
                        };
                        disabled: {
                            type: string;
                        };
                        assistant: {
                            type: string;
                        };
                        kind: {
                            const: string;
                        };
                    };
                }, {
                    type: string;
                    additionalProperties: boolean;
                    required: string[];
                    properties: {
                        kind: {
                            const: string;
                        };
                        id: {
                            type: string;
                            pattern: string;
                        };
                        label: {
                            type: string;
                            minLength: number;
                            maxLength: number;
                        };
                        placeholder: {
                            type: string;
                            minLength: number;
                            maxLength: number;
                        };
                        value: {
                            type: string;
                            maxLength: number;
                        };
                        disabled: {
                            type: string;
                        };
                        assistant: {
                            type: string;
                        };
                    };
                }];
            };
        };
        readonly subtitle: {
            readonly type: "string";
            readonly maxLength: 120;
        };
    };
};
/** Every item of a header, in the order the desktop drops them when the bar is narrow (start, then end). */
export declare function headerItems(header: Header): HeaderItem[];
/** The first id used twice (items, tabs and menu entries share one namespace), or null. */
export declare function duplicateHeaderId(header: Header): string | null;
/** The header as one caller sees it: without what is kept from the assistant (`assistant: false`). */
export declare function headerFor(header: Header, caller: string): Header;
/**
 * Check one activation against a header, and the header after it: tabs
 * select, toggles press, search fields hold their text; a button or a menu
 * entry changes nothing the desktop keeps. Returns a refusal code and message
 * when the item is absent, disabled, kept from this caller, or the value does
 * not fit it.
 */
export declare function activateHeader(header: Header, caller: string, item: string, value: unknown): {
    ok: true;
    header: Header;
    value?: string | boolean;
} | {
    ok: false;
    code: 'OS0114' | 'OS0115' | 'OS0116';
    message: string;
};
/**
 * How many of a bar's droppable items fit, in the order they drop (the last
 * first): all of them when their widths fit `available`, otherwise as many
 * as fit beside the "more" button that then holds the rest.
 */
export declare function fitHeader(widths: readonly number[], available: number, more: number): number;
/** `tangle_os_header`: the kernel's own contract over every window's header bar, for the assistant and granted modules. */
export declare const HEADER_CONTRACT: {
    readonly $contract: "0.1";
    readonly id: "tangle_os_header";
    readonly operations: {
        readonly 'header.list': {
            readonly kind: "read";
            readonly doc: "The header bar of every open window that has one: its buttons, toggles, menus, tabs and search fields, with their state (the selected tab, a pressed toggle, the search text).";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly properties: {};
            };
            readonly output: {
                readonly type: "object";
                readonly required: readonly ["windows"];
                readonly properties: {
                    readonly windows: {
                        readonly type: "array";
                        readonly items: {
                            readonly type: "object";
                            readonly required: readonly ["window", "module", "header"];
                            readonly properties: {
                                readonly window: {
                                    readonly type: "string";
                                };
                                readonly module: {
                                    readonly type: "string";
                                };
                                readonly header: {
                                    readonly type: "object";
                                    readonly additionalProperties: false;
                                    readonly properties: {
                                        readonly start: {
                                            readonly type: "array";
                                            readonly maxItems: 4;
                                            readonly items: {
                                                readonly anyOf: readonly [{
                                                    type: string;
                                                    additionalProperties: boolean;
                                                    required: string[];
                                                    properties: {
                                                        primary: {
                                                            type: string;
                                                        };
                                                        shortcut: {
                                                            type: string;
                                                            minLength: number;
                                                            maxLength: number;
                                                        };
                                                        id: {
                                                            type: string;
                                                            pattern: string;
                                                        };
                                                        label: {
                                                            type: string;
                                                            minLength: number;
                                                            maxLength: number;
                                                        };
                                                        glyph: {
                                                            enum: string[];
                                                        };
                                                        disabled: {
                                                            type: string;
                                                        };
                                                        assistant: {
                                                            type: string;
                                                        };
                                                        kind: {
                                                            const: string;
                                                        };
                                                    };
                                                }, {
                                                    type: string;
                                                    additionalProperties: boolean;
                                                    required: string[];
                                                    properties: {
                                                        pressed: {
                                                            type: string;
                                                        };
                                                        shortcut: {
                                                            type: string;
                                                            minLength: number;
                                                            maxLength: number;
                                                        };
                                                        id: {
                                                            type: string;
                                                            pattern: string;
                                                        };
                                                        label: {
                                                            type: string;
                                                            minLength: number;
                                                            maxLength: number;
                                                        };
                                                        glyph: {
                                                            enum: string[];
                                                        };
                                                        disabled: {
                                                            type: string;
                                                        };
                                                        assistant: {
                                                            type: string;
                                                        };
                                                        kind: {
                                                            const: string;
                                                        };
                                                    };
                                                }, {
                                                    type: string;
                                                    additionalProperties: boolean;
                                                    required: string[];
                                                    properties: {
                                                        entries: {
                                                            type: string;
                                                            minItems: number;
                                                            maxItems: number;
                                                            items: {
                                                                anyOf: ({
                                                                    type: string;
                                                                    additionalProperties: boolean;
                                                                    required: string[];
                                                                    properties: {
                                                                        separator: {
                                                                            const: boolean;
                                                                        };
                                                                        id?: undefined;
                                                                        label?: undefined;
                                                                        checked?: undefined;
                                                                        disabled?: undefined;
                                                                        shortcut?: undefined;
                                                                        assistant?: undefined;
                                                                    };
                                                                } | {
                                                                    type: string;
                                                                    additionalProperties: boolean;
                                                                    required: string[];
                                                                    properties: {
                                                                        id: {
                                                                            type: string;
                                                                            pattern: string;
                                                                        };
                                                                        label: {
                                                                            type: string;
                                                                            minLength: number;
                                                                            maxLength: number;
                                                                        };
                                                                        checked: {
                                                                            type: string;
                                                                        };
                                                                        disabled: {
                                                                            type: string;
                                                                        };
                                                                        shortcut: {
                                                                            type: string;
                                                                            minLength: number;
                                                                            maxLength: number;
                                                                        };
                                                                        assistant: {
                                                                            type: string;
                                                                        };
                                                                        separator?: undefined;
                                                                    };
                                                                })[];
                                                            };
                                                        };
                                                        id: {
                                                            type: string;
                                                            pattern: string;
                                                        };
                                                        label: {
                                                            type: string;
                                                            minLength: number;
                                                            maxLength: number;
                                                        };
                                                        glyph: {
                                                            enum: string[];
                                                        };
                                                        disabled: {
                                                            type: string;
                                                        };
                                                        assistant: {
                                                            type: string;
                                                        };
                                                        kind: {
                                                            const: string;
                                                        };
                                                    };
                                                }];
                                            };
                                        };
                                        readonly center: {
                                            readonly anyOf: readonly [{
                                                type: string;
                                                additionalProperties: boolean;
                                                required: string[];
                                                properties: {
                                                    kind: {
                                                        const: string;
                                                    };
                                                    id: {
                                                        type: string;
                                                        pattern: string;
                                                    };
                                                    label: {
                                                        type: string;
                                                        minLength: number;
                                                        maxLength: number;
                                                    };
                                                    selected: {
                                                        type: string;
                                                        pattern: string;
                                                    };
                                                    assistant: {
                                                        type: string;
                                                    };
                                                    items: {
                                                        type: string;
                                                        minItems: number;
                                                        maxItems: number;
                                                        items: {
                                                            type: string;
                                                            additionalProperties: boolean;
                                                            required: string[];
                                                            properties: {
                                                                id: {
                                                                    type: string;
                                                                    pattern: string;
                                                                };
                                                                label: {
                                                                    type: string;
                                                                    minLength: number;
                                                                    maxLength: number;
                                                                };
                                                                glyph: {
                                                                    enum: string[];
                                                                };
                                                                disabled: {
                                                                    type: string;
                                                                };
                                                            };
                                                        };
                                                    };
                                                };
                                            }, {
                                                type: string;
                                                additionalProperties: boolean;
                                                required: string[];
                                                properties: {
                                                    kind: {
                                                        const: string;
                                                    };
                                                    id: {
                                                        type: string;
                                                        pattern: string;
                                                    };
                                                    label: {
                                                        type: string;
                                                        minLength: number;
                                                        maxLength: number;
                                                    };
                                                    placeholder: {
                                                        type: string;
                                                        minLength: number;
                                                        maxLength: number;
                                                    };
                                                    value: {
                                                        type: string;
                                                        maxLength: number;
                                                    };
                                                    disabled: {
                                                        type: string;
                                                    };
                                                    assistant: {
                                                        type: string;
                                                    };
                                                };
                                            }];
                                        };
                                        readonly end: {
                                            readonly type: "array";
                                            readonly maxItems: 4;
                                            readonly items: {
                                                readonly anyOf: readonly [{
                                                    type: string;
                                                    additionalProperties: boolean;
                                                    required: string[];
                                                    properties: {
                                                        primary: {
                                                            type: string;
                                                        };
                                                        shortcut: {
                                                            type: string;
                                                            minLength: number;
                                                            maxLength: number;
                                                        };
                                                        id: {
                                                            type: string;
                                                            pattern: string;
                                                        };
                                                        label: {
                                                            type: string;
                                                            minLength: number;
                                                            maxLength: number;
                                                        };
                                                        glyph: {
                                                            enum: string[];
                                                        };
                                                        disabled: {
                                                            type: string;
                                                        };
                                                        assistant: {
                                                            type: string;
                                                        };
                                                        kind: {
                                                            const: string;
                                                        };
                                                    };
                                                }, {
                                                    type: string;
                                                    additionalProperties: boolean;
                                                    required: string[];
                                                    properties: {
                                                        pressed: {
                                                            type: string;
                                                        };
                                                        shortcut: {
                                                            type: string;
                                                            minLength: number;
                                                            maxLength: number;
                                                        };
                                                        id: {
                                                            type: string;
                                                            pattern: string;
                                                        };
                                                        label: {
                                                            type: string;
                                                            minLength: number;
                                                            maxLength: number;
                                                        };
                                                        glyph: {
                                                            enum: string[];
                                                        };
                                                        disabled: {
                                                            type: string;
                                                        };
                                                        assistant: {
                                                            type: string;
                                                        };
                                                        kind: {
                                                            const: string;
                                                        };
                                                    };
                                                }, {
                                                    type: string;
                                                    additionalProperties: boolean;
                                                    required: string[];
                                                    properties: {
                                                        entries: {
                                                            type: string;
                                                            minItems: number;
                                                            maxItems: number;
                                                            items: {
                                                                anyOf: ({
                                                                    type: string;
                                                                    additionalProperties: boolean;
                                                                    required: string[];
                                                                    properties: {
                                                                        separator: {
                                                                            const: boolean;
                                                                        };
                                                                        id?: undefined;
                                                                        label?: undefined;
                                                                        checked?: undefined;
                                                                        disabled?: undefined;
                                                                        shortcut?: undefined;
                                                                        assistant?: undefined;
                                                                    };
                                                                } | {
                                                                    type: string;
                                                                    additionalProperties: boolean;
                                                                    required: string[];
                                                                    properties: {
                                                                        id: {
                                                                            type: string;
                                                                            pattern: string;
                                                                        };
                                                                        label: {
                                                                            type: string;
                                                                            minLength: number;
                                                                            maxLength: number;
                                                                        };
                                                                        checked: {
                                                                            type: string;
                                                                        };
                                                                        disabled: {
                                                                            type: string;
                                                                        };
                                                                        shortcut: {
                                                                            type: string;
                                                                            minLength: number;
                                                                            maxLength: number;
                                                                        };
                                                                        assistant: {
                                                                            type: string;
                                                                        };
                                                                        separator?: undefined;
                                                                    };
                                                                })[];
                                                            };
                                                        };
                                                        id: {
                                                            type: string;
                                                            pattern: string;
                                                        };
                                                        label: {
                                                            type: string;
                                                            minLength: number;
                                                            maxLength: number;
                                                        };
                                                        glyph: {
                                                            enum: string[];
                                                        };
                                                        disabled: {
                                                            type: string;
                                                        };
                                                        assistant: {
                                                            type: string;
                                                        };
                                                        kind: {
                                                            const: string;
                                                        };
                                                    };
                                                }, {
                                                    type: string;
                                                    additionalProperties: boolean;
                                                    required: string[];
                                                    properties: {
                                                        kind: {
                                                            const: string;
                                                        };
                                                        id: {
                                                            type: string;
                                                            pattern: string;
                                                        };
                                                        label: {
                                                            type: string;
                                                            minLength: number;
                                                            maxLength: number;
                                                        };
                                                        placeholder: {
                                                            type: string;
                                                            minLength: number;
                                                            maxLength: number;
                                                        };
                                                        value: {
                                                            type: string;
                                                            maxLength: number;
                                                        };
                                                        disabled: {
                                                            type: string;
                                                        };
                                                        assistant: {
                                                            type: string;
                                                        };
                                                    };
                                                }];
                                            };
                                        };
                                        readonly subtitle: {
                                            readonly type: "string";
                                            readonly maxLength: 120;
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };
        readonly 'header.activate': {
            readonly kind: "command";
            readonly doc: "Use one item of a window's header bar as the person would: press a button (no value), set a toggle (true or false; without a value it flips), choose a menu entry or a tab (its id), or put a text into a search field. List the headers first.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["window", "item"];
                readonly properties: {
                    readonly window: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 128;
                    };
                    readonly item: {
                        type: string;
                        pattern: string;
                    };
                    readonly value: {
                        readonly anyOf: readonly [{
                            readonly type: "string";
                            readonly maxLength: 200;
                        }, {
                            readonly type: "boolean";
                        }];
                    };
                };
            };
            readonly output: {
                readonly type: "object";
            };
        };
    };
};
export {};
