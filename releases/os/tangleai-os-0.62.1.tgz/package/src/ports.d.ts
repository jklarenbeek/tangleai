/**
 * Jaren's port transport, loaded only when a framed module connects. A desktop
 * whose modules all run in the page (shipped mounts, the built-in contracts)
 * never fetches `@jarenjs/contract/port` and the frame and stream modules it
 * brings; the first framed module that says hello starts the load.
 *
 * Serving and opening stay synchronous for the caller. Until the transport has
 * arrived, a served port is wrapped: every message that reaches it is held and
 * handed to the server, in order, as soon as it attaches, so nothing a module
 * sends early is lost. A client's calls wait for the load and then go out.
 */
import type { ServedContract, ContractClient } from './kernel.ts';
type PortModule = typeof import('@jarenjs/contract/port');
/**
 * A loader that fetches once and keeps what arrived, but not a failure: the
 * next framed window, or a Retry, fetches again.
 */
export declare function portLoader(load: () => Promise<PortModule>): {
    load(): Promise<PortModule>;
    get: () => PortModule | null;
};
/** Start loading the port transport (once) and resolve when it is there. */
export declare function loadPorts(): Promise<PortModule>;
/** Whether the port transport has been loaded. */
export declare function portsLoaded(): boolean;
/** Serve `contract` on `options.channel`, now when the transport is loaded, else as soon as it is. */
export declare function servePortLazily(contract: any, handlers: Record<string, any>, options: {
    channel: any;
}): ServedContract;
/** Open a client on `options.channel`; its calls wait for the transport if it is still loading. */
export declare function openPortClientLazily(contract: any, options: {
    channel: any;
    timeoutMs?: number;
}): ContractClient;
export {};
