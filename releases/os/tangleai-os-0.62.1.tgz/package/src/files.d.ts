/**
 * File locations: where the desktop's Files finds documents and images. A
 * location is a contract an application serves (its own files, from its own
 * storage), built from one template, {@link fileLocationContract}, so every
 * location answers the same operations: list a folder (paged), search, read
 * one file, and, when it is `writable`, write, make a folder, move or rename,
 * and delete. Entries have opaque ids and a parent, never paths, so a
 * location whose files are rows (a document per person) serves them as they
 * are. A read answers the bytes inline (base64, at most 10 MB) or an https
 * address the location signed for a short while.
 *
 * A module says which contract is its location in its manifest
 * (`files: { contract, title }`). The desktop's Files calls it as the
 * person's own hand; the assistant reaches locations only through the
 * kernel's `tangle_os_files` contract, which reads and searches but never
 * writes, and never a location marked `assistant: false`.
 */
/** One file or folder in a location. */
export type FileEntry = {
    id: string;
    parent: string | null;
    name: string;
    kind: 'file' | 'folder';
    type?: string;
    size?: number;
    modified?: string;
};
/** A file's contents: inline bytes (base64) or an https address that serves them. */
export type FileContent = {
    entry: FileEntry;
    data?: string;
    url?: string;
};
export type FileLocationHandlers = {
    'files.info': () => {
        writable: boolean;
    } | Promise<{
        writable: boolean;
    }>;
    'files.list': (input: {
        folder?: string | null;
        cursor?: string;
        limit?: number;
    }) => {
        entries: FileEntry[];
        cursor?: string;
    } | Promise<{
        entries: FileEntry[];
        cursor?: string;
    }>;
    'files.search': (input: {
        query: string;
        cursor?: string;
        limit?: number;
    }) => {
        entries: FileEntry[];
        cursor?: string;
    } | Promise<{
        entries: FileEntry[];
        cursor?: string;
    }>;
    'files.read': (input: {
        id: string;
    }) => FileContent | Promise<FileContent>;
    'files.write'?: (input: {
        folder?: string | null;
        name: string;
        data: string;
        type?: string;
        replace?: string;
    }) => {
        entry: FileEntry;
    } | Promise<{
        entry: FileEntry;
    }>;
    'files.mkdir'?: (input: {
        folder?: string | null;
        name: string;
    }) => {
        entry: FileEntry;
    } | Promise<{
        entry: FileEntry;
    }>;
    'files.move'?: (input: {
        id: string;
        folder?: string | null;
        name?: string;
    }) => {
        entry: FileEntry;
    } | Promise<{
        entry: FileEntry;
    }>;
    'files.delete'?: (input: {
        id: string;
    }) => Record<string, never> | Promise<Record<string, never>>;
};
/** The most a read answers inline: 10 MB, as base64. */
export declare const MAX_INLINE_BYTES: number;
export declare const FILE_ENTRY_SCHEMA: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly required: readonly ["id", "parent", "name", "kind"];
    readonly properties: {
        readonly id: {
            type: string;
            minLength: number;
            maxLength: number;
        };
        readonly parent: {
            anyOf: ({
                type: string;
                minLength: number;
                maxLength: number;
            } | {
                type: string;
            })[];
        };
        readonly name: {
            type: string;
            minLength: number;
            maxLength: number;
            pattern: string;
        };
        readonly kind: {
            readonly enum: readonly ["file", "folder"];
        };
        readonly type: {
            readonly type: "string";
            readonly maxLength: 255;
        };
        readonly size: {
            readonly type: "integer";
            readonly minimum: 0;
        };
        readonly modified: {
            readonly type: "string";
            readonly maxLength: 40;
        };
    };
};
/** A location's contract, under the id its module serves it as. */
export declare function fileLocationContract(id: string): {
    readonly $contract: "0.1";
    readonly id: string;
    readonly operations: {
        readonly 'files.info': {
            readonly kind: "read";
            readonly doc: "Whether this location can be written.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly properties: {};
            };
            readonly output: {
                readonly type: "object";
                readonly properties: {
                    readonly writable: {
                        readonly type: "boolean";
                    };
                    readonly refused: {
                        type: string;
                        required: string[];
                        properties: {
                            code: {
                                type: string;
                                maxLength: number;
                            };
                            message: {
                                type: string;
                                maxLength: number;
                            };
                        };
                    };
                };
            };
        };
        readonly 'files.list': {
            readonly kind: "read";
            readonly doc: "The files and folders in a folder (null for the top), a page at a time.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly properties: {
                    readonly cursor: {
                        type: string;
                        maxLength: number;
                    };
                    readonly limit: {
                        type: string;
                        minimum: number;
                        maximum: number;
                    };
                    readonly folder: {
                        anyOf: ({
                            type: string;
                            minLength: number;
                            maxLength: number;
                        } | {
                            type: string;
                        })[];
                    };
                };
            };
            readonly output: {
                type: string;
                properties: {
                    entries: {
                        type: string;
                        maxItems: number;
                        items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["id", "parent", "name", "kind"];
                            readonly properties: {
                                readonly id: {
                                    type: string;
                                    minLength: number;
                                    maxLength: number;
                                };
                                readonly parent: {
                                    anyOf: ({
                                        type: string;
                                        minLength: number;
                                        maxLength: number;
                                    } | {
                                        type: string;
                                    })[];
                                };
                                readonly name: {
                                    type: string;
                                    minLength: number;
                                    maxLength: number;
                                    pattern: string;
                                };
                                readonly kind: {
                                    readonly enum: readonly ["file", "folder"];
                                };
                                readonly type: {
                                    readonly type: "string";
                                    readonly maxLength: 255;
                                };
                                readonly size: {
                                    readonly type: "integer";
                                    readonly minimum: 0;
                                };
                                readonly modified: {
                                    readonly type: "string";
                                    readonly maxLength: 40;
                                };
                            };
                        };
                    };
                    cursor: {
                        type: string;
                        maxLength: number;
                    };
                    refused: {
                        type: string;
                        required: string[];
                        properties: {
                            code: {
                                type: string;
                                maxLength: number;
                            };
                            message: {
                                type: string;
                                maxLength: number;
                            };
                        };
                    };
                };
            };
        };
        readonly 'files.search': {
            readonly kind: "read";
            readonly doc: "Files and folders whose name contains the query, a page at a time.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["query"];
                readonly properties: {
                    readonly cursor: {
                        type: string;
                        maxLength: number;
                    };
                    readonly limit: {
                        type: string;
                        minimum: number;
                        maximum: number;
                    };
                    readonly query: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 200;
                    };
                };
            };
            readonly output: {
                type: string;
                properties: {
                    entries: {
                        type: string;
                        maxItems: number;
                        items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["id", "parent", "name", "kind"];
                            readonly properties: {
                                readonly id: {
                                    type: string;
                                    minLength: number;
                                    maxLength: number;
                                };
                                readonly parent: {
                                    anyOf: ({
                                        type: string;
                                        minLength: number;
                                        maxLength: number;
                                    } | {
                                        type: string;
                                    })[];
                                };
                                readonly name: {
                                    type: string;
                                    minLength: number;
                                    maxLength: number;
                                    pattern: string;
                                };
                                readonly kind: {
                                    readonly enum: readonly ["file", "folder"];
                                };
                                readonly type: {
                                    readonly type: "string";
                                    readonly maxLength: 255;
                                };
                                readonly size: {
                                    readonly type: "integer";
                                    readonly minimum: 0;
                                };
                                readonly modified: {
                                    readonly type: "string";
                                    readonly maxLength: 40;
                                };
                            };
                        };
                    };
                    cursor: {
                        type: string;
                        maxLength: number;
                    };
                    refused: {
                        type: string;
                        required: string[];
                        properties: {
                            code: {
                                type: string;
                                maxLength: number;
                            };
                            message: {
                                type: string;
                                maxLength: number;
                            };
                        };
                    };
                };
            };
        };
        readonly 'files.read': {
            readonly kind: "read";
            readonly doc: "One file: its bytes inline (base64, at most 10 MB) or an https address that serves them.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["id"];
                readonly properties: {
                    readonly id: {
                        type: string;
                        minLength: number;
                        maxLength: number;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly properties: {
                    readonly entry: {
                        readonly type: "object";
                        readonly additionalProperties: false;
                        readonly required: readonly ["id", "parent", "name", "kind"];
                        readonly properties: {
                            readonly id: {
                                type: string;
                                minLength: number;
                                maxLength: number;
                            };
                            readonly parent: {
                                anyOf: ({
                                    type: string;
                                    minLength: number;
                                    maxLength: number;
                                } | {
                                    type: string;
                                })[];
                            };
                            readonly name: {
                                type: string;
                                minLength: number;
                                maxLength: number;
                                pattern: string;
                            };
                            readonly kind: {
                                readonly enum: readonly ["file", "folder"];
                            };
                            readonly type: {
                                readonly type: "string";
                                readonly maxLength: 255;
                            };
                            readonly size: {
                                readonly type: "integer";
                                readonly minimum: 0;
                            };
                            readonly modified: {
                                readonly type: "string";
                                readonly maxLength: 40;
                            };
                        };
                    };
                    readonly data: {
                        readonly type: "string";
                        readonly maxLength: number;
                    };
                    readonly url: {
                        readonly type: "string";
                        readonly maxLength: 4096;
                        readonly pattern: "^https://|^http://(localhost|127\\.0\\.0\\.1)(:|/)";
                    };
                    readonly refused: {
                        type: string;
                        required: string[];
                        properties: {
                            code: {
                                type: string;
                                maxLength: number;
                            };
                            message: {
                                type: string;
                                maxLength: number;
                            };
                        };
                    };
                };
            };
        };
        readonly 'files.write': {
            readonly kind: "command";
            readonly doc: "Write a file into a folder (null for the top), or replace an existing one.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["name", "data"];
                readonly properties: {
                    readonly folder: {
                        anyOf: ({
                            type: string;
                            minLength: number;
                            maxLength: number;
                        } | {
                            type: string;
                        })[];
                    };
                    readonly name: {
                        type: string;
                        minLength: number;
                        maxLength: number;
                        pattern: string;
                    };
                    readonly data: {
                        readonly type: "string";
                        readonly maxLength: number;
                    };
                    readonly type: {
                        readonly type: "string";
                        readonly maxLength: 255;
                    };
                    readonly replace: {
                        type: string;
                        minLength: number;
                        maxLength: number;
                    };
                };
            };
            readonly output: {
                type: string;
                properties: {
                    entry: {
                        readonly type: "object";
                        readonly additionalProperties: false;
                        readonly required: readonly ["id", "parent", "name", "kind"];
                        readonly properties: {
                            readonly id: {
                                type: string;
                                minLength: number;
                                maxLength: number;
                            };
                            readonly parent: {
                                anyOf: ({
                                    type: string;
                                    minLength: number;
                                    maxLength: number;
                                } | {
                                    type: string;
                                })[];
                            };
                            readonly name: {
                                type: string;
                                minLength: number;
                                maxLength: number;
                                pattern: string;
                            };
                            readonly kind: {
                                readonly enum: readonly ["file", "folder"];
                            };
                            readonly type: {
                                readonly type: "string";
                                readonly maxLength: 255;
                            };
                            readonly size: {
                                readonly type: "integer";
                                readonly minimum: 0;
                            };
                            readonly modified: {
                                readonly type: "string";
                                readonly maxLength: 40;
                            };
                        };
                    };
                    refused: {
                        type: string;
                        required: string[];
                        properties: {
                            code: {
                                type: string;
                                maxLength: number;
                            };
                            message: {
                                type: string;
                                maxLength: number;
                            };
                        };
                    };
                };
            };
        };
        readonly 'files.mkdir': {
            readonly kind: "command";
            readonly doc: "Make a folder.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["name"];
                readonly properties: {
                    readonly folder: {
                        anyOf: ({
                            type: string;
                            minLength: number;
                            maxLength: number;
                        } | {
                            type: string;
                        })[];
                    };
                    readonly name: {
                        type: string;
                        minLength: number;
                        maxLength: number;
                        pattern: string;
                    };
                };
            };
            readonly output: {
                type: string;
                properties: {
                    entry: {
                        readonly type: "object";
                        readonly additionalProperties: false;
                        readonly required: readonly ["id", "parent", "name", "kind"];
                        readonly properties: {
                            readonly id: {
                                type: string;
                                minLength: number;
                                maxLength: number;
                            };
                            readonly parent: {
                                anyOf: ({
                                    type: string;
                                    minLength: number;
                                    maxLength: number;
                                } | {
                                    type: string;
                                })[];
                            };
                            readonly name: {
                                type: string;
                                minLength: number;
                                maxLength: number;
                                pattern: string;
                            };
                            readonly kind: {
                                readonly enum: readonly ["file", "folder"];
                            };
                            readonly type: {
                                readonly type: "string";
                                readonly maxLength: 255;
                            };
                            readonly size: {
                                readonly type: "integer";
                                readonly minimum: 0;
                            };
                            readonly modified: {
                                readonly type: "string";
                                readonly maxLength: 40;
                            };
                        };
                    };
                    refused: {
                        type: string;
                        required: string[];
                        properties: {
                            code: {
                                type: string;
                                maxLength: number;
                            };
                            message: {
                                type: string;
                                maxLength: number;
                            };
                        };
                    };
                };
            };
        };
        readonly 'files.move': {
            readonly kind: "command";
            readonly doc: "Move a file or folder into another folder, rename it, or both.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["id"];
                readonly properties: {
                    readonly id: {
                        type: string;
                        minLength: number;
                        maxLength: number;
                    };
                    readonly folder: {
                        anyOf: ({
                            type: string;
                            minLength: number;
                            maxLength: number;
                        } | {
                            type: string;
                        })[];
                    };
                    readonly name: {
                        type: string;
                        minLength: number;
                        maxLength: number;
                        pattern: string;
                    };
                };
            };
            readonly output: {
                type: string;
                properties: {
                    entry: {
                        readonly type: "object";
                        readonly additionalProperties: false;
                        readonly required: readonly ["id", "parent", "name", "kind"];
                        readonly properties: {
                            readonly id: {
                                type: string;
                                minLength: number;
                                maxLength: number;
                            };
                            readonly parent: {
                                anyOf: ({
                                    type: string;
                                    minLength: number;
                                    maxLength: number;
                                } | {
                                    type: string;
                                })[];
                            };
                            readonly name: {
                                type: string;
                                minLength: number;
                                maxLength: number;
                                pattern: string;
                            };
                            readonly kind: {
                                readonly enum: readonly ["file", "folder"];
                            };
                            readonly type: {
                                readonly type: "string";
                                readonly maxLength: 255;
                            };
                            readonly size: {
                                readonly type: "integer";
                                readonly minimum: 0;
                            };
                            readonly modified: {
                                readonly type: "string";
                                readonly maxLength: 40;
                            };
                        };
                    };
                    refused: {
                        type: string;
                        required: string[];
                        properties: {
                            code: {
                                type: string;
                                maxLength: number;
                            };
                            message: {
                                type: string;
                                maxLength: number;
                            };
                        };
                    };
                };
            };
        };
        readonly 'files.delete': {
            readonly kind: "command";
            readonly doc: "Delete a file, or a folder with everything in it.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["id"];
                readonly properties: {
                    readonly id: {
                        type: string;
                        minLength: number;
                        maxLength: number;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly properties: {
                    readonly refused: {
                        type: string;
                        required: string[];
                        properties: {
                            code: {
                                type: string;
                                maxLength: number;
                            };
                            message: {
                                type: string;
                                maxLength: number;
                            };
                        };
                    };
                };
            };
        };
    };
};
/** A file's type from its name, for a location that does not keep one. */
export declare function typeOfName(name: string): string;
declare const toBase64: (bytes: Uint8Array) => string;
declare const fromBase64: (text: string) => Uint8Array<ArrayBuffer>;
/** A location in memory: for tests, and the reference every location answers like. */
export declare function memoryLocation(options?: {
    writable?: boolean;
    now?: () => string;
}): FileLocationHandlers;
/**
 * "This browser": a folder of the browser's own private file system (OPFS)
 * as a location. The host passes the directory it gives the person, never the
 * file system's root, which holds the host's own databases. Ids are paths
 * inside that directory, opaque to everyone else.
 */
export declare function browserLocation(root: FileSystemDirectoryHandle | Promise<FileSystemDirectoryHandle>): FileLocationHandlers;
/**
 * A location's handlers as a contract serves them: a refusal it throws
 * (`OS06xx`, or any error) is answered as `{ refused: { code, message } }`,
 * so the person reads why. Serve every location through this.
 */
export declare function serveFileLocation(handlers: FileLocationHandlers): Record<string, (input: any) => Promise<unknown>>;
/** A location's answer, or the refusal it carried (thrown with its code). */
export declare function fileAnswer<T>(outcome: {
    ok: boolean;
    value?: any;
    error?: {
        code: string;
        message: string;
    };
}): T;
export { toBase64 as fileBytesToBase64, fromBase64 as fileBase64ToBytes };
