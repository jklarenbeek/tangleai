import { type OsConnection } from './module.ts';
export type ModuleHostOptions = {
    node?: any;
    window?: any;
    onError?: (error: unknown) => void;
};
/** Boot the document module this frame is handed. Returns the connection and the running app. */
export declare function bootDocumentModule(options?: ModuleHostOptions): Promise<{
    connection: OsConnection;
    app: any;
}>;
