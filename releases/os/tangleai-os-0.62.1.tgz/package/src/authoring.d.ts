import type { LocalizedText, ModuleManifest } from './manifest.ts';
/** A complete working document the crib shows: a to-do list. */
export declare const AUTHORING_SEED: {
    readonly $app: "0.1";
    readonly state: {
        readonly draft: "";
        readonly nextId: 3;
        readonly items: readonly [{
            readonly id: 1;
            readonly text: "Read the manual";
            readonly done: true;
        }, {
            readonly id: 2;
            readonly text: "Try the calculator";
            readonly done: false;
        }];
    };
    readonly view: {
        readonly $jslt: "0.1";
        readonly rules: readonly [{
            readonly match: "$";
            readonly body: readonly ["div", {
                readonly class: "todo";
            }, readonly ["h2", {}, "To do"], readonly ["p", {
                readonly class: "todo-count";
            }, {
                readonly $count: "$.items[?@.done == false]";
            }, " open of ", {
                readonly $count: "$.items[*]";
            }], readonly ["form", {
                readonly on: {
                    readonly submit: {
                        readonly action: "add";
                        readonly preventDefault: true;
                    };
                };
            }, readonly ["input", {
                readonly type: "text";
                readonly value: "$.draft";
                readonly placeholder: "New item";
                readonly on: {
                    readonly input: "draft";
                };
            }], readonly ["button", {
                readonly type: "submit";
                readonly disabled: {
                    readonly $eq: readonly ["$.draft", ""];
                };
            }, "Add"]], readonly ["ul", {}, readonly [{
                readonly $apply: "$.items[*]";
            }]]];
        }, {
            readonly match: "$.items[*]";
            readonly body: readonly ["li", {
                readonly key: {
                    readonly $string: "$.id";
                };
                readonly class: {
                    readonly $if: readonly ["$.done", "done", "open"];
                };
            }, readonly ["label", {}, readonly ["input", {
                readonly type: "checkbox";
                readonly checked: "$.done";
                readonly on: {
                    readonly change: {
                        readonly action: "toggle";
                        readonly with: {
                            readonly id: "$.id";
                        };
                    };
                };
            }], " ", "$.text"], readonly ["button", {
                readonly type: "button";
                readonly on: {
                    readonly click: {
                        readonly action: "remove";
                        readonly with: {
                            readonly id: "$.id";
                        };
                    };
                };
            }, "Remove"]];
        }];
    };
    readonly actions: {
        readonly draft: {
            readonly patch: readonly [{
                readonly op: "replace";
                readonly path: "/draft";
                readonly value: "$event.value";
            }];
        };
        readonly add: {
            readonly $if: readonly [{
                readonly $eq: readonly ["$.draft", ""];
            }, null, {
                readonly patch: readonly [{
                    readonly op: "add";
                    readonly path: "/items/-";
                    readonly value: {
                        readonly id: "$.nextId";
                        readonly text: "$.draft";
                        readonly done: false;
                    };
                }, {
                    readonly op: "replace";
                    readonly path: "/nextId";
                    readonly value: {
                        readonly $add: readonly ["$.nextId", 1];
                    };
                }, {
                    readonly op: "replace";
                    readonly path: "/draft";
                    readonly value: "";
                }];
            }];
        };
        readonly toggle: {
            readonly patch: readonly [{
                readonly op: "replace";
                readonly path: "/items";
                readonly value: readonly [{
                    readonly $for: {
                        readonly i: "$.items[*]";
                    };
                    readonly $return: {
                        readonly $if: readonly [{
                            readonly $eq: readonly ["$i.id", "$payload.id"];
                        }, {
                            readonly id: "$i.id";
                            readonly text: "$i.text";
                            readonly done: {
                                readonly $not: "$i.done";
                            };
                        }, "$i"];
                    };
                }];
            }];
        };
        readonly remove: {
            readonly patch: readonly [{
                readonly op: "replace";
                readonly path: "/items";
                readonly value: readonly [{
                    readonly $for: {
                        readonly i: "$.items[*]";
                    };
                    readonly $where: {
                        readonly $ne: readonly ["$i.id", "$payload.id"];
                    };
                    readonly $return: "$i";
                }];
            }];
        };
    };
};
/** The operators the crib names, each one Jaren's: what an application needs for arithmetic, text, logic and lists. */
export declare const AUTHORING_OPERATORS: readonly ["$add", "$sub", "$mul", "$div", "$mod", "$round", "$floor", "$ceiling", "$abs", "$min", "$max", "$eq", "$ne", "$lt", "$gt", "$if", "$not", "$and", "$or", "$concat", "$string", "$number", "$lower", "$upper", "$contains", "$string-length", "$tokenize", "$normalize-space", "$count", "$sum", "$avg"];
/** The grammar crib an author model is given, with the seed as its one working example. */
export declare function authoringCrib(): string;
/** What the compiler cannot see: object-shaped vnodes and code written in strings. */
export declare function lintAuthoredApp(doc: unknown): string[];
/** The text a rendered tree shows, with each field's current value. */
export declare function textOfVnode(vnode: any): string;
/**
 * One use by the person. `find` names an element as they would see it: its
 * `role` (`button`, `field`, `checkbox`, `select`), a `name` pattern matched
 * case-insensitively against its label, placeholder, accessible name or text,
 * and `nth` among the matches.
 */
export type ProbeStep = {
    find: {
        role: 'button' | 'field' | 'checkbox' | 'select';
        name?: string;
        nth?: number;
    };
    type?: string;
    checked?: boolean;
};
/** A scripted use and what the screen shows after it: `text` that must appear, `absent` that must not. */
export type AppProbe = {
    steps: ProbeStep[];
    expect: {
        text?: string[];
        absent?: string[];
    };
};
export type AuthoringVerdict = {
    ok: boolean;
    problems: string[];
    shown?: string;
};
/** The checks a document passes before any use, synchronously: the lint, the compile and a first frame with text. */
export declare function gateAuthoredApp(doc: unknown): {
    problems: string[];
    firstText: string;
};
/** Run a document and every probe on it, model-free; the first problem names what to fix. */
export declare function checkAuthoredApp(doc: unknown, probes?: readonly AppProbe[]): Promise<AuthoringVerdict>;
/** The module an authored document becomes: a document module that asks for nothing and offers nothing. */
export declare function authoredManifest(doc: unknown, options: {
    id: string;
    title: LocalizedText;
    hue?: number;
}): ModuleManifest;
