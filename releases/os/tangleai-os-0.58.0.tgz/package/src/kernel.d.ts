import { type ModuleManifest, type ManifestIssue } from './manifest.ts';
import { type Header, type HeaderHandler } from './header.ts';
import { type DockLayout } from './dock.ts';
import { type DesktopStore, type StateScope } from './state.ts';
import { type CapabilityDocument } from './capability.ts';
import { type Consent } from './consent.ts';
export type Layer = 'shipped' | 'suite' | 'user';
export type JournalEntry = {
    seq: number;
    at: number;
    layer: Layer;
    module: string;
    kind: 'install' | 'patch' | 'remove';
    patch?: unknown[];
    inverse?: unknown[];
    consent?: Consent;
};
export type LedgerEntry = {
    seq: number;
    at: number;
    caller: string;
    contract: string;
    op: string;
    ok: boolean;
    code?: string;
    ms: number;
};
/**
 * A proposal in the inbox, kept by the kernel: its kind, status and sender come
 * from the module's port and manifest, never from what the module wrote.
 */
export type Proposal = {
    id: string;
    kind: string;
    status: 'pending' | 'deciding' | 'accepted' | 'rejected';
    summary?: string;
    payload?: unknown;
    evidence?: {
        label: string;
        href?: string;
    }[];
    revision?: string;
    origin?: 'human' | 'rule' | 'import' | 'ai';
    /** The answer it asks for: its JSON Schema and the button's words. */
    answer?: {
        schema: Record<string, unknown> | boolean;
        label?: string;
    };
    /** Why the last decision did not take effect; the proposal stays pending. */
    reason?: {
        code: string;
        message: string;
    };
};
export type MailEnvelope = {
    id: string;
    at: number;
    from: string;
    to: string;
    subject: string;
    body?: string;
    data?: unknown;
    read: boolean;
    proposal?: Proposal;
};
/** How a decision reaches the module that filed the proposal: its own control channel, never the bus. */
export type Decider = (decision: {
    id: string;
    kind: string;
    decision: 'accept' | 'reject' | 'answer';
    revision?: string;
    payload?: unknown;
    response?: unknown;
    roles?: string[];
}) => Promise<{
    refused?: string;
} | void> | {
    refused?: string;
} | void;
export type Outcome = {
    ok: true;
    value: unknown;
} | {
    ok: false;
    error: {
        code: string;
        message: string;
    };
};
/**
 * `header`: a window's header bar changed (`window`), or one of its items was
 * used (`item`, and `by`: `shell` for the person, else the caller).
 */
export type KernelEvent = {
    kind: 'modules' | 'mail' | 'ledger' | 'providers' | 'title' | 'settings' | 'header' | 'dock' | 'state';
    module?: string;
    title?: string;
    window?: string;
    item?: string;
    by?: string;
};
/**
 * Where the desktop keeps the values of a `form` module's settings (a module
 * with no server of its own). A host passes its own storage; the default keeps
 * them for the page's lifetime. Never secrets: a form refuses them.
 */
export type SettingsStore = {
    read(module: string): unknown;
    write(module: string, values: unknown): void;
};
/**
 * Where the desktop keeps its state: a store the host passes (its server
 * through `contractStore`, the browser through `webStorageStore`), or
 * `{ module }`, the installed application that serves `tangle_os_state`
 * once it connects (the one that is signed in to the server). Absent, the
 * state lives as long as the page.
 */
export type StateOption = DesktopStore | {
    module: string;
};
/** Whether the desktop's state can be read and changed: `loading` and `unavailable` change nothing. */
export type StateStatus = {
    status: 'loading' | 'ready' | 'unavailable';
    saving: number;
    failed: string | null;
};
/** The ids no module may take: the shell's own hand, the person, and the desktop that files its own proposals. */
export declare const RESERVED_IDS: readonly ["shell", "person", "desktop"];
/**
 * `tangle_os_files`: the kernel's own contract over every file location, for
 * the assistant. It lists, searches and reads (text, capped; a binary file as
 * its description), and never writes, moves or deletes; a location marked
 * `assistant: false` is not in it.
 */
export declare const FILES_CONTRACT: {
    readonly $contract: "0.1";
    readonly id: "tangle_os_files";
    readonly operations: {
        readonly 'files.locations': {
            readonly kind: "read";
            readonly doc: "The file locations: each application's files, and the person's own.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly properties: {};
            };
            readonly output: {
                readonly type: "object";
            };
        };
        readonly 'files.list': {
            readonly kind: "read";
            readonly doc: "The files and folders in one folder of a location (no folder for its top), a page at a time.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["location"];
                readonly properties: {
                    readonly location: {
                        type: string;
                        pattern: string;
                    };
                    readonly folder: {
                        readonly anyOf: readonly [{
                            readonly type: "string";
                            readonly maxLength: 1024;
                        }, {
                            readonly type: "null";
                        }];
                    };
                    readonly cursor: {
                        readonly type: "string";
                        readonly maxLength: 1024;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
            };
        };
        readonly 'files.search': {
            readonly kind: "read";
            readonly doc: "Files and folders whose name contains the query, in one location or in all of them.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["query"];
                readonly properties: {
                    readonly location: {
                        type: string;
                        pattern: string;
                    };
                    readonly query: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 200;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
            };
        };
        readonly 'files.read': {
            readonly kind: "read";
            readonly doc: "One file: the text of a text file (the first 6,000 characters), or what a binary file is.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["location", "id"];
                readonly properties: {
                    readonly location: {
                        type: string;
                        pattern: string;
                    };
                    readonly id: {
                        readonly type: "string";
                        readonly maxLength: 1024;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
            };
        };
    };
};
/** `tangle_os_dock`: the kernel's own contract over the person's dock, for the assistant and granted modules. */
export declare const DOCK_CONTRACT: {
    readonly $contract: "0.1";
    readonly id: "tangle_os_dock";
    readonly operations: {
        readonly 'dock.read': {
            readonly kind: "read";
            readonly doc: "The person's dock: its icons in order (an id is a module, or <module>/<entry> for one of its screens), its folders with their icons, the hidden icons, every icon's title, and the layout's revision.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly properties: {};
            };
            readonly output: {
                readonly type: "object";
            };
        };
        readonly 'dock.suggest': {
            readonly kind: "command";
            readonly doc: "Suggest a new arrangement of the dock (a layout document, as dock.read returns it). It goes to the person's inbox as a proposal they accept or reject; a new suggestion replaces your earlier one. Nothing changes until they accept.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["layout"];
                readonly properties: {
                    readonly layout: {
                        readonly type: "object";
                        readonly additionalProperties: false;
                        readonly required: readonly ["$dock", "items", "hidden"];
                        readonly properties: {
                            readonly $dock: {
                                readonly const: "0.1";
                            };
                            readonly items: {
                                readonly type: "array";
                                readonly maxItems: 400;
                                readonly items: {
                                    readonly anyOf: readonly [{
                                        readonly type: "string";
                                        readonly pattern: "^[A-Za-z0-9._:/-]{1,160}$";
                                    }, {
                                        readonly type: "object";
                                        readonly additionalProperties: false;
                                        readonly required: readonly ["folder", "items"];
                                        readonly properties: {
                                            readonly folder: {
                                                readonly type: "string";
                                                readonly pattern: "^[A-Za-z0-9._:-]{1,64}$";
                                            };
                                            readonly title: {
                                                readonly type: "string";
                                                readonly minLength: 1;
                                                readonly maxLength: 64;
                                            };
                                            readonly items: {
                                                readonly type: "array";
                                                readonly maxItems: 200;
                                                readonly items: {
                                                    readonly type: "string";
                                                    readonly pattern: "^[A-Za-z0-9._:/-]{1,160}$";
                                                };
                                            };
                                        };
                                    }];
                                };
                            };
                            readonly hidden: {
                                readonly type: "array";
                                readonly maxItems: 400;
                                readonly items: {
                                    readonly type: "string";
                                    readonly pattern: "^[A-Za-z0-9._:/-]{1,160}$";
                                };
                            };
                        };
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                    };
                };
            };
        };
    };
};
/** Any contract client: an object with `invoke`, as every Jaren binding returns. */
export type ContractClient = {
    invoke: (op: string, input: unknown, ctx?: unknown) => Promise<any>;
    close?: () => void;
};
/** A served contract: what `servePort` returns. */
export type ServedContract = {
    close?: () => void;
};
type Provider = {
    module: string;
    owner: string;
    contract: any;
    client: ContractClient;
};
/** One operation a caller may call, as plain data: what any agent stack needs to offer it as a tool. */
export type GrantedOperation = {
    tool: string;
    contract: string;
    op: string;
    kind: string;
    doc?: string;
    input?: unknown;
    output?: unknown;
};
/**
 * The host's tool builder, so the kernel names no agent runtime: Tangle's
 * `@tangleai/agents/toolbox` fits as it is (`createKernel({ tools: toolbox })`).
 */
export type ToolBuilder = {
    createToolbox: () => any;
    toolboxFromContract: (contract: any, client: {
        invoke: (op: string, input: unknown) => Promise<unknown>;
    }, options: {
        toolbox: any;
        ops: string[];
        name: (op: string) => string;
    }) => unknown;
};
/** A tool's name: `<contract>__<operation>` with every character outside [A-Za-z0-9_-] as `_`, at most 64. */
export declare const toolName: (contract: string, op: string) => string;
/**
 * `assistantGrants`: what the assistant may call — `'all'`, or scopes
 * (`contract.op`, `contract.*`). Nothing by default: a host decides.
 */
export declare function createKernel(options?: {
    recovery?: boolean;
    now?: () => number;
    assistantGrants?: 'all' | string[];
    tools?: ToolBuilder;
    settings?: SettingsStore;
    state?: StateOption;
}): {
    recovery: boolean;
    /**
     * Install a whole module in a layer. A shipped or suite module is granted
     * what it declares it requires, unless `grant: false`: a suite joined
     * from a link is installed without grants, so a link cannot hand a
     * module access. A contract another module already declares is refused.
     */
    install(value: unknown, layer?: Layer, install?: {
        grant?: boolean;
    }): {
        ok: true;
        manifest: ModuleManifest;
    } | {
        ok: false;
        issues: ManifestIssue[];
    };
    /**
     * Change an installed module with an RFC 6902 patch in a layer above its
     * own. The shipped document is never written; the result must still be a
     * valid manifest, or the patch is refused and nothing changes.
     */
    patch(id: string, patch: unknown[], layer?: Layer): Outcome;
    /** Remove a module a person installed. Shipped and suite modules are not removable, only hidden by a patch. */
    remove(id: string): Outcome;
    /** Undo the person's last change. */
    undo(): Outcome;
    effective(id: string): ModuleManifest | null;
    modules(): ModuleManifest[];
    layerOf(id: string): Layer | null;
    journal(): JournalEntry[];
    grant(caller: string, scope: string): void;
    revoke(caller: string, scope: string): void;
    /**
     * Install an application the person joined, in their layer, with exactly
     * what they allowed: `scopes` out of what its manifest asks for (`OS0140`
     * for one it does not ask for), and whether the assistant may use what it
     * provides. Kept in the person's state, so it is there on their next visit
     * and on their other devices; refused (`OS0121`) until that state loads.
     * Only the shell's install sheet, after the person's gesture, calls this.
     */
    join(value: unknown, allow: {
        scopes: string[];
        assistant: boolean;
        source?: string;
    }): Outcome;
    /** What the person allowed a joined application, or null for one they did not join. */
    consentOf(id: string): Consent | null;
    /** Whether installing this manifest needs the person's consent (again), against what they allowed before. */
    consentNeeded(value: ModuleManifest): {
        needed: false;
    } | {
        needed: true;
        reason: "new" | "origin" | "more";
        scopes: string[];
        provides: string[];
    };
    /** Change what a joined application may use, or whether the assistant may use it (`OS0141` for one not joined). */
    setConsent(id: string, change: {
        scopes?: string[];
        assistant?: boolean;
    }): Outcome;
    grants(): Record<string, string[]>;
    /** A `form` module's settings as the person set them (`{}` until they do); `{}` for a module that keeps its own. */
    settings(module: string): unknown;
    /**
     * The person sets a `form` module's settings in the desktop's Settings:
     * checked against the module's schema, kept, and reported (`settings`).
     * Refused for a module that keeps its own (`OS0105`) or values its schema
     * refuses (`OS0106`).
     */
    setSettings(module: string, values: unknown): Outcome;
    allowed(caller: string, contract: string, op: string): boolean;
    /**
     * Make a contract callable: the client reaches the module that serves it.
     * Only the module whose manifest declares the contract may serve it
     * (`OS0011` otherwise), so one module cannot take over another's.
     */
    provide(module: string, contractDoc: unknown, client: Provider["client"], owner?: string): void;
    /** A shipped module serves a contract from inside the page. */
    provideLocal(module: string, contractDoc: unknown, handlers: Record<string, (input: any) => unknown>, owner?: string): void;
    /** Withdraw what one owner (a window) registered; another window of the same module keeps serving. */
    withdraw(module: string, owner?: string): void;
    providers(): {
        contract: string;
        module: string;
        operations: string[];
    }[];
    /** The bus: one operation of one contract, for one caller, under grants, into the ledger. */
    call(caller: string, contract: string, op: string, input?: unknown): Promise<Outcome>;
    ledger(): LedgerEntry[];
    sendMail(from: string, envelope: {
        to?: string;
        subject: string;
        body?: string;
        data?: unknown;
    }): MailEnvelope;
    mail(): MailEnvelope[];
    markRead(id: string): void;
    /**
     * File a proposal in the inbox for the person. The kind must be one the
     * module's manifest declares (`OS0107`) and the proposal must match its
     * schema (`OS0108`); filing the same id again replaces it, pending again.
     * The module keeps its proposals: the inbox lives as long as the page.
     */
    propose(module: string, input: unknown): Outcome;
    /**
     * Install a capability (`CAPABILITY_SCHEMA`): its kinds and their review
     * policies become those of every module whose manifest names it. Only the
     * shipped and suite layers install one (`OS0130`): its prompt pack becomes
     * the assistant's system text, so a person's or the assistant's own layer
     * never writes it. Refused when it does not match (`OS0130`) or does not
     * agree with itself (`OS0131`).
     */
    installCapability(doc: unknown, layer?: Layer): Outcome;
    /** The installed capabilities. */
    capabilities(): CapabilityDocument[];
    /** The review policy of a module's kind: who may file it, and the roles that may decide it (a hint the module enforces). */
    reviewOf(module: string, kind: string): {
        origins?: string[];
        roles?: string[];
    } | null;
    /** Take back a module's pending proposal. */
    withdrawProposal(module: string, id: string): Outcome;
    /**
     * Where a module's decisions go while one of its windows can take them:
     * the shell registers the window's control channel. Returns the release.
     */
    registerDecider(module: string, owner: string, decide: Decider): () => void;
    /**
     * The person accepts or rejects a proposal. The decision goes to the
     * module that filed it, over its own channel, never as a contract
     * operation, so neither the assistant nor another module can decide. One
     * decision at a time; a module that is not running (`OS0110`), refuses
     * (`OS0112`, e.g. its revision moved) or fails leaves the proposal pending
     * with the reason.
     */
    decide(mailId: string, decision: "accept" | "reject" | "answer", response?: unknown): Promise<Outcome>;
    /** The modules that open a file of this type (`text/calendar`); a manifest's subtype or type may be a star. */
    openersFor(type: string): ModuleManifest[];
    /** Every file location the installed modules declare: its contract, title, whether the assistant may read it, and whether it is served now. */
    fileLocations(): {
        module: string;
        contract: string;
        title: string;
        assistant: boolean;
        served: boolean;
    }[];
    /** The person's saved dock layout, or null for one they have not arranged (a recovery boot ignores it). */
    dock(): DockLayout | null;
    /** A document of the desktop's state the host keeps for itself (its preferences): never a secret. */
    state(key: string, scope?: StateScope): unknown;
    /** Keep a document of the host's own; refused (`OS0121`) while the state is loading or could not be loaded. */
    setState(key: string, value: unknown, scope?: StateScope): Outcome;
    /** Resolves when the state's latest load has finished (loaded, or found unavailable). */
    ready(): Promise<void>;
    /** Whether the state is loaded, how many saves are on their way, and the last save failure. */
    stateStatus(): StateStatus;
    /** Load the state again (after it could not be loaded, or to take what another device changed). */
    reloadState(): Promise<void>;
    /** Resolves when every change made so far is saved (or has failed). */
    flushState(): Promise<void>;
    /** The layout's revision: it moves with every change, so a suggestion made against an older dock is refused. */
    dockRevision(): number;
    /** Keep a new dock layout (`OS0119` when it does not match the dock schema). */
    setDock(layout: unknown): Outcome;
    /** The dock as the installed modules and the saved layout make it, in English titles, with its revision. */
    dockView(): {
        revision: number;
        layout: DockLayout;
        items: ({
            icon: {
                id: string;
                title: string;
            };
            folder?: undefined;
            title?: undefined;
            icons?: undefined;
        } | {
            folder: string;
            title: string;
            icons: {
                id: string;
                title: string;
            }[];
            icon?: undefined;
        })[];
        hidden: {
            id: string;
            title: string;
        }[];
    };
    /**
     * File a suggested dock in the person's inbox, as the desktop's own
     * proposal; nothing changes until they accept it, and it is refused then
     * if the dock moved meanwhile. One suggestion per caller: a new one
     * replaces the last. The inbox shows what would change, derived here,
     * never the caller's description of it.
     */
    suggestDock(caller: string, layout: unknown): Outcome;
    /**
     * Set a window's header bar (`null` takes it away). The header must match
     * {@link HEADER_SCHEMA} with every id used once (`OS0113`); the window
     * belongs to the module that sets it.
     */
    setHeader(module: string, window: string, header: unknown): Outcome;
    /** A window's header bar now, with its state; undefined when it has none. */
    header(window: string): Header | undefined;
    /** Every window's header bar, as `caller` sees it (`assistant: false` items are kept from all but the shell). */
    headers(caller?: string): {
        window: string;
        module: string;
        header: Header;
    }[];
    /** Where a window's header activations go while it can take them. Returns the release. */
    registerHeaderHandler(module: string, window: string, handle: HeaderHandler): () => void;
    /** Whether a window can take header activations now (its application is connected). */
    hasHeaderHandler(window: string): boolean;
    /**
     * Use one item of a window's header bar: the one path for the person's
     * hand (`caller` `shell`) and for every granted caller. The desktop keeps
     * the item's state (a tab, a toggle, a search text) as soon as it is
     * used, and the application's next header wins. Refused when the window
     * has no header (`OS0114`), the item is absent (`OS0114`), disabled or
     * kept from this caller (`OS0115`), the value does not fit it (`OS0116`),
     * the application is not connected (`OS0117`) or it refuses (`OS0118`).
     */
    activateHeader(caller: string, window: string, item: string, value?: unknown): Promise<Outcome>;
    /**
     * Serve `tangle_os` to one module over its own port. The module's id is
     * bound here, by the port it was handed, never taken from its input.
     */
    serveModule(module: string, port: any, hooks?: {
        setTitle?: (title: string) => void;
        openSettings?: () => void;
        window?: string;
    }): ServedContract;
    /** Open a client on a port where a module serves one of its contracts, and make it callable. */
    connectProvider(module: string, contractDoc: unknown, port: any, timeoutMs?: number, owner?: string): ContractClient;
    /**
     * Every served operation `caller` may call, as plain data (tool name,
     * contract, operation, kind, description, input and output schemas): an
     * application with its own agent runtime offers these as tools and calls
     * back through `call`, so grants and the ledger still apply.
     */
    operations(caller?: string): GrantedOperation[];
    /**
     * The assistant's tools: every served contract the assistant may call, as
     * model tools built by the host's tool builder, each routed through `call`
     * so grants and the ledger apply. Names are {@link toolName}.
     */
    tools(caller?: string): any;
    subscribe(listener: (event: KernelEvent) => void): () => boolean;
};
export type Kernel = ReturnType<typeof createKernel>;
export {};
