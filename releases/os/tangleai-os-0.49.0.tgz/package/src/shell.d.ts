import { type ModuleManifest } from './manifest.ts';
import { type ThemeDocument } from './theme.ts';
import { type OsCatalogue } from './messages.ts';
import { type Desktop } from './windows.ts';
import type { Kernel } from './kernel.ts';
export type ShippedContext = {
    module: ModuleManifest;
    window: string;
    call(contract: string, op: string, input?: unknown): ReturnType<Kernel['call']>;
    sendMail(envelope: {
        to?: string;
        subject: string;
        body?: string;
        data?: unknown;
    }): void;
    setTitle(title: string): void;
    provide(contract: unknown, handlers: Record<string, (input: any) => unknown>): void;
    locale: string;
    dir: 'ltr' | 'rtl';
};
/** A shipped component: mounts into a window's content node and returns its disposer. */
export type ShippedMount = (node: HTMLElement, context: ShippedContext) => (() => void) | void;
export type DesktopOptions = {
    kernel: Kernel;
    shipped?: Record<string, ShippedMount>;
    /** URL of the page that loads the document module host as a classic script. */
    documentHost?: string;
    theme?: ThemeDocument;
    /**
     * The theme the dock's light/dark switch moves to; defaults to the built-in
     * pair. A host with a person's own colours returns their variant here.
     */
    themeFor?: (scheme: 'light' | 'dark') => ThemeDocument;
    /** Called after the person switches between light and dark from the dock or a menu. */
    onSchemeSwitch?: (scheme: 'light' | 'dark') => void;
    locale?: string;
    dir?: 'ltr' | 'rtl';
    messages?: Partial<OsCatalogue>;
    /** Defaults to the node's owner window. */
    window?: Window;
    onError?: (error: unknown) => void;
};
/**
 * Why an application page may not be framed as an origin module, or null.
 * A page on the desktop's own origin would be framed with that origin's
 * rights and could read the desktop's storage and keys (all project sites of
 * one GitHub Pages account share an origin), so it is refused.
 */
export declare function originHostProblem(url: string, desktopOrigin: string | undefined): string | null;
export declare function mountDesktop(node: HTMLElement, options: DesktopOptions): {
    open: (moduleId: string) => string | null;
    close: (id: string) => void;
    focus: (id: string) => void;
    minimize: (id: string) => void;
    maximize: (id: string) => void;
    move: (id: string, x: number, y: number) => void;
    state: () => Desktop;
    setTheme: (next: ThemeDocument) => void;
    setLocale: (next: {
        locale: string;
        dir: "ltr" | "rtl";
    }) => void;
    theme: () => ThemeDocument;
    /** The framed module's own context row, for the assistant. */
    context: (id: string) => any;
    dispose(): void;
};
export type DesktopHandle = ReturnType<typeof mountDesktop>;
