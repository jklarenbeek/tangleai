/**
 * Window state as a JSON document with pure transitions: what is open, where,
 * in which order, and which window has focus. The shell renders it; the tests
 * drive it headless. Nothing here touches the DOM.
 */
export type Rect = {
    x: number;
    y: number;
    w: number;
    h: number;
};
export type WindowState = {
    id: string;
    module: string;
    title: string;
    rect: Rect;
    /** The rect to return to from maximized. */
    restore?: Rect;
    z: number;
    minimized: boolean;
    maximized: boolean;
};
export type Desktop = {
    windows: WindowState[];
    focus: string | null;
    nextId: number;
    viewport: {
        w: number;
        h: number;
    };
};
export type WindowRequest = {
    module: string;
    title: string;
    width?: number;
    height?: number;
    minWidth?: number;
    minHeight?: number;
    singleton?: boolean;
};
export declare const emptyDesktop: (viewport?: {
    w: number;
    h: number;
}) => Desktop;
export declare function fit(rect: Rect, viewport: Desktop['viewport'], min?: {
    w: number;
    h: number;
}): Rect;
/** Open a window, or focus the existing one of a single-instance module. Cascades new windows. */
export declare function openWindow(d: Desktop, request: WindowRequest): Desktop;
export declare function focusWindow(d: Desktop, id: string): Desktop;
export declare function closeWindow(d: Desktop, id: string): Desktop;
export declare function moveWindow(d: Desktop, id: string, x: number, y: number): Desktop;
export declare function resizeWindow(d: Desktop, id: string, width: number, height: number, min?: {
    w: number;
    h: number;
}): Desktop;
export declare function toggleMaximize(d: Desktop, id: string): Desktop;
export declare function minimizeWindow(d: Desktop, id: string): Desktop;
export declare function setTitle(d: Desktop, id: string, title: string): Desktop;
/** A new viewport keeps every window reachable and maximized windows full size. */
export declare function setViewport(d: Desktop, viewport: Desktop['viewport']): Desktop;
/** Windows in stacking order, bottom first. */
export declare const stacked: (d: Desktop) => WindowState[];
