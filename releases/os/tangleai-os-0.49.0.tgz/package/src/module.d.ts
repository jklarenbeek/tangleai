import { type ConnectMessage } from './contracts.ts';
export type ModuleHandlers = Record<string, (input: any) => unknown>;
export type ConnectOptions = {
    /** Contract documents this page serves, by contract id, with their handlers. */
    serve?: {
        contract: unknown;
        handlers: ModuleHandlers;
    }[];
    /** Origins of desktops allowed to frame this page: exact origins, or `'parent'` to accept the framing window whatever its origin (the sandboxed module host). */
    origins: string[] | 'parent';
    /** Called with token values after they are applied to the document root. */
    onTheme?: (theme: {
        tokens: Record<string, string>;
        scheme?: 'light' | 'dark';
    }) => void;
    onLocale?: (locale: {
        locale: string;
        dir: 'ltr' | 'rtl';
    }) => void;
    /** A compact description of what the page shows now, for the assistant. */
    context?: () => unknown;
    /** The window that sends the ports; the page's parent by default. */
    host?: {
        parent: any;
        addEventListener: (type: string, listener: (event: any) => void) => void;
        removeEventListener: (type: string, listener: (event: any) => void) => void;
        document?: any;
    };
    timeoutMs?: number;
};
export type OsConnection = {
    module: string;
    connect: ConnectMessage;
    call(contract: string, op: string, input?: unknown): Promise<any>;
    sendMail(envelope: {
        to?: string;
        subject: string;
        body?: string;
        data?: unknown;
    }): Promise<any>;
    setTitle(title: string): Promise<any>;
    close(): void;
};
/** Set token values as custom properties on a root element, and the colour scheme. */
export declare function applyTheme(root: any, theme: {
    tokens: Record<string, string>;
    scheme?: 'light' | 'dark';
}): void;
export declare function applyLocale(root: any, locale: {
    locale: string;
    dir: 'ltr' | 'rtl';
}): void;
/**
 * Join the desktop that frames this page. Resolves once the shell has handed
 * over its ports; a message from a window that is not the parent, or from an
 * origin not listed, is ignored.
 */
export declare function connectToOs(options: ConnectOptions): Promise<OsConnection>;
