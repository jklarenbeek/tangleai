import { type OsCatalogue, type OsMessageKey } from './messages.ts';
import { type JobEvent, type JobQueue, type JobRuntimeHealth, type JobSchedule, type JobState, type RegisteredJob } from './jobs.ts';
import type { ModuleManifest } from './manifest.ts';
import type { ShippedMount } from './shell.ts';
export type JobsOptions = {
    /** The host's queue: the desktop's kernel `jobQueue()`, or `unconfiguredJobQueue()` where it has none. */
    queue: JobQueue;
    /** Where the person names a job host (the host's own Settings section); the desktop's Settings by default. */
    configure?: () => void;
    messages?: Partial<OsCatalogue>;
    /** The language `messages` is in: dates, numbers and the title of Jobs in it. */
    locale?: string;
    /** The zone data a floating rule's runs are computed with (`@jarenjs/locales/intl-zones`, for example). */
    zoneProvider?: unknown;
    id?: string;
    /** The clock (tests). */
    now?: () => number;
    /** Whether this tab's own worker runs the host's background runtime (the browser twin); said on the heartbeat line. */
    ownsRuntime?: () => boolean;
    /** How often an open, visible Jobs window reads again, in milliseconds (default 10 s). */
    refreshMs?: number;
};
type Translate = (key: OsMessageKey, values?: Record<string, string | number>) => string;
type Series = {
    kind?: string;
    dtstart?: {
        kind?: string;
        date?: string;
        time?: string;
        instant?: string;
        zone?: string;
    };
    rrule?: Record<string, unknown>;
    policy?: string;
};
/** The order the desktop lists states in: what needs a person first. */
export declare const STATE_ORDER: readonly JobState[];
/**
 * A schedule's rule in words: every so many seconds, minutes or hours; a day,
 * days of the week or days of the month at their times. A rule it cannot say
 * plainly is shown as its RRULE text.
 */
export declare function describeRule(series: Series, zone: string | null, t: Translate, locale?: string): string;
/** One run as the desktop shows it: its instant, its identity in the schedule (Jaren's recurrence id), and whether a clock change moved it (`gap`) or it falls in a repeated hour (`fold`). */
export type NextRun = {
    at: number;
    recurrenceId?: string;
    mark?: 'gap' | 'fold';
};
/**
 * The next `n` runs of a schedule after `from`, computed from its rule with
 * Jaren's calendar. A utc or zoned rule needs nothing more; a floating one is
 * bound in `zone` with `zoneProvider` and its policy, and `null` answers when
 * either is missing (the runs are not guessed).
 */
export declare function nextRuns(series: Series, zone: string | null, n: number, from: number, zoneProvider?: unknown): NextRun[] | null;
/** The small job a schedule fires to enqueue the real one: kept out of the list and the waiting count. */
export declare const FIRE_KIND = "ops.fire";
/** The code of a background runtime that has not answered yet (the browser twin starting or changing tabs). */
export declare const STARTING = "OS0195";
/** How long the runtime may be silent before Jobs warns: three missed 30-second heartbeats. */
export declare const STALE_AFTER_MS = 90000;
/** One attempt of a job as the history tells it: its start, its outcome, and whether it was not repeated or refused by a budget. */
export type AttemptRow = {
    attempt: number;
    started?: JobEvent;
    outcome?: JobEvent;
    notRepeated: boolean;
    budget: boolean;
};
/** A job's events as its attempts, oldest first. */
export declare function attemptRows(events: readonly JobEvent[]): AttemptRow[];
/** How long ago the freshest runtime reported, by the host's clock; `null` when no runtime reports. */
export declare function runtimeAge(health: {
    now: number;
    runtimes: readonly JobRuntimeHealth[];
} | null): number | null;
/**
 * A schedule's runs in a range, as a calendar shows them. A run is one item at its instant; a schedule that runs more
 * often than daily (every so many seconds, minutes or hours) is one summary item a day with its number of runs — a
 * calendar shows "every minute, 1,440 runs", never 1,440 items. `date` is the day in the viewer's zone. `recurrenceId`
 * is the run's identity in its schedule (the wall time Jaren names it by), so `<scheduleId>@<recurrenceId>` names one run.
 */
export type ScheduledRun = {
    type: 'run';
    at: number;
    date: string;
    title: string;
    scheduleId: string;
    kind: string;
    recurrenceId: string;
    mark?: 'gap' | 'fold';
} | {
    type: 'summary';
    date: string;
    count: number;
    title: string;
    scheduleId: string;
    kind: string;
};
/**
 * The runs of the host's active schedules between `from` and `to` (instants), each by the registered job's title in
 * `locale` (falling back to English, then the schedule's kind). A schedule whose runs cannot be computed (a floating
 * rule without zone data) and a schedule that is not active have no runs here.
 */
export declare function scheduledRuns(schedules: readonly JobSchedule[], registry: readonly RegisteredJob[], from: number, to: number, options?: {
    locale?: string;
    zoneProvider?: unknown;
    viewZone?: string;
}): ScheduledRun[];
/** The Jobs module: its manifest and its mount. */
export declare function jobsModule(options: JobsOptions): {
    manifest: ModuleManifest;
    mount: ShippedMount;
};
export {};
