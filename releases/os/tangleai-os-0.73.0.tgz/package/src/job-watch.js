/**
 * The desktop's job watcher: background work that needs a person reaches
 * them. Over the host's job queue (the `job_queue` contract, `jobs.ts`) it
 * reads, once an interval, the dead jobs, the history since its last read and
 * the runtimes' heartbeats, and files ONE inbox item per job or runtime
 * through the kernel (`fileJobFailure`, `fileRuntimeSilent`): a dead job, a
 * single-send job a crash cut off (`not-repeated`), a job that keeps failing
 * (a third failed attempt), and a background runtime that stopped reporting.
 * An item is updated, never duplicated; a runtime that reports again takes its
 * item back.
 *
 * The item is filed at once — it is in the inbox and in Jobs immediately. Its
 * NOTICE (the item's `attention`, which the dock's mail button shows) is given
 * only inside the person's working hours; outside them, or when the hours are
 * unknown, it waits (unknown time is never working time), and when a working
 * period begins every item still open is noticed again. What the person
 * decided is remembered (`remember`), so a dismissed failure is not filed
 * again after a reload unless the job failed anew.
 */
import { JOB_CODES } from "./jobs.js";
/** How long a runtime may be silent before the person hears of it (as the Jobs app's warning). */
export const SILENT_AFTER_MS = 90_000;
const DAYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
/** Whether `at` falls inside the working hours (in `zone`); unknown hours are never working time. */
export function withinHours(at, hours, zone) {
    if (!hours || !hours.days?.length || !/^\d{2}:\d{2}$/.test(hours.start) || !/^\d{2}:\d{2}$/.test(hours.end))
        return false;
    let parts;
    try {
        parts = new Intl.DateTimeFormat('en-US', { timeZone: zone, weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(at);
    }
    catch {
        return false;
    }
    const get = (type) => parts.find(p => p.type === type)?.value ?? '';
    const day = DAYS[['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(get('weekday'))];
    const time = `${get('hour').padStart(2, '0')}:${get('minute').padStart(2, '0')}`;
    return hours.days.includes(day) && time >= hours.start && time < hours.end;
}
/** Start watching; the first look is immediate. `tick()` looks once (tests drive it); `stop()` ends the watch. */
export function watchJobs(options) {
    const { kernel, queue } = options;
    const now = options.now ?? Date.now;
    const silentAfter = options.silentAfterMs ?? SILENT_AFTER_MS;
    const setTimer = options.setTimer ?? ((run, ms) => setInterval(run, ms));
    const clearTimer = options.clearTimer ?? ((handle) => clearInterval(handle));
    let after, titles = null, wasWorking = null, stopped = false;
    const notRepeated = new Set();
    const decided = (() => { try {
        return { ...(options.remember?.load() ?? {}) };
    }
    catch {
        return {};
    } })();
    const ours = () => kernel.mail().filter(m => m.from === 'desktop' && (m.proposal?.kind === 'job.failed' || m.proposal?.kind === 'runtime.silent'));
    async function look() {
        const at = now();
        const working = withinHours(at, options.hours?.(), options.zone);
        // a working period begins: every item still open is noticed again
        if (working && wasWorking === false)
            for (const m of ours())
                if (m.proposal.status === 'pending')
                    kernel.noticeMail(m.proposal.id);
        wasWorking = working;
        // what the person decided is remembered, so a reload does not file it again
        let changed = false;
        for (const m of ours()) {
            const p = m.proposal, payload = p.payload;
            if (p.kind === 'job.failed' && (p.status === 'accepted' || p.status === 'rejected') && payload?.jobId && decided[payload.jobId] !== payload.attempts) {
                decided[payload.jobId] = payload.attempts ?? 0;
                changed = true;
            }
        }
        if (changed)
            try {
                options.remember?.save(decided);
            }
            catch { /* kept for this page */ }
        if (!titles)
            titles = await queue.registry().then(r => new Map(r.jobs.map(j => [j.kind, j])), () => null);
        const file = (jobId, kind, reason, attempts, lastError) => {
            if (decided[jobId] === attempts)
                return;
            const registered = titles?.get(kind);
            kernel.fileJobFailure({ jobId, kind, reason, attempts, attention: working, ...(registered ? { titles: registered.title, ...(registered.owner ? { owner: registered.owner } : {}) } : {}), ...(lastError ? { lastError } : {}) });
        };
        // the history since the last look: a single-send job a crash cut off, a job on its third failed attempt
        const { events } = await queue.events({ ...(after !== undefined ? { after } : {}), limit: 200 });
        for (const e of events) {
            after = Math.max(after ?? 0, e.at);
            if (e.event === 'not-repeated' && e.jobId)
                notRepeated.add(e.jobId);
        }
        for (const e of events) {
            if (e.event !== 'failed' || !e.jobId || (e.attempt ?? 0) < 3)
                continue;
            const job = await queue.get({ id: e.jobId }).catch(() => null);
            if (job?.state === 'failed')
                file(job.id, job.kind, 'failing', job.attempts, job.lastError?.message);
        }
        // the dead jobs
        const { items } = await queue.page({ state: 'dead', limit: 200 });
        for (const job of items)
            file(job.id, job.kind, notRepeated.has(job.id) ? 'not-repeated' : 'dead', job.attempts, job.lastError?.message);
        // runtimes that stopped reporting, and those that report again
        const health = await queue.health();
        for (const r of health.runtimes) {
            if (health.now - r.at > silentAfter)
                kernel.fileRuntimeSilent({ runtime: r.runtime, lastSeen: r.at, attention: working });
            else
                kernel.withdrawDesktop(`runtime-silent-${r.runtime}`.replace(/[^A-Za-z0-9._:-]/g, '_').slice(0, 128));
        }
    }
    let running = null;
    const once = () => {
        running = (async () => {
            try {
                await look();
            }
            catch (error) {
                if (error?.code !== JOB_CODES.unconfigured && error?.code !== JOB_CODES.starting)
                    throw error;
            }
        })().finally(() => { running = null; });
        return running;
    };
    /** One look; a look already under way is waited for first, so what changed since is seen. */
    const tick = async () => {
        while (running)
            await running.catch(() => { });
        if (stopped)
            return;
        return once();
    };
    // the interval never piles looks up: one under way is enough
    const run = () => { if (!running && !stopped)
        void once().catch(() => { }); };
    const handle = setTimer(run, options.intervalMs ?? 30_000);
    run();
    return { tick, stop: () => { stopped = true; clearTimer(handle); } };
}
