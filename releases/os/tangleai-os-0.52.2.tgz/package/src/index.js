/**
 * @tangleai/os — the browser operating system for Tangle suites.
 *
 * The root entry is headless: manifests, the kernel, window state, themes and
 * the message catalogue. The DOM shell is `@tangleai/os/shell`; an application
 * page joins a desktop with `@tangleai/os/module`; a host bundles
 * `@tangleai/os/module-host` once as a classic script for document modules.
 */
export { MODULE_MANIFEST_SCHEMA, validateManifest, localized } from "./manifest.js";
export { createKernel, toolName } from "./kernel.js";
export { OS_CONTRACT, MODULE_CONTRACT, PROPOSAL_SCHEMA, DECISION_SCHEMA, systemContracts, CONNECT, HELLO, KEY, FOCUS, PROTOCOL } from "./contracts.js";
export { emptyDesktop, openWindow, focusWindow, closeWindow, moveWindow, resizeWindow, toggleMaximize, minimizeWindow, setTitle, setViewport, setCompact, resizeDesktop, isVisible, stacked, fit, } from "./windows.js";
export { DEFAULT_THEMES, AURORA, checkTheme } from "./theme.js";
export { weaveSvg, weaveBackground, PATTERNS, patternBackground } from "./wallpaper.js";
export { THEME_KITS, composeTheme } from "./themes.js";
export { osMessagesEn, createOsMessages, format } from "./messages.js";
