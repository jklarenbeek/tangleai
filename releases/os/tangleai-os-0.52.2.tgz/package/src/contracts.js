/**
 * The two contracts every module connection carries.
 *
 * `tangle_os` is served by the kernel to one module over that module's own
 * port, so the caller's identity is the port, never a claim in the input:
 * a module cannot call as another. `tangle_os_module` is served by every
 * framed module back to the shell, for what the shell pushes to it (theme,
 * language) and what it reports (its compact context row).
 */
import { compileContract } from '@jarenjs/contract';
const text = { type: 'string', maxLength: 20000 };
const json = {};
/**
 * A proposal a module files for the person to accept or reject. Plain JSON,
 * bounded: the desktop shows it as text, links only to http(s) pages, and
 * never runs anything from it. The module keeps the proposal and decides what
 * accepting it does; `revision` is what it expects to still be true then.
 */
export const PROPOSAL_SCHEMA = {
    type: 'object', additionalProperties: false, required: ['id', 'kind', 'title'],
    properties: {
        id: { type: 'string', pattern: '^[A-Za-z0-9._:-]{1,128}$' },
        kind: { type: 'string', pattern: '^[a-z][a-z0-9.-]{0,63}$' },
        title: { type: 'string', minLength: 1, maxLength: 200 },
        summary: { type: 'string', maxLength: 2000 },
        payload: json,
        evidence: {
            type: 'array', maxItems: 12,
            items: { type: 'object', additionalProperties: false, required: ['label'], properties: { label: { type: 'string', minLength: 1, maxLength: 200 }, href: { type: 'string', maxLength: 2000, pattern: '^https?://' } } },
        },
        revision: { type: 'string', maxLength: 128 },
    },
};
/** What the desktop carries back to the module that filed a proposal. */
export const DECISION_SCHEMA = {
    type: 'object', additionalProperties: false, required: ['id', 'kind', 'decision'],
    properties: { id: PROPOSAL_SCHEMA.properties.id, kind: PROPOSAL_SCHEMA.properties.kind, decision: { enum: ['accept', 'reject'] }, revision: { type: 'string', maxLength: 128 }, payload: json },
};
export const OS_CONTRACT = {
    $contract: '0.1',
    id: 'tangle_os',
    operations: {
        'os.call': {
            kind: 'command',
            doc: 'Call an operation another module serves. Refused unless this module was granted it.',
            input: {
                type: 'object', additionalProperties: false, required: ['contract', 'op'],
                properties: { contract: { type: 'string', pattern: '^[A-Za-z_][A-Za-z0-9_-]*$' }, op: { type: 'string', minLength: 1, maxLength: 128 }, input: json },
            },
            output: json,
        },
        'mail.send': {
            kind: 'command',
            doc: 'Send a message to the person, or to another module, through the desktop mail.',
            input: {
                type: 'object', additionalProperties: false, required: ['subject'],
                properties: {
                    to: { type: 'string', pattern: '^(person|[a-z][a-z0-9-]{0,63})$' },
                    subject: { type: 'string', minLength: 1, maxLength: 200 },
                    body: text,
                    data: json,
                },
            },
            output: { type: 'object', required: ['id'], properties: { id: { type: 'string' } } },
        },
        'window.title': {
            kind: 'command',
            doc: 'Set the title of this module\'s window.',
            input: { type: 'object', additionalProperties: false, required: ['title'], properties: { title: { type: 'string', maxLength: 200 } } },
            output: { type: 'object' },
        },
        'mail.propose': {
            kind: 'command',
            doc: 'File a proposal in the desktop\'s inbox for the person to accept or reject; filing the same id again replaces it.',
            input: PROPOSAL_SCHEMA,
            output: { type: 'object', required: ['id'], properties: { id: { type: 'string' } } },
        },
        'mail.withdraw': {
            kind: 'command',
            doc: 'Take back one of this module\'s proposals that is still pending.',
            input: { type: 'object', additionalProperties: false, required: ['id'], properties: { id: PROPOSAL_SCHEMA.properties.id } },
            output: { type: 'object' },
        },
        'settings.get': {
            kind: 'read',
            doc: 'This module\'s settings as the person set them in the desktop\'s Settings (a form module\'s values; empty for one that keeps its own).',
            input: { type: 'object', additionalProperties: false, properties: {} },
            output: { type: 'object', properties: { values: json } },
        },
        'settings.open': {
            kind: 'command',
            doc: 'Open the desktop\'s Settings at this module\'s own section.',
            input: { type: 'object', additionalProperties: false, properties: {} },
            output: { type: 'object' },
        },
    },
};
export const MODULE_CONTRACT = {
    $contract: '0.1',
    id: 'tangle_os_module',
    operations: {
        'module.theme': {
            kind: 'command',
            doc: 'The desktop theme: token values to set on the module\'s root.',
            input: {
                type: 'object', additionalProperties: false, required: ['tokens'],
                properties: { tokens: { type: 'object', additionalProperties: { type: 'string', maxLength: 400 } }, scheme: { enum: ['light', 'dark'] } },
            },
            output: { type: 'object' },
        },
        'module.locale': {
            kind: 'command',
            doc: 'The person\'s language and writing direction.',
            input: { type: 'object', additionalProperties: false, required: ['locale', 'dir'], properties: { locale: { type: 'string', maxLength: 16 }, dir: { enum: ['ltr', 'rtl'] } } },
            output: { type: 'object' },
        },
        'module.settings': {
            kind: 'command',
            doc: 'The module\'s settings changed in the desktop\'s Settings: its new values.',
            input: { type: 'object', additionalProperties: false, properties: { values: json } },
            output: { type: 'object' },
        },
        'module.decide': {
            kind: 'command',
            doc: 'The person accepted or rejected one of the module\'s proposals. The module carries it out, or refuses with the reason (`refused`), for example when the revision moved.',
            input: DECISION_SCHEMA,
            output: { type: 'object', properties: { refused: { type: 'string', maxLength: 400 } } },
        },
        'module.context': {
            kind: 'read',
            doc: 'A compact description of what the module shows now, for the assistant.',
            input: { type: 'object', additionalProperties: false, properties: {} },
            output: { type: 'object' },
        },
    },
};
let compiled = null;
/** Compiled once on first use, so importing the package compiles nothing. */
export function systemContracts() {
    compiled ??= { os: compileContract(OS_CONTRACT), module: compileContract(MODULE_CONTRACT) };
    return compiled;
}
/** The message a host posts with the ports, and the module side checks. */
export const CONNECT = 'tangle-os.connect';
/** What a framed page posts to its parent when it is ready for the ports. */
export const HELLO = 'tangle-os.hello';
/** A pointer pressed inside a frame: raise its window. */
export const FOCUS = 'tangle-os.focus';
/** A desktop shortcut pressed inside a frame. */
export const KEY = 'tangle-os.key';
export const PROTOCOL = 1;
