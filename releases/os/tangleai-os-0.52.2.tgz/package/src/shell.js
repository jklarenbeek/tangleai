/**
 * The desktop shell: renders the window document, hosts each module in its
 * window, and connects framed modules to the kernel over ports. Shipped code,
 * so it may use the DOM directly; what it shows comes from the kernel's
 * manifests, the theme document and the message catalogue.
 */
import { openPortClient } from '@jarenjs/contract/port';
import { localized } from "./manifest.js";
import { CONNECT, FOCUS, HELLO, KEY, PROTOCOL, systemContracts } from "./contracts.js";
import { DEFAULT_THEMES, checkTheme } from "./theme.js";
import { patternBackground } from "./wallpaper.js";
import { createOsMessages } from "./messages.js";
import { applyTheme, applyLocale } from "./module.js";
import { closeWindow, emptyDesktop, focusWindow, isVisible, minimizeWindow, moveWindow, openWindow, resizeDesktop, resizeWindow, setTitle, stacked, toggleMaximize, } from "./windows.js";
const svg = (path) => `<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true" focusable="false"><path d="${path}" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>`;
const ICON = { close: svg('M4 4l8 8M12 4l-8 8'), minimize: svg('M4 8h8'), maximize: svg('M4.5 4.5h7v7h-7z'), restore: svg('M6 4h6v6M4 6h6v6H4z') };
/**
 * Why an application page may not be framed as an origin module, or null.
 * A page on the desktop's own origin would be framed with that origin's
 * rights and could read the desktop's storage and keys (all project sites of
 * one GitHub Pages account share an origin), so it is refused.
 */
export function originHostProblem(url, desktopOrigin) {
    let target;
    try {
        target = new URL(url);
    }
    catch {
        return `'${url}' is not a URL`;
    }
    if (target.protocol !== 'https:' && target.protocol !== 'http:')
        return `'${url}' is not an http(s) page`;
    if (desktopOrigin && target.origin === desktopOrigin)
        return `'${url}' shares the desktop's origin; an application must be served from its own origin`;
    return null;
}
export function mountDesktop(node, options) {
    const { kernel } = options;
    const win = options.window ?? node.ownerDocument.defaultView;
    const doc = node.ownerDocument;
    const t = createOsMessages(options.messages);
    const report = options.onError ?? ((error) => win.console?.error?.(error));
    let theme = options.theme ?? DEFAULT_THEMES[win.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'];
    let locale = { locale: options.locale ?? 'en', dir: options.dir ?? 'ltr' };
    let desktop = emptyDesktop({ w: node.clientWidth || 1280, h: node.clientHeight || 800 });
    const mounted = new Map();
    // ── structure ───────────────────────────────────────────────────────────
    node.classList.add('tos');
    node.setAttribute('role', 'application');
    node.setAttribute('aria-label', t('desktop/label'));
    const wallpaper = doc.createElement('div');
    wallpaper.className = 'tos-wallpaper';
    const layer = doc.createElement('div');
    layer.className = 'tos-windows';
    const shield = doc.createElement('div');
    shield.className = 'tos-shield';
    shield.hidden = true;
    const dock = doc.createElement('nav');
    dock.className = 'tos-dock';
    dock.setAttribute('aria-label', t('dock/label'));
    const mailPanel = doc.createElement('section');
    mailPanel.className = 'tos-mail';
    mailPanel.hidden = true;
    mailPanel.setAttribute('aria-label', t('mail/title'));
    node.replaceChildren(wallpaper, layer, shield, mailPanel, dock);
    // ── events ────────────────────────────────────────────────────────────────
    const listeners = new Set();
    const visibility = new Map();
    const copy = (w) => JSON.parse(JSON.stringify(w));
    function changes(prev, next) {
        const out = [];
        const push = (type, w) => out.push({ type, window: w.id, module: w.module, state: copy(w) });
        const before = new Map(prev.windows.map(w => [w.id, w]));
        for (const w of next.windows) {
            const was = before.get(w.id);
            if (!was) {
                push('opened', w);
                continue;
            }
            if (!was.minimized && w.minimized)
                push('minimized', w);
            else if (was.minimized && !w.minimized)
                push('restored', w);
            if (!was.maximized && w.maximized)
                push('maximized', w);
            else if (was.maximized && !w.maximized)
                push('restored', w);
            else {
                if (was.rect.x !== w.rect.x || was.rect.y !== w.rect.y)
                    push('moved', w);
                if (was.rect.w !== w.rect.w || was.rect.h !== w.rect.h)
                    push('resized', w);
            }
            if (was.title !== w.title)
                push('retitled', w);
        }
        for (const was of prev.windows)
            if (!next.windows.some(w => w.id === was.id))
                push('closed', was);
        const focused = next.focus !== prev.focus || next.windows.find(w => w.id === next.focus)?.z !== prev.windows.find(w => w.id === next.focus)?.z
            ? next.windows.find(w => w.id === next.focus) : undefined;
        if (focused)
            push('focused', focused);
        return out;
    }
    /** Every change of the desktop goes through here: it renders, tells modules what is on screen, and reports. */
    function setDesktop(next) {
        const prev = desktop;
        desktop = next;
        render();
        for (const [id, entry] of visibility) {
            const w = desktop.windows.find(x => x.id === id);
            const visible = w ? isVisible(desktop, w) : false;
            if (visible === entry.visible)
                continue;
            entry.visible = visible;
            for (const listener of [...entry.listeners]) {
                try {
                    listener(visible);
                }
                catch (error) {
                    report(error);
                }
            }
        }
        if (listeners.size)
            for (const event of changes(prev, next))
                tell(event);
    }
    function tell(event) { for (const listener of [...listeners]) {
        try {
            listener(event);
        }
        catch (error) {
            report(error);
        }
    } }
    /** A module's lifecycle in its window, reported beside the window changes. */
    function lifecycle(type, id) {
        const w = desktop.windows.find(x => x.id === id);
        if (w)
            tell({ type, window: w.id, module: w.module, state: copy(w) });
    }
    const resized = (d, viewport) => resizeDesktop(d, viewport, options.compact !== undefined && viewport.w < options.compact.below);
    // ── theme and language ────────────────────────────────────────────────────
    function applyShellTheme(next) {
        const problems = checkTheme(next);
        if (problems.length)
            throw new Error(`the theme is refused: ${problems.join('; ')}`);
        theme = next;
        applyTheme(node, { tokens: next.tokens, scheme: next.scheme });
        // a procedural wallpaper is drawn from the theme's colours and seed; any other value is CSS
        const tk = next.tokens;
        wallpaper.style.background = patternBackground(tk) ?? '';
        for (const m of mounted.values())
            m.moduleClient?.invoke('module.theme', { tokens: next.tokens, scheme: next.scheme });
        renderDock();
    }
    function applyShellLocale(next) {
        locale = next;
        applyLocale(node, next);
        for (const m of mounted.values())
            m.moduleClient?.invoke('module.locale', next);
        render();
        renderDock();
    }
    // ── hosting ───────────────────────────────────────────────────────────────
    function connectFrame(w, manifest, frame, entry) {
        const targetOrigin = manifest.host.kind === 'origin' ? new URL(manifest.host.url).origin : '*';
        const expected = manifest.host.kind === 'origin' ? targetOrigin : 'null';
        let deadline, notice = null;
        /** Close what an earlier connection of this window held. */
        const release = () => {
            kernel.withdraw(manifest.id, w.id);
            entry.releaseDecider?.();
            entry.releaseDecider = undefined;
            try {
                entry.served?.close?.();
            }
            catch (error) {
                report(error);
            }
            for (const port of entry.ports)
                port.close();
            entry.ports = [];
            entry.served = undefined;
            entry.moduleClient = undefined;
            entry.connected = false;
        };
        const unanswered = () => {
            if (entry.connected)
                return;
            release();
            entry.el.classList.remove('is-loading');
            entry.el.classList.add('is-failed');
            notice?.remove();
            notice = doc.createElement('div');
            notice.className = 'tos-notice';
            notice.setAttribute('role', 'alert');
            const text = doc.createElement('p');
            text.textContent = t('window/unanswered', { title: localized(manifest.title, locale.locale) });
            const retry = doc.createElement('button');
            retry.type = 'button';
            retry.textContent = t('window/retry');
            retry.addEventListener('click', () => {
                notice?.remove();
                notice = null;
                entry.el.classList.remove('is-failed');
                entry.el.classList.add('is-loading');
                arm();
                frame.src = frame.src;
            });
            notice.append(text, retry);
            entry.content.append(notice);
            lifecycle('failed', w.id);
        };
        const arm = () => { win.clearTimeout(deadline); deadline = win.setTimeout(unanswered, options.connectTimeoutMs ?? 15_000); };
        const onHello = (event) => {
            if (event.source !== frame.contentWindow || event.data?.type !== HELLO)
                return;
            if (event.origin !== expected) {
                report(new Error(`${manifest.id}: a frame of origin ${event.origin} answered for ${expected}`));
                return;
            }
            win.clearTimeout(deadline);
            // a frame that reloaded says hello again: it starts over on fresh ports
            if (entry.connected || entry.ports.length)
                release();
            notice?.remove();
            notice = null;
            entry.el.classList.remove('is-failed');
            const os = new MessageChannel(), control = new MessageChannel();
            const provided = (manifest.provides ?? []).map(contract => ({ contract, channel: new MessageChannel() }));
            entry.served = kernel.serveModule(manifest.id, os.port1, { setTitle: (title) => setDesktop(setTitle(desktop, w.id, title)), openSettings: () => openSettings(manifest.id) });
            os.port1.start();
            const moduleClient = openPortClient(systemContracts().module, { channel: control.port1, timeoutMs: 10_000 });
            control.port1.start();
            for (const { contract, channel } of provided) {
                try {
                    kernel.connectProvider(manifest.id, contract, channel.port1, 10_000, w.id);
                }
                catch (error) {
                    report(error);
                }
            }
            entry.moduleClient = moduleClient;
            // the person's decisions on this module's proposals go over its own control channel, never the bus
            entry.releaseDecider = kernel.registerDecider(manifest.id, w.id, async (decision) => {
                const outcome = await moduleClient.invoke('module.decide', decision);
                if (outcome?.ok === false)
                    throw new Error(outcome.error?.message ?? 'the application did not take the decision');
                return outcome?.ok === true ? outcome.value : outcome;
            });
            entry.ports.push(os.port1, control.port1, ...provided.map(p => p.channel.port1));
            const message = {
                type: CONNECT, protocol: PROTOCOL, module: manifest.id,
                ports: ['os', 'module', ...provided.map(p => p.contract.id)],
                theme: { tokens: theme.tokens, scheme: theme.scheme }, locale,
                ...(manifest.host.kind === 'document' ? { document: { app: manifest.host.app, ...(manifest.styles ? { styles: manifest.styles } : {}) } } : {}),
            };
            frame.contentWindow.postMessage(message, targetOrigin, [os.port2, control.port2, ...provided.map(p => p.channel.port2)]);
            entry.connected = true;
            entry.el.classList.remove('is-loading');
            lifecycle('ready', w.id);
        };
        win.addEventListener('message', onHello);
        arm();
        return () => { win.clearTimeout(deadline); win.removeEventListener('message', onHello); };
    }
    function mountModule(w, manifest, entry) {
        const host = manifest.host;
        if (host.kind === 'shipped') {
            const mount = options.shipped?.[host.mount];
            if (!mount)
                throw new Error(`no shipped component '${host.mount}'`);
            const seen = { visible: isVisible(desktop, w), listeners: new Set() };
            visibility.set(w.id, seen);
            const dispose = mount(entry.content, {
                module: manifest, window: w.id, locale: locale.locale, dir: locale.dir,
                get visible() { return seen.visible; },
                get theme() { return { tokens: { ...theme.tokens }, scheme: theme.scheme }; },
                openSettings: () => openSettings(manifest.id),
                propose: (proposal) => kernel.propose(manifest.id, proposal),
                withdraw: (id) => kernel.withdrawProposal(manifest.id, id),
                onDecision: (handler) => { entry.releaseDecider?.(); return (entry.releaseDecider = kernel.registerDecider(manifest.id, w.id, handler)); },
                onVisibility: (listener) => { seen.listeners.add(listener); return () => { seen.listeners.delete(listener); }; },
                call: (contract, op, input) => kernel.call(manifest.id, contract, op, input),
                sendMail: (envelope) => { kernel.sendMail(manifest.id, envelope); },
                setTitle: (title) => setDesktop(setTitle(desktop, w.id, title)),
                provide: (contract, handlers) => kernel.provideLocal(manifest.id, contract, handlers, w.id),
            });
            entry.el.classList.remove('is-loading');
            lifecycle('ready', w.id);
            return () => { visibility.delete(w.id); dispose?.(); kernel.withdraw(manifest.id, w.id); entry.releaseDecider?.(); };
        }
        const frame = doc.createElement('iframe');
        frame.className = 'tos-frame';
        frame.title = localized(manifest.title, locale.locale);
        if (host.kind === 'document') {
            if (!options.documentHost)
                throw new Error('documentHost is not configured');
            frame.setAttribute('sandbox', 'allow-scripts');
            frame.src = options.documentHost;
        }
        else {
            const problem = originHostProblem(host.url, win.location?.origin);
            if (problem)
                throw Object.assign(new Error(problem), { code: 'OS0201' });
            frame.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-forms allow-popups allow-modals allow-downloads');
            frame.setAttribute('referrerpolicy', 'strict-origin');
            frame.src = host.url;
        }
        entry.frame = frame;
        // focus moving into this frame (from the page or from another frame) raises its window
        frame.addEventListener('focus', () => { if (desktop.focus !== w.id)
            setDesktop(focusWindow(desktop, w.id)); });
        const stop = connectFrame(w, manifest, frame, entry);
        entry.content.append(frame);
        return () => { stop(); kernel.withdraw(manifest.id, w.id); entry.releaseDecider?.(); try {
            entry.served?.close?.();
        }
        catch { /* closing */ } for (const port of entry.ports)
            port.close(); frame.remove(); };
    }
    // ── windows ───────────────────────────────────────────────────────────────
    function createWindowElement(w, manifest) {
        const el = doc.createElement('section');
        // the opening animation plays once, not again when the window is shown or restored
        el.className = 'tos-window is-loading is-opening';
        el.addEventListener('animationend', (event) => { if (event.target === el)
            el.classList.remove('is-opening'); });
        el.dataset.window = w.id;
        el.dataset.module = w.module;
        // a window is a labelled region of the desktop, not a modal dialog
        el.setAttribute('role', 'region');
        el.setAttribute('aria-label', w.title);
        const bar = doc.createElement('header');
        bar.className = 'tos-titlebar';
        const title = doc.createElement('h2');
        title.className = 'tos-title';
        const controls = doc.createElement('div');
        controls.className = 'tos-controls';
        const button = (action, label, icon) => {
            const b = doc.createElement('button');
            b.type = 'button';
            b.className = `tos-control tos-${action}`;
            b.dataset.action = action;
            b.setAttribute('aria-label', label);
            b.title = label;
            b.innerHTML = icon;
            return b;
        };
        controls.append(button('minimize', t('window/minimize'), ICON.minimize), button('maximize', t('window/maximize'), ICON.maximize), button('close', t('window/close'), ICON.close));
        const glyph = doc.createElement('span');
        glyph.className = 'tos-glyph';
        glyph.dataset.glyph = manifest.icon?.glyph ?? 'app';
        if (manifest.icon?.hue !== undefined)
            glyph.style.setProperty('--hue', String(manifest.icon.hue));
        bar.append(glyph, title, controls);
        const content = doc.createElement('div');
        content.className = 'tos-content';
        const grip = doc.createElement('div');
        grip.className = 'tos-resize';
        grip.setAttribute('aria-hidden', 'true');
        el.append(bar, content, grip);
        el.addEventListener('pointerdown', () => { if (desktop.focus !== w.id)
            setDesktop(focusWindow(desktop, w.id)); }, true);
        controls.addEventListener('click', (event) => {
            const action = event.target.closest('button')?.dataset.action;
            if (action === 'close')
                close(w.id);
            else if (action === 'minimize')
                setDesktop(minimizeWindow(desktop, w.id));
            else if (action === 'maximize')
                setDesktop(toggleMaximize(desktop, w.id));
        });
        bar.addEventListener('dblclick', (event) => { if (!event.target.closest('button'))
            setDesktop(toggleMaximize(desktop, w.id)); });
        drag(bar, w.id, 'move');
        drag(grip, w.id, 'resize');
        return { el, content, title, dispose: () => { }, ports: [] };
    }
    /** Pointer drags over frames: a shield takes the pointer for the drag's duration. */
    function drag(handle, id, mode) {
        handle.addEventListener('pointerdown', (event) => {
            if (event.button !== 0 || event.target.closest('button'))
                return;
            const current = desktop.windows.find(w => w.id === id);
            if (!current || current.maximized)
                return;
            event.preventDefault();
            const start = { x: event.clientX, y: event.clientY, rect: { ...current.rect } };
            const rtl = locale.dir === 'rtl' && mode === 'resize' ? -1 : 1;
            shield.hidden = false;
            shield.dataset.mode = mode;
            const move = (e) => {
                const dx = e.clientX - start.x, dy = e.clientY - start.y;
                if (mode === 'move')
                    setDesktop(moveWindow(desktop, id, start.rect.x + dx, start.rect.y + dy));
                else
                    setDesktop(resizeWindow(desktop, id, start.rect.w + dx * rtl, start.rect.h + dy));
            };
            const up = () => { shield.hidden = true; shield.removeEventListener('pointermove', move); shield.removeEventListener('pointerup', up); shield.removeEventListener('pointercancel', up); };
            shield.addEventListener('pointermove', move);
            shield.addEventListener('pointerup', up);
            shield.addEventListener('pointercancel', up);
        });
    }
    function open(moduleId) {
        const manifest = kernel.effective(moduleId);
        if (!manifest) {
            report(new Error(`no module '${moduleId}'`));
            return null;
        }
        const before = new Set(desktop.windows.map(w => w.id));
        const title = localized(manifest.title, locale.locale);
        const next = openWindow(desktop, { module: moduleId, title, ...manifest.window });
        const created = next.windows.find(w => !before.has(w.id));
        if (!created) {
            setDesktop(next);
            return desktop.focus;
        }
        const entry = createWindowElement(created, manifest);
        mounted.set(created.id, entry);
        layer.append(entry.el);
        // the window is on the desktop before its module mounts, so the module may retitle it at once
        setDesktop(next);
        try {
            entry.dispose = mountModule(created, manifest, entry);
        }
        catch (error) {
            entry.el.classList.remove('is-loading');
            entry.content.textContent = t('window/failed', { title, detail: String(error?.message ?? error) });
            report(error);
            lifecycle('failed', created.id);
        }
        return created.id;
    }
    /**
     * Open the desktop's Settings, at a module's own section when one is
     * named: the one place every application's settings are found.
     */
    function openSettings(moduleId) {
        const settingsId = options.settings ?? 'settings';
        if (!kernel.effective(settingsId)) {
            report(new Error(`no Settings module '${settingsId}' is installed`));
            return;
        }
        const running = desktop.windows.find(w => w.module === settingsId);
        if (running)
            setDesktop(focusWindow(desktop, running.id));
        else
            open(settingsId);
        if (moduleId)
            kernel.call('shell', 'tangle_os_settings', 'settings.show', { section: `module:${moduleId}` }).then(outcome => { if (!outcome.ok)
                report(new Error(outcome.error.message)); });
    }
    function close(id) {
        const entry = mounted.get(id);
        if (entry) {
            try {
                entry.dispose();
            }
            catch (error) {
                report(error);
            }
            entry.el.remove();
            mounted.delete(id);
        }
        setDesktop(closeWindow(desktop, id));
    }
    function render() {
        node.classList.toggle('is-compact', desktop.compact === true);
        for (const w of stacked(desktop)) {
            const entry = mounted.get(w.id);
            if (!entry)
                continue;
            const { el } = entry;
            el.style.insetInlineStart = '';
            el.style.left = `${w.rect.x}px`;
            el.style.top = `${w.rect.y}px`;
            el.style.width = `${w.rect.w}px`;
            el.style.height = `${w.rect.h}px`;
            el.style.zIndex = String(w.z);
            el.hidden = !isVisible(desktop, w);
            el.classList.toggle('is-focused', desktop.focus === w.id);
            el.classList.toggle('is-maximized', w.maximized);
            el.setAttribute('aria-label', w.title);
            entry.title.textContent = w.title;
            const max = el.querySelector('.tos-maximize');
            if (max) {
                const label = w.maximized ? t('window/restore') : t('window/maximize');
                max.setAttribute('aria-label', label);
                max.title = label;
                max.innerHTML = w.maximized ? ICON.restore : ICON.maximize;
            }
        }
        renderDock();
    }
    // ── dock and mail ─────────────────────────────────────────────────────────
    let dockSignature = '';
    function renderDock(force = false) {
        const signature = JSON.stringify([kernel.modules().map(m => [m.id, localized(m.title, locale.locale), m.icon]), [...new Set(desktop.windows.map(w => w.module))].sort(), kernel.mail().filter(m => m.proposal ? m.proposal.status === 'pending' || m.proposal.status === 'deciding' : !m.read).length, theme.scheme, locale, desktop.focus]);
        if (!force && signature === dockSignature)
            return;
        dockSignature = signature;
        const items = kernel.modules().map(manifest => {
            const b = doc.createElement('button');
            b.type = 'button';
            b.className = 'tos-dock-item';
            b.dataset.module = manifest.id;
            const title = localized(manifest.title, locale.locale);
            b.setAttribute('aria-label', t('dock/open', { title }));
            b.title = title;
            const glyph = doc.createElement('span');
            glyph.className = 'tos-glyph';
            glyph.dataset.glyph = manifest.icon?.glyph ?? 'app';
            if (manifest.icon?.hue !== undefined)
                glyph.style.setProperty('--hue', String(manifest.icon.hue));
            b.append(glyph);
            if (desktop.windows.some(w => w.module === manifest.id))
                b.classList.add('is-running');
            b.addEventListener('click', () => {
                const running = desktop.windows.filter(w => w.module === manifest.id).sort((a, c) => c.z - a.z)[0];
                if (running)
                    setDesktop(focusWindow(desktop, running.id));
                else
                    open(manifest.id);
            });
            return b;
        });
        // plain mail until it is read, a proposal while it waits for the person
        const unread = kernel.mail().filter(m => m.proposal ? m.proposal.status === 'pending' || m.proposal.status === 'deciding' : !m.read).length;
        const mailButton = doc.createElement('button');
        mailButton.type = 'button';
        mailButton.className = 'tos-dock-item tos-dock-mail';
        mailButton.setAttribute('aria-label', t('mail/title'));
        mailButton.title = t('mail/title');
        mailButton.innerHTML = '<span class="tos-glyph" data-glyph="mail"></span>';
        if (unread) {
            const badge = doc.createElement('span');
            badge.className = 'tos-badge';
            badge.textContent = String(unread);
            mailButton.append(badge);
        }
        mailButton.addEventListener('click', toggleMail);
        const themeButton = doc.createElement('button');
        themeButton.type = 'button';
        themeButton.className = 'tos-dock-item tos-dock-theme';
        const label = theme.scheme === 'dark' ? t('tray/theme-light') : t('tray/theme-dark');
        themeButton.setAttribute('aria-label', label);
        themeButton.title = label;
        themeButton.innerHTML = `<span class="tos-glyph" data-glyph="${theme.scheme === 'dark' ? 'sun' : 'moon'}"></span>`;
        themeButton.addEventListener('click', toggleScheme);
        const tray = [...(options.tray?.mail === false ? [] : [mailButton]), ...(options.tray?.theme === false ? [] : [themeButton])];
        const separator = doc.createElement('span');
        separator.className = 'tos-dock-separator';
        separator.setAttribute('aria-hidden', 'true');
        const brand = brandMark();
        // the tiles shrink with the count before the dock overflows
        dock.style.setProperty('--tos-dock-count', String(items.length + tray.length));
        // a keyboard user stays on the tile they were on when the dock redraws
        const active = doc.activeElement;
        const had = active && dock.contains(active) ? (active.dataset.module ? `[data-module="${active.dataset.module}"]` : active.classList.contains('tos-dock-mail') ? '.tos-dock-mail' : active.classList.contains('tos-dock-theme') ? '.tos-dock-theme' : null) : null;
        dock.replaceChildren(...(brand ? [brand] : []), ...items, ...(tray.length ? [separator, ...tray] : []));
        if (had)
            dock.querySelector(had)?.focus({ preventScroll: true });
    }
    let brandNode = null;
    function brandMark() {
        const brand = options.tray?.brand;
        if (!brand)
            return null;
        if (brandNode)
            return brandNode;
        const mark = doc.createElement('span');
        mark.className = 'tos-dock-brand';
        mark.setAttribute('role', 'img');
        mark.setAttribute('aria-label', brand.label);
        mark.title = brand.label;
        if (brand.node)
            mark.append(brand.node);
        else if (brand.src) {
            const img = doc.createElement('img');
            img.src = brand.src;
            img.alt = '';
            mark.append(img);
        }
        return (brandNode = mark);
    }
    function toggleMail() { mailPanel.hidden = !mailPanel.hidden; renderMail(); }
    function toggleScheme() {
        const scheme = theme.scheme === 'dark' ? 'light' : 'dark';
        try {
            applyShellTheme(options.themeFor?.(scheme) ?? DEFAULT_THEMES[scheme]);
        }
        catch (error) {
            report(error);
            applyShellTheme(DEFAULT_THEMES[scheme]);
        }
        options.onSchemeSwitch?.(scheme);
    }
    let menu = null;
    const windowsOf = (moduleId) => desktop.windows.filter(w => w.module === moduleId).sort((a, b) => a.id.localeCompare(b.id, 'en', { numeric: true }));
    const singleton = (moduleId) => kernel.effective(moduleId)?.window?.singleton === true;
    const appGlyph = (manifest) => ({ glyph: manifest.icon?.glyph ?? 'app', hue: manifest.icon?.hue });
    function windowMenu(id) {
        const w = desktop.windows.find(x => x.id === id);
        if (!w)
            return [];
        return [
            { label: t('window/minimize'), run: () => setDesktop(minimizeWindow(desktop, id)) },
            { label: w.maximized ? t('window/restore') : t('window/maximize'), run: () => setDesktop(toggleMaximize(desktop, id)) },
            ...(singleton(w.module) ? [] : ['separator', { label: t('menu/new-window'), run: () => { open(w.module); } }]),
            ...(kernel.effective(w.module)?.settings ? ['separator', { label: t('menu/settings'), run: () => openSettings(w.module) }] : []),
            'separator',
            { label: t('window/close'), run: () => close(id) },
        ];
    }
    function dockMenu(moduleId) {
        const manifest = kernel.effective(moduleId);
        if (!manifest)
            return [];
        const title = localized(manifest.title, locale.locale);
        const running = windowsOf(moduleId);
        const entries = running.map(w => ({ label: w.title, glyph: appGlyph(manifest), run: () => setDesktop(focusWindow(desktop, w.id)) }));
        if (running.length === 0)
            entries.push({ label: t('dock/open', { title }), run: () => { open(moduleId); } });
        else if (!singleton(moduleId))
            entries.push('separator', { label: t('menu/new-window'), run: () => { open(moduleId); } });
        if (manifest.settings)
            entries.push('separator', { label: t('menu/settings'), run: () => openSettings(moduleId) });
        if (running.length)
            entries.push('separator', { label: running.length === 1 ? t('window/close') : t('menu/close-all'), run: () => { for (const w of windowsOf(moduleId))
                    close(w.id); } });
        return entries;
    }
    function desktopMenu() {
        const shown = desktop.windows.filter(w => !w.minimized), hidden = desktop.windows.filter(w => w.minimized);
        return [
            ...kernel.modules().map(manifest => ({ label: localized(manifest.title, locale.locale), glyph: appGlyph(manifest), run: () => {
                    const top = windowsOf(manifest.id).sort((a, b) => b.z - a.z)[0];
                    if (top)
                        setDesktop(focusWindow(desktop, top.id));
                    else
                        open(manifest.id);
                } })),
            'separator',
            { label: t('menu/show-desktop'), disabled: shown.length === 0, run: () => setDesktop(desktop.windows.reduce((d, w) => minimizeWindow(d, w.id), desktop)) },
            { label: t('menu/show-windows'), disabled: hidden.length === 0, run: () => setDesktop(stacked(desktop).filter(w => w.minimized).reduce((d, w) => focusWindow(d, w.id), desktop)) },
            { label: t('menu/close-all'), disabled: desktop.windows.length === 0, run: () => { for (const w of [...desktop.windows])
                    close(w.id); } },
            'separator',
            ...(options.tray?.mail === false ? [] : [{ label: t('mail/title'), run: toggleMail }]),
            ...(options.tray?.theme === false ? [] : [{ label: theme.scheme === 'dark' ? t('tray/theme-light') : t('tray/theme-dark'), run: toggleScheme }]),
        ];
    }
    /** What a right click on this element offers, or null for the browser's own menu. */
    function menuFor(target) {
        if (target.closest('.tos-content, .tos-mail, .tos-dock-brand'))
            return null;
        const windowEl = target.closest('.tos-window');
        if (windowEl?.dataset.window) {
            const w = desktop.windows.find(x => x.id === windowEl.dataset.window);
            return w ? { title: w.title, entries: windowMenu(w.id) } : null;
        }
        const item = target.closest('.tos-dock-item[data-module]');
        if (item?.dataset.module) {
            const manifest = kernel.effective(item.dataset.module);
            return manifest ? { title: localized(manifest.title, locale.locale), entries: dockMenu(manifest.id) } : null;
        }
        return { title: t('desktop/label'), entries: desktopMenu() };
    }
    function closeMenu(returnFocus = false) {
        if (!menu)
            return;
        const { el, restore } = menu;
        menu = null;
        el.remove();
        if (returnFocus && restore?.isConnected)
            restore.focus();
    }
    function openMenu(title, entries, at, restore) {
        closeMenu();
        const el = doc.createElement('div');
        el.className = 'tos-menu';
        el.setAttribute('role', 'menu');
        el.setAttribute('aria-label', t('menu/label', { title }));
        // no leading, trailing or doubled separators, whatever the entries say
        const tidy = entries.filter((e, i, all) => e !== 'separator' || (i > 0 && i < all.length - 1 && all[i - 1] !== 'separator'));
        for (const entry of tidy) {
            if (entry === 'separator') {
                const hr = doc.createElement('div');
                hr.className = 'tos-menu-separator';
                hr.setAttribute('role', 'separator');
                el.append(hr);
                continue;
            }
            const b = doc.createElement('button');
            b.type = 'button';
            b.className = 'tos-menu-item';
            b.tabIndex = -1;
            b.setAttribute('role', 'menuitem');
            if (entry.disabled) {
                b.disabled = true;
                b.setAttribute('aria-disabled', 'true');
            }
            if (entry.glyph) {
                const glyph = doc.createElement('span');
                glyph.className = 'tos-glyph';
                glyph.dataset.glyph = entry.glyph.glyph;
                if (entry.glyph.hue !== undefined)
                    glyph.style.setProperty('--hue', String(entry.glyph.hue));
                b.append(glyph);
            }
            const label = doc.createElement('span');
            label.textContent = entry.label;
            b.append(label);
            // the pointer and the keyboard share one highlighted item
            if (!entry.disabled)
                b.addEventListener('pointermove', () => { if (doc.activeElement !== b)
                    b.focus({ preventScroll: true }); });
            b.addEventListener('click', () => {
                closeMenu();
                try {
                    entry.run();
                }
                catch (error) {
                    report(error);
                }
            });
            el.append(b);
        }
        el.addEventListener('keydown', (event) => {
            const items = [...el.querySelectorAll('.tos-menu-item:not(:disabled)')];
            const index = items.indexOf(doc.activeElement);
            const go = (i) => { event.preventDefault(); items[(i + items.length) % items.length]?.focus(); };
            if (event.key === 'ArrowDown')
                go(index + 1);
            else if (event.key === 'ArrowUp')
                go(index < 0 ? -1 : index - 1);
            else if (event.key === 'Home')
                go(0);
            else if (event.key === 'End')
                go(-1);
            else if (event.key === 'Escape' || event.key === 'Tab') {
                event.preventDefault();
                closeMenu(true);
            }
        });
        el.addEventListener('contextmenu', (event) => event.preventDefault());
        el.style.visibility = 'hidden';
        node.append(el);
        // at the pointer, opening towards the line's end (towards the start on a
        // right-to-left desktop) and flipped where it would leave the desktop
        const box = node.getBoundingClientRect(), width = el.offsetWidth, height = el.offsetHeight, margin = 6;
        let x = at.x - box.left, y = at.y - box.top;
        if (locale.dir === 'rtl') {
            if (x - width >= margin)
                x -= width;
        }
        else if (x + width > box.width - margin)
            x -= width;
        if (y + height > box.height - margin)
            y -= height;
        el.style.left = `${Math.round(Math.max(margin, Math.min(x, box.width - width - margin)))}px`;
        el.style.top = `${Math.round(Math.max(margin, Math.min(y, box.height - height - margin)))}px`;
        el.style.visibility = '';
        menu = { el, restore };
        el.querySelector('.tos-menu-item:not(:disabled)')?.focus({ preventScroll: true });
    }
    const onContextMenu = (event) => {
        const target = event.target;
        if (menu?.el.contains(target)) {
            event.preventDefault();
            return;
        }
        const offer = menuFor(target);
        if (!offer || offer.entries.length === 0) {
            closeMenu();
            return;
        }
        event.preventDefault();
        // the menu key and Shift+F10 fire with no pointer position: anchor on the element
        let at = { x: event.clientX, y: event.clientY };
        if (event.button !== 2 && at.x === 0 && at.y === 0) {
            const r = (target.closest('.tos-titlebar, .tos-dock-item') ?? target).getBoundingClientRect();
            at = { x: r.left + Math.min(24, r.width / 2), y: r.bottom };
        }
        const active = doc.activeElement;
        openMenu(offer.title, offer.entries, at, active && active !== doc.body ? active : null);
    };
    const onOutside = (event) => { if (menu && !menu.el.contains(event.target))
        closeMenu(); };
    const onMenuBlur = () => closeMenu();
    node.addEventListener('contextmenu', onContextMenu);
    doc.addEventListener('pointerdown', onOutside, true);
    win.addEventListener('blur', onMenuBlur);
    win.addEventListener('resize', onMenuBlur);
    function renderMail() {
        if (mailPanel.hidden)
            return;
        const heading = doc.createElement('h2');
        heading.textContent = t('mail/title');
        const items = kernel.mail().reverse();
        const appName = (id) => { const sender = kernel.effective(id); return sender ? localized(sender.title, locale.locale) : id; };
        const open = items.filter(m => m.proposal && (m.proposal.status === 'pending' || m.proposal.status === 'deciding'));
        const rest = items.filter(m => !open.includes(m));
        const sections = [heading];
        if (open.length) {
            const title = doc.createElement('h3');
            title.className = 'tos-mail-group';
            title.textContent = t('mail/to-decide');
            const list = doc.createElement('ul');
            list.className = 'tos-proposals';
            for (const item of open)
                list.append(proposalItem(item, appName(item.from)));
            sections.push(title, list);
        }
        if (rest.length) {
            const list = doc.createElement('ul');
            for (const item of rest) {
                const li = doc.createElement('li');
                li.className = item.read || item.proposal ? 'is-read' : '';
                const subject = doc.createElement('strong');
                subject.textContent = item.subject;
                const from = doc.createElement('span');
                from.className = 'tos-muted';
                from.textContent = t('mail/from', { sender: appName(item.from) });
                li.append(subject, from);
                if (item.proposal) {
                    const status = doc.createElement('span');
                    status.className = 'tos-muted';
                    status.textContent = item.proposal.status === 'accepted' ? t('mail/accepted') : t('mail/rejected');
                    li.append(status);
                }
                if (item.body) {
                    const body = doc.createElement('p');
                    body.textContent = item.body;
                    li.append(body);
                }
                list.append(li);
                if (!item.read && !item.proposal)
                    kernel.markRead(item.id);
            }
            sections.push(list);
        }
        if (!open.length && !rest.length) {
            const empty = doc.createElement('p');
            empty.className = 'tos-muted';
            empty.textContent = t('mail/empty');
            sections.push(empty);
        }
        mailPanel.replaceChildren(...sections);
    }
    /** One proposal waiting for the person: text only, links to http(s) pages only, the decision carried to its module. */
    function proposalItem(item, app) {
        const p = item.proposal;
        const li = doc.createElement('li');
        li.className = 'tos-proposal';
        li.dataset.proposal = p.id;
        li.dataset.module = item.from;
        const subject = doc.createElement('strong');
        subject.textContent = item.subject;
        const from = doc.createElement('span');
        from.className = 'tos-muted';
        from.textContent = t('mail/from', { sender: app });
        li.append(subject, from);
        if (p.summary) {
            const summary = doc.createElement('p');
            summary.textContent = p.summary;
            li.append(summary);
        }
        if (p.evidence?.length) {
            const evidence = doc.createElement('ul');
            evidence.className = 'tos-evidence';
            evidence.setAttribute('aria-label', t('mail/evidence'));
            for (const e of p.evidence) {
                const row = doc.createElement('li');
                if (e.href && /^https?:\/\//.test(e.href)) {
                    const a = doc.createElement('a');
                    a.href = e.href;
                    a.target = '_blank';
                    a.rel = 'noopener noreferrer';
                    a.textContent = e.label;
                    row.append(a);
                }
                else
                    row.textContent = e.label;
                evidence.append(row);
            }
            li.append(evidence);
        }
        if (p.reason) {
            const reason = doc.createElement('p');
            reason.className = 'tos-proposal-reason';
            reason.setAttribute('role', 'alert');
            reason.textContent = p.reason.code === 'OS0110' ? t('mail/not-running', { app }) : t('mail/refused', { detail: p.reason.message });
            li.append(reason);
        }
        const actions = doc.createElement('div');
        actions.className = 'tos-proposal-actions';
        const deciding = p.status === 'deciding';
        for (const [decision, label] of [['accept', t('mail/accept')], ['reject', t('mail/reject')]]) {
            const b = doc.createElement('button');
            b.type = 'button';
            b.dataset.decision = decision;
            b.textContent = deciding ? t('mail/deciding') : label;
            b.disabled = deciding;
            b.addEventListener('click', () => { for (const x of actions.querySelectorAll('button'))
                x.disabled = true; kernel.decide(item.id, decision).catch(report); });
            actions.append(b);
        }
        li.append(actions);
        return li;
    }
    // ── wiring ──────────────────────────────────────────────────────────────
    const unsubscribe = kernel.subscribe((event) => {
        if (event.kind === 'mail') {
            renderDock();
            renderMail();
        }
        if (event.kind === 'modules')
            renderDock();
        // a form module's windows hear their new settings; one that predates them may refuse, which is fine
        if (event.kind === 'settings' && event.module) {
            const values = kernel.settings(event.module);
            for (const [id, m] of mounted)
                if (desktop.windows.find(w => w.id === id)?.module === event.module)
                    m.moduleClient?.invoke('module.settings', { values }).catch(() => { });
        }
    });
    const onKey = (event) => {
        const type = event.data?.type;
        if (type !== KEY && type !== FOCUS)
            return;
        const source = [...mounted].find(([, m]) => m.frame?.contentWindow === event.source);
        if (!source)
            return;
        if (type === FOCUS) {
            if (desktop.focus !== source[0])
                setDesktop(focusWindow(desktop, source[0]));
            return;
        }
        if (event.data.key?.endsWith('+k'))
            dock.querySelector('.tos-dock-item')?.focus();
    };
    win.addEventListener('message', onKey);
    // a click inside a framed window goes to the frame, not the shell: when
    // focus moves into a frame, raise the window that holds it
    const onBlur = () => win.setTimeout(() => {
        const active = doc.activeElement;
        if (active?.tagName !== 'IFRAME')
            return;
        for (const [id, entry] of mounted)
            if (entry.frame === active && desktop.focus !== id)
                setDesktop(focusWindow(desktop, id));
    }, 0);
    win.addEventListener('blur', onBlur);
    // windows live in the window layer, which stops above the dock: lay them out in its area
    const area = () => ({ w: layer.clientWidth || node.clientWidth, h: layer.clientHeight || node.clientHeight });
    const observer = typeof win.ResizeObserver === 'function' ? new win.ResizeObserver(() => setDesktop(resized(desktop, area()))) : null;
    observer?.observe(node);
    desktop = resized(desktop, area());
    applyShellTheme(theme);
    applyShellLocale(locale);
    return {
        open,
        close,
        focus: (id) => setDesktop(focusWindow(desktop, id)),
        minimize: (id) => setDesktop(minimizeWindow(desktop, id)),
        maximize: (id) => setDesktop(toggleMaximize(desktop, id)),
        move: (id, x, y) => setDesktop(moveWindow(desktop, id, x, y)),
        state: () => JSON.parse(JSON.stringify(desktop)),
        /** Open the desktop's Settings, at a module's own section when one is named. */
        openSettings,
        /** Every window change, as it happens; returns the unsubscribe. */
        subscribe(listener) { listeners.add(listener); return () => { listeners.delete(listener); }; },
        setTheme: applyShellTheme,
        setLocale: applyShellLocale,
        theme: () => theme,
        /** The framed module's own context row, for the assistant. */
        context: (id) => mounted.get(id)?.moduleClient?.invoke('module.context', {}),
        dispose() {
            unsubscribe();
            observer?.disconnect();
            win.removeEventListener('message', onKey);
            win.removeEventListener('blur', onBlur);
            closeMenu();
            node.removeEventListener('contextmenu', onContextMenu);
            doc.removeEventListener('pointerdown', onOutside, true);
            win.removeEventListener('blur', onMenuBlur);
            win.removeEventListener('resize', onMenuBlur);
            for (const id of [...mounted.keys()])
                close(id);
            listeners.clear();
            visibility.clear();
            node.replaceChildren();
            node.classList.remove('tos', 'is-compact');
        },
    };
}
