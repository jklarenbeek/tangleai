/**
 * Every sentence the desktop's chrome shows, keyed for all twelve languages.
 * English is built in; a language pack is a catalogue with the same keys.
 * Keys never carry English word order a translation would have to keep.
 */
export declare const osMessagesEn: {
    readonly 'desktop/label': "Desktop";
    readonly 'dock/label': "Applications";
    readonly 'dock/open': "Open {title}";
    readonly 'window/close': "Close";
    readonly 'window/minimize': "Minimize";
    readonly 'window/maximize': "Maximize";
    readonly 'window/restore': "Restore";
    readonly 'window/failed': "{title} could not start: {detail}";
    readonly 'window/unanswered': "{title} did not answer. It may not be running, or it may refuse this desktop.";
    readonly 'window/retry': "Try again";
    readonly 'mail/title': "Mail";
    readonly 'mail/empty': "No messages.";
    readonly 'mail/from': "From {sender}";
    readonly 'mail/to-decide': "To decide";
    readonly 'mail/evidence': "Evidence";
    readonly 'mail/accept': "Accept";
    readonly 'mail/reject': "Reject";
    readonly 'mail/deciding': "Deciding…";
    readonly 'mail/accepted': "Accepted";
    readonly 'mail/rejected': "Rejected";
    readonly 'mail/not-running': "{app} is not running. Open it, then decide again.";
    readonly 'mail/refused': "Not done: {detail}";
    readonly 'tray/theme-light': "Switch to the light theme";
    readonly 'tray/theme-dark': "Switch to the dark theme";
    readonly 'menu/label': "Menu for {title}";
    readonly 'menu/new-window': "New window";
    readonly 'menu/show-desktop': "Show the desktop";
    readonly 'menu/show-windows': "Show all windows";
    readonly 'menu/close-all': "Close all windows";
    readonly 'menu/settings': "Settings";
    readonly 'settings/search': "Search settings";
    readonly 'settings/sections': "Settings sections";
    readonly 'settings/applications': "Applications";
    readonly 'settings/no-match': "No setting matches.";
    readonly 'settings/empty': "There is nothing to set yet.";
    readonly 'settings/saved': "Saved.";
    readonly 'settings/refused': "Not saved: {detail}";
};
export type OsMessageKey = keyof typeof osMessagesEn;
export type OsCatalogue = Record<OsMessageKey, string>;
/** Fill `{name}` placeholders. Values are inserted as text, never as markup. */
export declare function format(template: string, values?: Record<string, string | number>): string;
export declare function createOsMessages(catalogue?: Partial<OsCatalogue>): (key: OsMessageKey, values?: Record<string, string | number>) => string;
