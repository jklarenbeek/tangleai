export const emptyDesktop = (viewport = { w: 1280, h: 800 }) => ({ windows: [], focus: null, nextId: 1, viewport });
const topZ = (d) => d.windows.reduce((max, w) => Math.max(max, w.z), 0);
const clamp = (value, lo, hi) => Math.max(lo, Math.min(hi, value));
/** Keep at least a grabbable strip of the title bar on screen. */
const GRIP = 48;
const DEFAULT_MIN = { w: 200, h: 120 };
const full = (d) => ({ x: 0, y: 0, w: d.viewport.w, h: d.viewport.h });
export function fit(rect, viewport, min = { w: 200, h: 120 }) {
    const w = clamp(Math.round(rect.w), min.w, Math.max(min.w, viewport.w));
    const h = clamp(Math.round(rect.h), min.h, Math.max(min.h, viewport.h));
    return { x: clamp(Math.round(rect.x), GRIP - w, viewport.w - GRIP), y: clamp(Math.round(rect.y), 0, viewport.h - 32), w, h };
}
/**
 * Open a window, or focus the existing one of a single-instance module. New
 * windows cascade, sized to the desktop and placed wholly on it; on a compact
 * desktop they open maximized.
 */
export function openWindow(d, request) {
    if (request.singleton) {
        const existing = d.windows.find(w => w.module === request.module);
        if (existing)
            return focusWindow({ ...d, windows: d.windows.map(w => w.id === existing.id ? { ...w, minimized: false } : w) }, existing.id);
    }
    const min = { w: request.minWidth ?? DEFAULT_MIN.w, h: request.minHeight ?? DEFAULT_MIN.h };
    const size = fit({ x: 0, y: 0, w: request.width ?? 640, h: request.height ?? 440 }, d.viewport, min);
    const offset = (d.windows.length % 8) * 28;
    // placed from the size it will have, wholly on the desktop where it fits
    const rect = {
        x: clamp(Math.round((d.viewport.w - size.w) / 2) - 84 + offset, 0, Math.max(0, d.viewport.w - size.w)),
        y: clamp(Math.round((d.viewport.h - size.h) / 2) - 60 + offset, 0, Math.max(0, d.viewport.h - size.h)),
        w: size.w, h: size.h,
    };
    const id = `w${d.nextId}`;
    const placed = { id, module: request.module, title: request.title, rect, z: topZ(d) + 1, minimized: false, maximized: false, min };
    const win = d.compact ? { ...placed, maximized: true, compacted: true, restore: rect, rect: full(d) } : placed;
    return { ...d, windows: [...d.windows, win], focus: id, nextId: d.nextId + 1 };
}
export function focusWindow(d, id) {
    const target = d.windows.find(w => w.id === id);
    if (!target)
        return d;
    if (d.focus === id && target.z === topZ(d) && !target.minimized)
        return d;
    const z = topZ(d) + 1;
    return { ...d, focus: id, windows: d.windows.map(w => w.id === id ? { ...w, z, minimized: false } : w) };
}
export function closeWindow(d, id) {
    const windows = d.windows.filter(w => w.id !== id);
    const next = windows.filter(w => !w.minimized).sort((a, b) => b.z - a.z)[0];
    return { ...d, windows, focus: d.focus === id ? next?.id ?? null : d.focus };
}
export function moveWindow(d, id, x, y) {
    return { ...d, windows: d.windows.map(w => w.id === id && !w.maximized ? { ...w, rect: fit({ ...w.rect, x, y }, d.viewport, w.min) } : w) };
}
/** Resize, never below the window's own minimum (its manifest's `minWidth` and `minHeight`) unless `min` says otherwise. */
export function resizeWindow(d, id, width, height, min) {
    return { ...d, windows: d.windows.map(w => w.id === id && !w.maximized ? { ...w, rect: fit({ ...w.rect, w: width, h: height }, d.viewport, min ?? w.min) } : w) };
}
/**
 * Resize by dragging an edge or a corner of the window as it was when the drag
 * began: the edges it names follow the pointer, the opposite ones stay put, and
 * the window never goes below its minimum or above the desktop's top.
 */
export function resizeWindowFrom(d, id, edge, start, dx, dy) {
    return { ...d, windows: d.windows.map(w => {
            if (w.id !== id || w.maximized)
                return w;
            const min = w.min ?? { w: 200, h: 120 };
            let { x, y, w: width, h: height } = start;
            if (edge.includes('e'))
                width = start.w + dx;
            if (edge.includes('w')) {
                width = Math.max(min.w, start.w - dx);
                x = start.x + start.w - width;
            }
            if (edge.includes('s'))
                height = start.h + dy;
            if (edge.includes('n')) {
                height = Math.max(min.h, start.h - dy);
                y = start.y + start.h - height;
                if (y < 0) {
                    height += y;
                    y = 0;
                }
            }
            return { ...w, rect: fit({ x, y, w: width, h: height }, d.viewport, min) };
        }) };
}
/** Maximize or restore; on a compact desktop every window stays maximized. */
export function toggleMaximize(d, id) {
    if (d.compact)
        return focusWindow(d, id);
    return focusWindow({ ...d, windows: d.windows.map(w => {
            if (w.id !== id)
                return w;
            if (w.maximized)
                return { ...w, maximized: false, compacted: undefined, rect: w.restore ?? w.rect, restore: undefined };
            return { ...w, maximized: true, restore: w.rect, rect: full(d) };
        }) }, id);
}
/**
 * Enter or leave the compact desktop: entering maximizes every window the
 * person had not maximized (marked `compacted`), leaving restores exactly those.
 */
export function setCompact(d, compact) {
    if ((d.compact === true) === compact)
        return d;
    return { ...d, compact, windows: d.windows.map(w => {
            if (compact)
                return w.maximized ? w : { ...w, maximized: true, compacted: true, restore: w.rect, rect: full(d) };
            if (!w.compacted)
                return w;
            return { ...w, maximized: false, compacted: undefined, rect: fit(w.restore ?? w.rect, d.viewport, w.min), restore: undefined };
        }) };
}
/**
 * A new desktop size, compact or not: entering compact happens before the
 * windows are fitted to the narrower desktop, so each keeps the place and size
 * it returns to.
 */
export function resizeDesktop(d, viewport, compact = d.compact === true) {
    return setViewport(setCompact({ ...d, viewport }, compact), viewport);
}
/** Whether a window is on screen: not minimized, and on a compact desktop the focused one. */
export const isVisible = (d, w) => !w.minimized && (!d.compact || d.focus === w.id);
export function minimizeWindow(d, id) {
    const windows = d.windows.map(w => w.id === id ? { ...w, minimized: true } : w);
    const next = windows.filter(w => !w.minimized).sort((a, b) => b.z - a.z)[0];
    return { ...d, windows, focus: d.focus === id ? next?.id ?? null : d.focus };
}
export function setTitle(d, id, title) {
    return { ...d, windows: d.windows.map(w => w.id === id ? { ...w, title } : w) };
}
/** A new viewport keeps every window reachable and maximized windows full size. */
export function setViewport(d, viewport) {
    return { ...d, viewport, windows: d.windows.map(w => w.maximized ? { ...w, rect: { x: 0, y: 0, w: viewport.w, h: viewport.h } } : { ...w, rect: fit(w.rect, viewport, w.min) }) };
}
/** Windows in stacking order, bottom first. */
export const stacked = (d) => [...d.windows].sort((a, b) => a.z - b.z);
