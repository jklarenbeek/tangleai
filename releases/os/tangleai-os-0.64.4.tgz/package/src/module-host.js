/**
 * The document module host: the script a sandboxed frame runs. A host bundles
 * this entry once as a CLASSIC script (an opaque-origin frame cannot load a
 * module script from a server that sends no CORS headers) and serves it beside
 * a page that loads it.
 *
 * It boots the module's jaren-app document with exactly one granted effect,
 * `os`, whose only door is the port the shell handed over. The frame's origin
 * is opaque: it cannot read the desktop's storage, keys or DOM.
 *
 * The `os` effect: `{ "run": "os", "with": { "call": "mail.send" | "os.call" |
 * "window.title", "input": {…}, "then"?: action, "catch"?: action } }`.
 */
import { createApp, formEventFields } from '@jarenjs/app';
import { connectToOs } from "./module.js";
import { KEY } from "./contracts.js";
const OPERATIONS = new Set(['os.call', 'mail.send', 'window.title']);
/** Boot the document module this frame is handed. Returns the connection and the running app. */
export async function bootDocumentModule(options = {}) {
    const win = options.window ?? globalThis;
    const doc = win.document;
    let app = null;
    const connection = await connectToOs({ origins: 'parent', host: win, context: () => ({ state: app?.getState?.() ?? null }) });
    const module = connection.connect.document;
    if (!module)
        throw new Error('the shell sent no document to boot');
    if (module.styles) {
        const style = doc.createElement('style');
        style.setAttribute('data-module-styles', connection.module);
        style.textContent = module.styles;
        doc.head.append(style);
    }
    const report = options.onError ?? ((error) => win.console?.error?.(error));
    const os = (props, dispatch) => {
        const call = props?.call;
        if (!OPERATIONS.has(call)) {
            report(new Error(`the os effect cannot run '${String(call)}'`));
            return;
        }
        const run = call === 'os.call' ? connection.call(props.input?.contract, props.input?.op, props.input?.input ?? {})
            : call === 'mail.send' ? connection.sendMail(props.input ?? {})
                : connection.setTitle(props.input?.title ?? '');
        Promise.resolve(run).then((outcome) => {
            // os.call answers with the kernel's own outcome inside the transport's
            const value = outcome?.ok ? outcome.value : undefined;
            const inner = call === 'os.call' ? value : outcome;
            if (outcome?.ok && (call !== 'os.call' || inner?.ok)) {
                if (props.then)
                    dispatch(props.then, call === 'os.call' ? inner.value : value);
            }
            else if (props.catch)
                dispatch(props.catch, (call === 'os.call' ? inner?.error : outcome?.error) ?? { code: 'OS0103' });
        }, (error) => { if (props.catch)
            dispatch(props.catch, { code: 'OS0103', message: String(error) }); });
    };
    const node = options.node ?? doc.getElementById('module') ?? doc.body;
    app = createApp(module.app, {
        node,
        effects: { os },
        capabilities: { effects: ['os'], eventFields: Object.keys(formEventFields()) },
        eventFields: { ...formEventFields() },
        onError: report,
    });
    // The frame has no form submission (its sandbox omits allow-forms, so an authored document cannot
    // send a form anywhere), and the browser refuses a submission BEFORE it fires the form's submit
    // event: a document's on.submit would never run. A submit button and Enter in a field dispatch the
    // submit event instead, which never navigates, after the form's own validity check.
    const submitButtons = (form) => [...form.elements].filter((el) => el.type === 'submit' || el.type === 'image');
    const submitForm = (form, by) => {
        if (!form.noValidate && !by?.formNoValidate && typeof form.checkValidity === 'function' && !form.checkValidity()) {
            form.reportValidity?.();
            return;
        }
        const Submit = win.SubmitEvent ?? win.Event;
        form.dispatchEvent(new Submit('submit', { bubbles: true, cancelable: true, ...(by ? { submitter: by } : {}) }));
    };
    doc.addEventListener('click', (event) => {
        const button = event.target?.closest?.('button, input[type="submit"], input[type="image"]');
        if (!button?.form || button.disabled || (button.type !== 'submit' && button.type !== 'image'))
            return;
        event.preventDefault();
        submitForm(button.form, button);
    }, true);
    doc.addEventListener('keydown', (event) => {
        if (event.key !== 'Enter' || event.isComposing || event.defaultPrevented)
            return;
        const field = event.target;
        if (field?.tagName !== 'INPUT' || !field.form || ['button', 'submit', 'reset', 'checkbox', 'radio', 'image', 'file', 'color', 'range', 'hidden'].includes(field.type))
            return;
        event.preventDefault();
        // the form's default button decides, as the browser's implicit submission does: a disabled one submits nothing
        const first = submitButtons(field.form)[0];
        if (first?.disabled)
            return;
        submitForm(field.form, first ?? null);
    });
    // the desktop's own shortcuts still work while focus is inside the frame
    doc.addEventListener('keydown', (event) => {
        if ((event.ctrlKey || event.metaKey) && ['k', ' '].includes(String(event.key).toLowerCase())) {
            event.preventDefault();
            win.parent?.postMessage({ type: KEY, key: `${event.metaKey ? 'meta' : 'ctrl'}+${String(event.key).toLowerCase()}` }, '*');
        }
    });
    return { connection, app };
}
// as a classic script in a frame: boot at once
if (typeof globalThis.document !== 'undefined' && globalThis.document?.documentElement?.dataset?.tangleOsModule === 'auto') {
    bootDocumentModule().catch((error) => globalThis.console?.error?.(error));
}
