/**
 * The dock as a document. Each installed module is one icon, or one icon per
 * launch entry when its manifest lists `entries` (an application whose
 * screens live inside one page puts each screen in the dock). A person's
 * dock is a small JSON document: the order of its icons and folders, and the
 * icons they hid. Everything here is pure: the shell draws a dock arranged by
 * {@link arrangeDock}, and every edit (move, hide, show, group, take out,
 * rename) is a function from one layout to the next, normalized so that
 * every icon appears exactly once, no folder is empty, and a folder of one
 * icon dissolves into that icon.
 *
 * Manifests place only their own icons, into folders they name in
 * `dock.folders` (a suite's manifests share folder ids), and only the first
 * time an icon appears: once a person has moved it, their dock wins. With no
 * saved layout and no manifest folders, the dock is every icon in install
 * order, as it always was.
 */
import { type ModuleManifest } from './manifest.ts';
/** A folder in a layout: its icons, and its title only when the person named it. */
export type DockFolder = {
    folder: string;
    title?: string;
    items: string[];
};
export type DockLayout = {
    $dock: '0.1';
    items: (string | DockFolder)[];
    hidden: string[];
};
/** One dock icon: a module, or one launch entry of a module (`<module>/<entry>`). */
export type DockIcon = {
    id: string;
    module: string;
    entry?: string;
    screen?: string;
    title: string;
    icon?: {
        glyph: string;
        hue?: number;
    };
    folder?: string;
    hidden?: true;
};
export type DockView = {
    items: ({
        kind: 'icon';
        icon: DockIcon;
    } | {
        kind: 'folder';
        id: string;
        title: string;
        icons: DockIcon[];
    })[];
    hidden: DockIcon[];
};
/** The layout document: bounded plain JSON, checked before it is kept. */
export declare const DOCK_SCHEMA: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly required: readonly ["$dock", "items", "hidden"];
    readonly properties: {
        readonly $dock: {
            readonly const: "0.1";
        };
        readonly items: {
            readonly type: "array";
            readonly maxItems: 400;
            readonly items: {
                readonly anyOf: readonly [{
                    readonly type: "string";
                    readonly pattern: "^[A-Za-z0-9._:/-]{1,160}$";
                }, {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: readonly ["folder", "items"];
                    readonly properties: {
                        readonly folder: {
                            readonly type: "string";
                            readonly pattern: "^[A-Za-z0-9._:-]{1,64}$";
                        };
                        readonly title: {
                            readonly type: "string";
                            readonly minLength: 1;
                            readonly maxLength: 64;
                        };
                        readonly items: {
                            readonly type: "array";
                            readonly maxItems: 200;
                            readonly items: {
                                readonly type: "string";
                                readonly pattern: "^[A-Za-z0-9._:/-]{1,160}$";
                            };
                        };
                    };
                }];
            };
        };
        readonly hidden: {
            readonly type: "array";
            readonly maxItems: 400;
            readonly items: {
                readonly type: "string";
                readonly pattern: "^[A-Za-z0-9._:/-]{1,160}$";
            };
        };
    };
};
export declare const emptyDock: () => DockLayout;
/** Every icon the installed modules put in the dock, in install order. */
export declare function dockIcons(manifests: readonly ModuleManifest[], locale?: string): DockIcon[];
/** The titles manifests give their folders, the first manifest naming a folder winning. */
export declare function folderTitles(manifests: readonly ModuleManifest[], locale?: string): Map<string, string>;
/**
 * The one shape every layout keeps: each id once (its first place wins), no
 * empty folder, a folder of one dissolved into its icon in place, and no id
 * both shown and hidden. Normalizing twice changes nothing.
 */
export declare function normalizeDock(layout: DockLayout): DockLayout;
/**
 * The person's layout with every newly installed icon placed: among the
 * hidden ones when its manifest says so, else into the folder its manifest names (made at the end when it is not there yet, with
 * every newcomer that names it), else at the end. An icon the layout already
 * holds, shown, foldered or hidden, stays where the person put it; one whose
 * module is gone stays in the layout (so it returns to its place when the
 * module does) but not in the view.
 */
export declare function arrangeDock(saved: DockLayout | null | undefined, icons: readonly DockIcon[], titles?: ReadonlyMap<string, string>, fallbackTitle?: string): {
    layout: DockLayout;
    view: DockView;
};
/** Put an icon (or a whole folder, by its folder id) at a top-level position, out of any folder it was in. */
export declare function moveInDock(layout: DockLayout, id: string, index: number): DockLayout;
export declare function hideInDock(layout: DockLayout, id: string): DockLayout;
/** Show a hidden icon again, at the end of the dock. */
export declare function showInDock(layout: DockLayout, id: string): DockLayout;
/**
 * Drop one icon on another: on a folder it joins the folder; on an icon the
 * two become a new folder where the target was. `folderId` names a new folder.
 */
export declare function groupInDock(layout: DockLayout, dragged: string, target: string, folderId: string): DockLayout;
/** Name a folder (an empty title goes back to the manifest's, or the default). */
export declare function renameDockFolder(layout: DockLayout, folder: string, title: string): DockLayout;
/** What changes from one layout to another, for the person to read before accepting it. */
export declare function dockChanges(before: DockLayout, after: DockLayout): {
    moved: string[];
    hidden: string[];
    shown: string[];
    folders: {
        id: string;
        items: string[];
    }[];
};
