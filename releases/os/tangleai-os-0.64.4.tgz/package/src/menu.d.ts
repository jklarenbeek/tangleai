/** The menu document: up to 40 entries, each a separator, an item, or an item with a submenu. */
export declare const MENU_SCHEMA: {
    readonly type: "array";
    readonly minItems: 1;
    readonly maxItems: 40;
    readonly items: {
        readonly anyOf: readonly [{
            readonly const: "separator";
        }, {
            readonly type: "object";
            readonly additionalProperties: false;
            readonly required: readonly ["id", "label"];
            readonly properties: {
                readonly id: {
                    readonly type: "string";
                    readonly pattern: "^[A-Za-z0-9._:-]{1,64}$";
                };
                readonly label: {
                    readonly type: "string";
                    readonly minLength: 1;
                    readonly maxLength: 80;
                };
                readonly glyph: {
                    readonly type: "string";
                    readonly pattern: "^[a-z][a-z0-9-]{0,31}$";
                };
                readonly hint: {
                    readonly type: "string";
                    readonly maxLength: 24;
                };
                readonly disabled: {
                    readonly type: "boolean";
                };
                readonly checked: {
                    readonly type: "boolean";
                };
            };
        }, {
            readonly type: "object";
            readonly additionalProperties: false;
            readonly required: readonly ["id", "label", "items"];
            readonly properties: {
                readonly items: {
                    readonly type: "array";
                    readonly minItems: 1;
                    readonly maxItems: 24;
                    readonly items: {
                        readonly anyOf: readonly [{
                            readonly const: "separator";
                        }, {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["id", "label"];
                            readonly properties: {
                                readonly id: {
                                    readonly type: "string";
                                    readonly pattern: "^[A-Za-z0-9._:-]{1,64}$";
                                };
                                readonly label: {
                                    readonly type: "string";
                                    readonly minLength: 1;
                                    readonly maxLength: 80;
                                };
                                readonly glyph: {
                                    readonly type: "string";
                                    readonly pattern: "^[a-z][a-z0-9-]{0,31}$";
                                };
                                readonly hint: {
                                    readonly type: "string";
                                    readonly maxLength: 24;
                                };
                                readonly disabled: {
                                    readonly type: "boolean";
                                };
                                readonly checked: {
                                    readonly type: "boolean";
                                };
                            };
                        }];
                    };
                };
                readonly id: {
                    readonly type: "string";
                    readonly pattern: "^[A-Za-z0-9._:-]{1,64}$";
                };
                readonly label: {
                    readonly type: "string";
                    readonly minLength: 1;
                    readonly maxLength: 80;
                };
                readonly glyph: {
                    readonly type: "string";
                    readonly pattern: "^[a-z][a-z0-9-]{0,31}$";
                };
                readonly hint: {
                    readonly type: "string";
                    readonly maxLength: 24;
                };
                readonly disabled: {
                    readonly type: "boolean";
                };
                readonly checked: {
                    readonly type: "boolean";
                };
            };
        }];
    };
};
export type MenuItem = {
    id: string;
    label: string;
    glyph?: string;
    hint?: string;
    disabled?: boolean;
    checked?: boolean;
    items?: (MenuItem | 'separator')[];
};
export type MenuDocument = (MenuItem | 'separator')[];
/** Where to draw a menu, in the page's coordinates (a framed page's own; the desktop translates them). */
export type MenuPoint = {
    x: number;
    y: number;
};
/** The menu, checked: every id once across the menu and its submenus; `OS0170` names what is wrong. */
export declare function checkMenu(value: unknown): {
    ok: true;
    value: MenuDocument;
} | {
    ok: false;
    error: {
        code: string;
        message: string;
    };
};
/** A point is two finite numbers; anything else is the top left corner. */
export declare const menuPoint: (at: unknown) => MenuPoint;
