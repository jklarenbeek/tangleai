/** The states a job passes through (Jaren JOBS-FORMAT §2, §10). */
export type JobState = 'pending' | 'leased' | 'done' | 'failed' | 'dead' | 'cancelled';
/** One job as the desktop sees it: no payload, no result, no lease internals. */
export type JobItem = {
    id: string;
    kind: string;
    state: JobState;
    runAt: number;
    attempts: number;
    maxAttempts: number;
    leaseUntil: number | null;
    lastError: {
        message: string;
        code?: string;
    } | null;
    createdAt: number;
    updatedAt: number;
};
/** How many jobs are in each state; `pendingKinds` counts the waiting ones by kind. */
export type JobCounts = Record<JobState, number> & {
    pendingKinds: Record<string, number>;
};
/** A recurring schedule (Jaren JOBS-FORMAT §11): its rule as the document Jaren stored, and where it stands. */
export type JobSchedule = {
    id: string;
    kind: string;
    series: Record<string, unknown>;
    zone: string | null;
    policy: string | null;
    missed: 'skip' | 'once' | {
        catchUp: number;
    };
    latenessMs: number | null;
    state: 'active' | 'unresolved' | 'stalled' | 'ended';
    nextRunAt: number | null;
    nextRecurrenceId: string | null;
    lastRunAt: number | null;
    lastRecurrenceId: string | null;
    counts: {
        fired: number;
        skipped: number;
        uncounted?: number;
    };
    stall: Record<string, unknown> | null;
    createdAt: number;
    updatedAt: number;
};
type Scoped = {
    scope?: string;
};
/** One step of one attempt, as the host's runtime recorded it (no payload; a message is at most 500 characters). */
export type JobEvent = {
    id: string;
    at: number;
    event: 'started' | 'completed' | 'failed' | 'lost' | 'cancelled' | 'not-repeated' | 'budget';
    kind?: string;
    jobId?: string;
    attempt?: number;
    durationMs?: number;
    code?: string;
    message?: string;
    simulated?: boolean;
};
/** A runtime's last heartbeat: when it reported and its worker's counts. */
/** A runtime's last heartbeat; a browser twin also says where it keeps its store and which tab owns it. */
/** `recovered`: when the runtime's store would not open (damaged) and was started fresh, the ISO time it did. */
export type JobRuntimeHealth = {
    runtime: string;
    at: number;
    stats: Record<string, number>;
    storage?: string;
    owner?: string;
    recovered?: string;
};
/** A job the host's registry declares: its title, how safe it is to repeat, and its schedule's id when it has one. */
export type RegisteredJob = {
    kind: string;
    title: Record<string, string>;
    description?: Record<string, string>;
    safety: 'safe-read' | 'provider-idempotent' | 'single-send';
    scheduled: boolean;
    schedule?: string;
    owner?: string;
};
/** A part of a host the desktop shows on its own (a product): its scope and its title per language. */
export type JobScope = {
    scope: string;
    title: Record<string, string>;
};
/** What a host's job queue does: the desktop's Jobs app and the assistant's contract call it. */
export type JobQueue = {
    counts(input?: Scoped): Promise<JobCounts>;
    page(input?: Scoped & {
        state?: JobState;
        kind?: string;
        after?: string;
        limit?: number;
    }): Promise<{
        items: JobItem[];
        next?: string;
    }>;
    get(input: Scoped & {
        id: string;
    }): Promise<JobItem>;
    schedules(input?: Scoped): Promise<{
        schedules: JobSchedule[];
    }>;
    cancel(input: Scoped & {
        id: string;
    }): Promise<{
        changed: boolean;
    }>;
    requeue(input: Scoped & {
        id: string;
    }): Promise<{
        changed: boolean;
    }>;
    unschedule(input: Scoped & {
        id: string;
    }): Promise<{
        changed: boolean;
    }>;
    events(input: Scoped & {
        jobId?: string;
        kind?: string;
        after?: number;
        limit?: number;
    }): Promise<{
        events: JobEvent[];
    }>;
    health(input?: Scoped): Promise<{
        now: number;
        runtimes: JobRuntimeHealth[];
    }>;
    registry(input?: Scoped): Promise<{
        jobs: RegisteredJob[];
    }>;
    run(input: Scoped & {
        kind: string;
    }): Promise<{
        id: string;
    }>;
    /** The parts a combined queue answers for (`combinedJobQueue`); a plain queue is one unnamed scope. */
    scopes?(): JobScope[];
};
/**
 * Refusals, each a coded error: `OS0190` no job host is configured; `OS0191`
 * no such job or schedule; `OS0192` its state forbids the call (a done job, a
 * live lease on requeue); `OS0193` a claimed job whose lease this host does not
 * hold (another process runs it); `OS0194` a scope this host does not serve; `OS0195` the background
 * runtime is starting or changing tabs (a browser twin between owners), not missing.
 */
export declare const JOB_CODES: {
    readonly unconfigured: "OS0190";
    readonly unknown: "OS0191";
    readonly refused: "OS0192";
    readonly held: "OS0193";
    readonly scope: "OS0194";
    readonly starting: "OS0195";
};
export declare const JOB_ITEM_SCHEMA: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly required: readonly ["id", "kind", "state", "runAt", "attempts", "maxAttempts", "leaseUntil", "lastError", "createdAt", "updatedAt"];
    readonly properties: {
        readonly id: {
            readonly type: "string";
            readonly minLength: 1;
            readonly maxLength: 512;
        };
        readonly kind: {
            readonly type: "string";
            readonly maxLength: 200;
        };
        readonly state: {
            readonly enum: readonly ["pending", "leased", "done", "failed", "dead", "cancelled"];
        };
        readonly runAt: {
            readonly type: "number";
        };
        readonly attempts: {
            readonly type: "integer";
            readonly minimum: 0;
        };
        readonly maxAttempts: {
            readonly type: "integer";
            readonly minimum: 0;
        };
        readonly leaseUntil: {
            readonly type: readonly ["number", "null"];
        };
        readonly lastError: {
            readonly oneOf: readonly [{
                readonly type: "null";
            }, {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["message"];
                readonly properties: {
                    readonly message: {
                        readonly type: "string";
                        readonly maxLength: 2000;
                    };
                    readonly code: {
                        readonly type: "string";
                        readonly maxLength: 40;
                    };
                };
            }];
        };
        readonly createdAt: {
            readonly type: "number";
        };
        readonly updatedAt: {
            readonly type: "number";
        };
    };
};
/** The provider contract a host serves (over HTTP from its server, or in a worker). */
export declare const JOB_QUEUE_CONTRACT: {
    readonly $contract: "0.1";
    readonly id: "job_queue";
    readonly operations: {
        readonly 'jobs.counts': {
            readonly kind: "read";
            readonly doc: "How many jobs are in each state, and how many wait per kind.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["pending", "leased", "done", "failed", "dead", "cancelled", "pendingKinds"];
                readonly properties: {
                    readonly pending: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly leased: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly done: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly failed: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly dead: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly cancelled: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly pendingKinds: {
                        readonly type: "object";
                        readonly additionalProperties: {
                            readonly type: "integer";
                            readonly minimum: 0;
                        };
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
                readonly starting: {
                    readonly status: 503;
                };
            };
        };
        readonly 'jobs.page': {
            readonly kind: "read";
            readonly doc: "A page of jobs by id, filtered by state and kind; `next` continues after the last one.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["items"];
                readonly properties: {
                    readonly items: {
                        readonly type: "array";
                        readonly maxItems: 200;
                        readonly items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["id", "kind", "state", "runAt", "attempts", "maxAttempts", "leaseUntil", "lastError", "createdAt", "updatedAt"];
                            readonly properties: {
                                readonly id: {
                                    readonly type: "string";
                                    readonly minLength: 1;
                                    readonly maxLength: 512;
                                };
                                readonly kind: {
                                    readonly type: "string";
                                    readonly maxLength: 200;
                                };
                                readonly state: {
                                    readonly enum: readonly ["pending", "leased", "done", "failed", "dead", "cancelled"];
                                };
                                readonly runAt: {
                                    readonly type: "number";
                                };
                                readonly attempts: {
                                    readonly type: "integer";
                                    readonly minimum: 0;
                                };
                                readonly maxAttempts: {
                                    readonly type: "integer";
                                    readonly minimum: 0;
                                };
                                readonly leaseUntil: {
                                    readonly type: readonly ["number", "null"];
                                };
                                readonly lastError: {
                                    readonly oneOf: readonly [{
                                        readonly type: "null";
                                    }, {
                                        readonly type: "object";
                                        readonly additionalProperties: false;
                                        readonly required: readonly ["message"];
                                        readonly properties: {
                                            readonly message: {
                                                readonly type: "string";
                                                readonly maxLength: 2000;
                                            };
                                            readonly code: {
                                                readonly type: "string";
                                                readonly maxLength: 40;
                                            };
                                        };
                                    }];
                                };
                                readonly createdAt: {
                                    readonly type: "number";
                                };
                                readonly updatedAt: {
                                    readonly type: "number";
                                };
                            };
                        };
                    };
                    readonly next: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 512;
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
                readonly starting: {
                    readonly status: 503;
                };
            };
        };
        readonly 'jobs.get': {
            readonly kind: "read";
            readonly doc: "One job: its kind, state, attempts, instants and last error.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["id", "kind", "state", "runAt", "attempts", "maxAttempts", "leaseUntil", "lastError", "createdAt", "updatedAt"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 512;
                    };
                    readonly kind: {
                        readonly type: "string";
                        readonly maxLength: 200;
                    };
                    readonly state: {
                        readonly enum: readonly ["pending", "leased", "done", "failed", "dead", "cancelled"];
                    };
                    readonly runAt: {
                        readonly type: "number";
                    };
                    readonly attempts: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly maxAttempts: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly leaseUntil: {
                        readonly type: readonly ["number", "null"];
                    };
                    readonly lastError: {
                        readonly oneOf: readonly [{
                            readonly type: "null";
                        }, {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["message"];
                            readonly properties: {
                                readonly message: {
                                    readonly type: "string";
                                    readonly maxLength: 2000;
                                };
                                readonly code: {
                                    readonly type: "string";
                                    readonly maxLength: 40;
                                };
                            };
                        }];
                    };
                    readonly createdAt: {
                        readonly type: "number";
                    };
                    readonly updatedAt: {
                        readonly type: "number";
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
                readonly starting: {
                    readonly status: 503;
                };
            };
        };
        readonly 'jobs.schedules': {
            readonly kind: "read";
            readonly doc: "Every recurring schedule: its rule, zone, state, next and last run, and how many it fired and skipped.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["schedules"];
                readonly properties: {
                    readonly schedules: {
                        readonly type: "array";
                        readonly maxItems: 1000;
                        readonly items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["id", "kind", "series", "zone", "policy", "missed", "latenessMs", "state", "nextRunAt", "nextRecurrenceId", "lastRunAt", "lastRecurrenceId", "counts", "stall", "createdAt", "updatedAt"];
                            readonly properties: {
                                readonly id: {
                                    readonly type: "string";
                                    readonly minLength: 1;
                                    readonly maxLength: 512;
                                };
                                readonly kind: {
                                    readonly type: "string";
                                    readonly maxLength: 200;
                                };
                                readonly series: {
                                    readonly type: "object";
                                };
                                readonly zone: {
                                    readonly type: readonly ["string", "null"];
                                    readonly maxLength: 200;
                                };
                                readonly policy: {
                                    readonly type: readonly ["string", "null"];
                                    readonly maxLength: 200;
                                };
                                readonly missed: {
                                    readonly oneOf: readonly [{
                                        readonly enum: readonly ["skip", "once"];
                                    }, {
                                        readonly type: "object";
                                        readonly additionalProperties: false;
                                        readonly required: readonly ["catchUp"];
                                        readonly properties: {
                                            readonly catchUp: {
                                                readonly type: "integer";
                                                readonly minimum: 0;
                                            };
                                        };
                                    }];
                                };
                                readonly latenessMs: {
                                    readonly type: readonly ["number", "null"];
                                };
                                readonly state: {
                                    readonly enum: readonly ["active", "unresolved", "stalled", "ended"];
                                };
                                readonly nextRunAt: {
                                    readonly type: readonly ["number", "null"];
                                };
                                readonly nextRecurrenceId: {
                                    readonly type: readonly ["string", "null"];
                                    readonly maxLength: 200;
                                };
                                readonly lastRunAt: {
                                    readonly type: readonly ["number", "null"];
                                };
                                readonly lastRecurrenceId: {
                                    readonly type: readonly ["string", "null"];
                                    readonly maxLength: 200;
                                };
                                readonly counts: {
                                    readonly type: "object";
                                    readonly additionalProperties: false;
                                    readonly required: readonly ["fired", "skipped"];
                                    readonly properties: {
                                        readonly fired: {
                                            readonly type: "integer";
                                            readonly minimum: 0;
                                        };
                                        readonly skipped: {
                                            readonly type: "integer";
                                            readonly minimum: 0;
                                        };
                                        readonly uncounted: {
                                            readonly type: "integer";
                                            readonly minimum: 0;
                                        };
                                    };
                                };
                                readonly stall: {
                                    readonly type: readonly ["object", "null"];
                                };
                                readonly createdAt: {
                                    readonly type: "number";
                                };
                                readonly updatedAt: {
                                    readonly type: "number";
                                };
                            };
                        };
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
                readonly starting: {
                    readonly status: 503;
                };
            };
        };
        readonly 'jobs.cancel': {
            readonly kind: "command";
            readonly doc: "Cancel a waiting job, or a running one this host holds the lease of.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["changed"];
                readonly properties: {
                    readonly changed: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
                readonly starting: {
                    readonly status: 503;
                };
            };
        };
        readonly 'jobs.requeue': {
            readonly kind: "command";
            readonly doc: "Return a failed, dead or cancelled job to the queue; its attempts are kept.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["changed"];
                readonly properties: {
                    readonly changed: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
                readonly starting: {
                    readonly status: 503;
                };
            };
        };
        readonly 'jobs.unschedule': {
            readonly kind: "command";
            readonly doc: "Remove a recurring schedule; the jobs it fired stay.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["changed"];
                readonly properties: {
                    readonly changed: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
                readonly starting: {
                    readonly status: 503;
                };
            };
        };
        readonly 'jobs.events': {
            readonly kind: "read";
            readonly doc: "The attempts the host's runtime recorded, newest first: started, completed, failed, lost, cancelled, not repeated, or refused by its budget; filtered by job, kind, and time (`after`, exclusive).";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["events"];
                readonly properties: {
                    readonly events: {
                        readonly type: "array";
                        readonly maxItems: 200;
                        readonly items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["id", "at", "event"];
                            readonly properties: {
                                readonly id: {
                                    readonly type: "string";
                                    readonly minLength: 1;
                                    readonly maxLength: 600;
                                };
                                readonly at: {
                                    readonly type: "number";
                                };
                                readonly event: {
                                    readonly enum: readonly ["started", "completed", "failed", "lost", "cancelled", "not-repeated", "budget"];
                                };
                                readonly kind: {
                                    readonly type: "string";
                                    readonly minLength: 1;
                                    readonly maxLength: 200;
                                };
                                readonly jobId: {
                                    readonly type: "string";
                                    readonly minLength: 1;
                                    readonly maxLength: 512;
                                };
                                readonly attempt: {
                                    readonly type: "integer";
                                    readonly minimum: 0;
                                };
                                readonly durationMs: {
                                    readonly type: "number";
                                    readonly minimum: 0;
                                };
                                readonly code: {
                                    readonly type: "string";
                                    readonly maxLength: 40;
                                };
                                readonly message: {
                                    readonly type: "string";
                                    readonly maxLength: 500;
                                };
                                readonly simulated: {
                                    readonly type: "boolean";
                                };
                            };
                        };
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
                readonly starting: {
                    readonly status: 503;
                };
            };
        };
        readonly 'jobs.health': {
            readonly kind: "read";
            readonly doc: "When each of the host's runtimes last reported, with its worker's counts, and the host's own time.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["now", "runtimes"];
                readonly properties: {
                    readonly now: {
                        readonly type: "number";
                    };
                    readonly runtimes: {
                        readonly type: "array";
                        readonly maxItems: 100;
                        readonly items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["runtime", "at", "stats"];
                            readonly properties: {
                                readonly runtime: {
                                    readonly type: "string";
                                    readonly minLength: 1;
                                    readonly maxLength: 200;
                                };
                                readonly at: {
                                    readonly type: "number";
                                };
                                readonly stats: {
                                    readonly type: "object";
                                    readonly additionalProperties: {
                                        readonly type: "number";
                                    };
                                };
                                readonly storage: {
                                    readonly type: "string";
                                    readonly maxLength: 40;
                                };
                                readonly owner: {
                                    readonly type: "string";
                                    readonly maxLength: 120;
                                };
                                readonly recovered: {
                                    readonly type: "string";
                                    readonly maxLength: 40;
                                };
                            };
                        };
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
                readonly starting: {
                    readonly status: 503;
                };
            };
        };
        readonly 'jobs.registry': {
            readonly kind: "read";
            readonly doc: "The jobs the host's registry declares: their titles, how safe each is to repeat, and their schedules.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["jobs"];
                readonly properties: {
                    readonly jobs: {
                        readonly type: "array";
                        readonly maxItems: 500;
                        readonly items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["kind", "title", "safety", "scheduled"];
                            readonly properties: {
                                readonly kind: {
                                    readonly type: "string";
                                    readonly minLength: 1;
                                    readonly maxLength: 200;
                                };
                                readonly title: {
                                    readonly type: "object";
                                    readonly additionalProperties: {
                                        readonly type: "string";
                                        readonly maxLength: 2000;
                                    };
                                };
                                readonly description: {
                                    readonly type: "object";
                                    readonly additionalProperties: {
                                        readonly type: "string";
                                        readonly maxLength: 2000;
                                    };
                                };
                                readonly safety: {
                                    readonly enum: readonly ["safe-read", "provider-idempotent", "single-send"];
                                };
                                readonly scheduled: {
                                    readonly type: "boolean";
                                };
                                readonly schedule: {
                                    readonly type: "string";
                                    readonly minLength: 1;
                                    readonly maxLength: 512;
                                };
                                readonly owner: {
                                    readonly type: "string";
                                    readonly maxLength: 200;
                                };
                            };
                        };
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
                readonly starting: {
                    readonly status: 503;
                };
            };
        };
        readonly 'jobs.run': {
            readonly kind: "command";
            readonly doc: "Run a registered job now, once; refused while a job of that kind waits or runs.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["id"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 512;
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
                readonly starting: {
                    readonly status: 503;
                };
            };
        };
    };
};
/** A queue that answers `OS0190` for everything: a desktop with no job host. */
export declare const unconfiguredJobQueue: () => JobQueue;
/**
 * The queue a host serves at `baseUrl` (for example `http://127.0.0.1:4700/api/job-queue`). Its declared
 * answers become the codes above; a host that cannot be reached, or answers outside the contract, is
 * `OS0190` marked `unanswered: true`.
 */
export declare function httpJobQueue(baseUrl: string, options?: {
    fetch?: typeof globalThis.fetch;
    timeoutMs?: number;
}): JobQueue;
/** A part of a host the desktop shows on its own: a product, or the host's own runtime. */
/**
 * One queue over several: each entry is a scope (a product's queue at its own address, the host's own runtime) and
 * every call goes to the entry its `scope` names. With several entries a call without a scope, or with one no entry
 * has, is refused `OS0194`; with one entry the scope is optional. `scopes()` answers the entries, in order, for a
 * picker. The scope travels on to the entry's queue, which may check it too.
 */
export declare function combinedJobQueue(entries: readonly {
    scope: string;
    title: Record<string, string>;
    queue: JobQueue;
}[]): JobQueue & {
    scopes(): JobScope[];
};
export {};
