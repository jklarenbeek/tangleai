/**
 * The desktop's job watcher: background work that needs a person reaches
 * them. Over the host's job queue (the `job_queue` contract, `jobs.ts`) it
 * reads, once an interval, the dead jobs, the history since its last read and
 * the runtimes' heartbeats, and files ONE inbox item per job or runtime
 * through the kernel (`fileJobFailure`, `fileRuntimeSilent`): a dead job, a
 * single-send job a crash cut off (`not-repeated`), a job that keeps failing
 * (a third failed attempt), and a background runtime that stopped reporting.
 * An item is updated, never duplicated; a runtime that reports again takes its
 * item back.
 *
 * The item is filed at once — it is in the inbox and in Jobs immediately. Its
 * NOTICE (the item's `attention`, which the dock's mail button shows) is given
 * only inside the person's working hours; outside them, or when the hours are
 * unknown, it waits (unknown time is never working time), and when a working
 * period begins every item still open is noticed again. What the person
 * decided is remembered (`remember`), so a dismissed failure is not filed
 * again after a reload unless the job failed anew.
 *
 * A queue that answers for several products (`scopes()`, a combined queue)
 * is looked at product by product: every item names its product and is keyed
 * by it, and a product whose host is not there or is starting is passed over
 * quietly while the others are still looked at.
 */
import { type JobQueue } from './jobs.ts';
/** The weekdays the Calendar's working hours name. */
export type Weekday = 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun';
/** The person's working hours: the days, and a start and end of day (`HH:MM`, end exclusive). */
export type WorkingHours = {
    days: Weekday[];
    start: string;
    end: string;
};
/** How long a runtime may be silent before the person hears of it (as the Jobs app's warning). */
export declare const SILENT_AFTER_MS = 90000;
type WatchKernel = {
    fileJobFailure(input: {
        jobId: string;
        kind: string;
        titles?: Record<string, string>;
        reason: 'dead' | 'not-repeated' | 'failing';
        lastError?: string;
        attempts: number;
        attention: boolean;
        owner?: string;
        scope?: string;
        scopeTitles?: Record<string, string>;
    }): unknown;
    fileRuntimeSilent(input: {
        runtime: string;
        lastSeen: number;
        attention: boolean;
        scope?: string;
        scopeTitles?: Record<string, string>;
    }): unknown;
    withdrawDesktop(id: string): unknown;
    noticeMail(id: string): unknown;
    mail(): readonly {
        from: string;
        attention?: boolean;
        proposal?: {
            id: string;
            kind: string;
            status: string;
            payload?: unknown;
        };
    }[];
};
export type JobWatchOptions = {
    kernel: WatchKernel;
    queue: JobQueue;
    /** The person's working hours, read at every interval (they change in the Calendar); `undefined` = unknown. */
    hours?: () => WorkingHours | undefined;
    /** The zone the hours are in (default: this browser's). */
    zone?: string;
    now?: () => number;
    intervalMs?: number;
    silentAfterMs?: number;
    /** What the person decided, kept across reloads: job id (with its product's scope, when it has one) → the attempts of the failure they decided on. */
    remember?: {
        load(): Record<string, number>;
        save(decided: Record<string, number>): void;
    };
    setTimer?: (run: () => void, ms: number) => unknown;
    clearTimer?: (handle: unknown) => void;
};
/** Whether `at` falls inside the working hours (in `zone`); unknown hours are never working time. */
export declare function withinHours(at: number, hours: WorkingHours | undefined, zone?: string): boolean;
/** The key a decision is remembered by: the job id, with its product's scope in front when it has one. */
export declare const decisionKey: (jobId: string, scope?: string) => string;
/** Start watching; the first look is immediate. `tick()` looks once (tests drive it); `stop()` ends the watch. */
export declare function watchJobs(options: JobWatchOptions): {
    tick(): Promise<void>;
    stop(): void;
};
export {};
