/**
 * `@tangleai/os/testing`: the desktop without a browser, for an application's
 * own CI. `checkSuite` says whether a suite document will join a desktop, and
 * `createTestDesktop` runs its applications on a real kernel the way a person's
 * link would: joined with consent, their contracts served by the test's own
 * handlers, the assistant reaching only what the consent allows, proposals
 * filed and decided through the inbox's own path.
 */
import { type Decider, type Outcome } from './kernel.ts';
import { type ModuleManifest } from './manifest.ts';
import { type CapabilityDocument } from './capability.ts';
import type { SuiteDocument } from './install-sheet.ts';
export type SuiteIssue = {
    code: string;
    level: 'error' | 'warning';
    path: string;
    message: string;
};
/**
 * Whether a suite document will join a desktop. Errors keep it from joining
 * (not a suite, an invalid manifest, an id used twice or reserved, a contract
 * two applications provide, a page on the desktop's own origin, capabilities
 * that disagree); warnings say what will not work as it stands (a contract it
 * requires that nothing in the suite or the desktop provides).
 */
export declare function checkSuite(value: unknown, options?: {
    desktopOrigin?: string;
    capabilities?: readonly CapabilityDocument[];
    provided?: readonly string[];
}): SuiteIssue[];
type Handlers = Record<string, (input: any) => unknown>;
/**
 * A headless desktop with a suite's applications joined. By default each is
 * joined as a person who allows everything it asks for and lets the assistant
 * use it would; `consent` narrows that per application. `serve` gives the
 * handlers of each contract an application provides (the test stands in for
 * its pages); `assistantGrants` is the host's, `'all'` by default.
 */
export declare function createTestDesktop(options?: {
    suite?: SuiteDocument;
    modules?: unknown[];
    consent?: Record<string, {
        scopes?: string[];
        assistant?: boolean;
    }>;
    serve?: Record<string, Handlers>;
    capabilities?: CapabilityDocument[];
    assistantGrants?: 'all' | string[];
    now?: () => number;
}): Promise<{
    kernel: {
        recovery: boolean;
        install(value: unknown, layer?: import("./kernel.ts").Layer, install?: {
            grant?: boolean;
        }): {
            ok: true;
            manifest: ModuleManifest;
        } | {
            ok: false;
            issues: import("./manifest.ts").ManifestIssue[];
        };
        patch(id: string, patch: unknown[], layer?: import("./kernel.ts").Layer): Outcome;
        remove(id: string): Outcome;
        undo(): Outcome;
        effective(id: string): ModuleManifest | null;
        modules(): ModuleManifest[];
        layerOf(id: string): import("./kernel.ts").Layer | null;
        journal(): import("./kernel.ts").JournalEntry[];
        grant(caller: string, scope: string): void;
        revoke(caller: string, scope: string): void;
        join(value: unknown, allow: {
            scopes: string[];
            assistant: boolean;
            source?: string;
        }): Outcome;
        consentOf(id: string): import("./consent.ts").Consent | null;
        consentNeeded(value: ModuleManifest): {
            needed: false;
        } | {
            needed: true;
            reason: "new" | "origin" | "more";
            scopes: string[];
            provides: string[];
        };
        setConsent(id: string, change: {
            scopes?: string[];
            assistant?: boolean;
        }): Outcome;
        grants(): Record<string, string[]>;
        settings(module: string): unknown;
        setSettings(module: string, values: unknown): Outcome;
        allowed(caller: string, contract: string, op: string): boolean;
        provide(module: string, contractDoc: unknown, client: import("./kernel.ts").ContractClient, owner?: string): void;
        provideLocal(module: string, contractDoc: unknown, handlers: Record<string, (input: any) => unknown>, owner?: string): void;
        withdraw(module: string, owner?: string): void;
        providers(): {
            contract: string;
            module: string;
            operations: string[];
        }[];
        call(caller: string, contract: string, op: string, input?: unknown): Promise<Outcome>;
        ledger(): import("./kernel.ts").LedgerEntry[];
        sendMail(from: string, envelope: {
            to?: string;
            subject: string;
            body?: string;
            data?: unknown;
        }): import("./kernel.ts").MailEnvelope;
        mail(): import("./kernel.ts").MailEnvelope[];
        markRead(id: string): void;
        propose(module: string, input: unknown): Outcome;
        installCapability(doc: unknown, layer?: import("./kernel.ts").Layer): Outcome;
        capabilities(): CapabilityDocument[];
        reviewOf(module: string, kind: string): {
            origins?: string[];
            roles?: string[];
        } | null;
        withdrawProposal(module: string, id: string): Outcome;
        registerDecider(module: string, owner: string, decide: Decider): () => void;
        decide(mailId: string, decision: "accept" | "reject" | "answer", response?: unknown): Promise<Outcome>;
        openersFor(type: string): ModuleManifest[];
        fileLocations(): {
            module: string;
            contract: string;
            title: string;
            assistant: boolean;
            served: boolean;
        }[];
        dock(): import("./dock.ts").DockLayout | null;
        state(key: string, scope?: import("./state.ts").StateScope): unknown;
        setState(key: string, value: unknown, scope?: import("./state.ts").StateScope): Outcome;
        ready(): Promise<void>;
        stateStatus(): import("./kernel.ts").StateStatus;
        reloadState(): Promise<void>;
        flushState(): Promise<void>;
        dockRevision(): number;
        setDock(layout: unknown): Outcome;
        dockView(): {
            revision: number;
            layout: import("./dock.ts").DockLayout;
            items: ({
                icon: {
                    id: string;
                    title: string;
                };
                folder?: undefined;
                title?: undefined;
                icons?: undefined;
            } | {
                folder: string;
                title: string;
                icons: {
                    id: string;
                    title: string;
                }[];
                icon?: undefined;
            })[];
            hidden: {
                id: string;
                title: string;
            }[];
        };
        proposeApp(caller: string, offer: {
            title: string;
            summary?: string;
            doc: unknown;
        }): Promise<Outcome>;
        reviseApp(caller: string, offer: {
            module: string;
            revision: string;
            summary?: string;
            doc: unknown;
        }): Promise<Outcome>;
        proposeJobChange(caller: string, input: {
            action: "cancel" | "requeue" | "unschedule" | "run";
            id?: string;
            kind?: string;
            reason: string;
            scope?: string;
        }): Promise<Outcome>;
        fileJobFailure(input: {
            jobId: string;
            kind: string;
            titles?: Record<string, string>;
            reason: "dead" | "not-repeated" | "failing";
            lastError?: string;
            attempts: number;
            attention: boolean;
            owner?: string;
            scope?: string;
            scopeTitles?: Record<string, string>;
        }): Outcome;
        fileRuntimeSilent(input: {
            runtime: string;
            lastSeen: number;
            attention: boolean;
            scope?: string;
            scopeTitles?: Record<string, string>;
        }): Outcome;
        withdrawDesktop(id: string): Outcome;
        noticeMail(id: string): Outcome;
        suggestDock(caller: string, layout: unknown): Outcome;
        setHeader(module: string, window: string, header: unknown): Outcome;
        header(window: string): import("./header.ts").Header | undefined;
        headers(caller?: string): {
            window: string;
            module: string;
            header: import("./header.ts").Header;
        }[];
        registerHeaderHandler(module: string, window: string, handle: import("./header.ts").HeaderHandler): () => void;
        hasHeaderHandler(window: string): boolean;
        activateHeader(caller: string, window: string, item: string, value?: unknown): Promise<Outcome>;
        serveModule(module: string, port: any, hooks?: {
            setTitle?: (title: string) => void;
            openSettings?: () => void;
            window?: string;
            menu?: (items: unknown, at: unknown, check: boolean) => Promise<{
                id: string | null;
            } | {
                refused: {
                    code: string;
                    message: string;
                };
            }>;
        }): import("./kernel.ts").ServedContract;
        connectProvider(module: string, contractDoc: unknown, port: any, timeoutMs?: number, owner?: string): import("./kernel.ts").ContractClient;
        operations(caller?: string): import("./kernel.ts").GrantedOperation[];
        tools(caller?: string): any;
        webReader(): import("./web.ts").WebReader;
        jobQueue(): import("./jobs.ts").JobQueue;
        subscribe(listener: (event: import("./kernel.ts").KernelEvent) => void): () => boolean;
    };
    /** The applications joined, in order. */
    joined: string[];
    /** What the desktop kept in the person's state (the joined applications and their consent among it). */
    state: () => import("./state.ts").StateDocument[];
    /** One operation as a caller makes it: a module id, `assistant`, or `shell` for the person's own hand. */
    call: (caller: string, contract: string, op: string, input?: unknown) => Promise<Outcome>;
    /** What the assistant is offered, as plain data, and a call it makes. */
    assistant: {
        operations: () => import("./kernel.ts").GrantedOperation[];
        call: (contract: string, op: string, input?: unknown) => Promise<Outcome>;
    };
    /** File a proposal as an application. */
    propose: (module: string, proposal: unknown) => Outcome;
    /** Where an application's decisions arrive; by default each is accepted by the test and recorded. */
    onDecision: (module: string, decide?: Decider) => () => void;
    /** Decide a proposal in the inbox as the person would. */
    decide: (mailId: string, decision: "accept" | "reject" | "answer", response?: unknown) => Promise<Outcome>;
    /** Every decision that reached an application through `onDecision`. */
    decisions: () => {
        module: string;
        decision: Parameters<Decider>[0];
    }[];
    mail: () => import("./kernel.ts").MailEnvelope[];
    ledger: () => import("./kernel.ts").LedgerEntry[];
}>;
export type TestDesktop = Awaited<ReturnType<typeof createTestDesktop>>;
export {};
