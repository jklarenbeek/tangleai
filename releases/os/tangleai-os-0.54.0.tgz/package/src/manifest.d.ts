import moduleSchema from '../schemas/module.schema.json' with { type: "json" };
export { moduleSchema as MODULE_MANIFEST_SCHEMA };
export type LocalizedText = {
    en: string;
} & Partial<Record<'ar' | 'de' | 'es' | 'fr' | 'ja' | 'ko' | 'nl' | 'pt' | 'ru' | 'tr' | 'zh-TW', string>>;
export type ModuleHost = {
    kind: 'shipped';
    mount: string;
} | {
    kind: 'document';
    app: Record<string, unknown>;
} | {
    kind: 'origin';
    url: string;
};
export type ContractDocument = {
    $contract: string;
    id: string;
    operations: Record<string, unknown>;
    [member: string]: unknown;
};
export type ModuleManifest = {
    $module: '0.1';
    id: string;
    version: string;
    title: LocalizedText;
    description?: LocalizedText;
    icon?: {
        glyph: string;
        hue?: number;
    };
    category?: 'system' | 'productivity' | 'development' | 'data' | 'communication' | 'suite' | 'play' | 'custom';
    host: ModuleHost;
    provides?: ContractDocument[];
    requires?: {
        contract: string;
        operations?: string[];
    }[];
    styles?: string;
    window?: {
        width?: number;
        height?: number;
        minWidth?: number;
        minHeight?: number;
        singleton?: boolean;
        resizable?: boolean;
    };
    settings?: ModuleSettings;
    /** The kinds of proposal it files in the desktop's inbox. */
    proposals?: {
        kind: string;
        title?: LocalizedText;
    }[];
    /**
     * Launch entries: each is its own dock icon that opens this module at one of
     * its screens (an application whose screens live inside one page). Without
     * entries the module is one icon.
     */
    entries?: {
        id: string;
        title: LocalizedText;
        icon?: {
            glyph: string;
            hue?: number;
        };
        screen?: string;
        folder?: string;
    }[];
    /**
     * Where its icons go in a dock the person has not arranged yet: `folder`
     * for the module's own icon, and the titles of the folders it (or its
     * entries) name. A suite's manifests share folder ids.
     */
    dock?: {
        folder?: string;
        folders?: {
            id: string;
            title: LocalizedText;
        }[];
    };
    /**
     * Its files, for the desktop's Files: the contract it serves as a file
     * location (built with `fileLocationContract`, declared in `provides`), the
     * location's title, and `assistant: false` to keep the assistant out of it.
     */
    files?: {
        contract: string;
        title?: LocalizedText;
        assistant?: boolean;
    };
    /** The kinds of file it opens (`text/calendar`, `image/*`): Files offers it for them, and hands it the file. */
    opens?: {
        type: string;
        title?: LocalizedText;
    }[];
};
/** Where a module's settings live in the desktop's Settings (see the schema's `settings`). */
export type ModuleSettings = {
    title?: LocalizedText;
    keywords?: string[];
} & ({
    kind: 'mount';
    mount: string;
} | {
    kind: 'page';
    url: string;
} | {
    kind: 'form';
    schema: Record<string, unknown>;
});
export type ManifestIssue = {
    code: string;
    path: string;
    message: string;
};
export type ManifestVerdict = {
    ok: true;
    manifest: ModuleManifest;
} | {
    ok: false;
    issues: ManifestIssue[];
};
/**
 * Validate a module manifest. Returns a frozen copy on success, so a caller
 * holding the input cannot change an installed module behind the kernel's
 * back; refusals carry a JSON pointer and a code (`OS0001` shape, `OS0002`
 * host kind, `OS0003` duplicate contract, `OS0004` settings that do not fit
 * the module, `OS0005` a launch entry or a folder named twice, `OS0006` a file
 * location whose contract the module does not provide).
 */
export declare function validateManifest(value: unknown): ManifestVerdict;
/** The text for a locale, falling back to English. */
export declare function localized(text: LocalizedText | undefined, locale: string): string;
