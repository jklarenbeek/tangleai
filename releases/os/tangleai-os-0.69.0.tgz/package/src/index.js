/**
 * @tangleai/os — the browser operating system for Tangle suites.
 *
 * The root entry is headless: manifests, the kernel, window state, themes and
 * the message catalogue. The DOM shell is `@tangleai/os/shell`; an application
 * page joins a desktop with `@tangleai/os/module`; a host bundles
 * `@tangleai/os/module-host` once as a classic script for document modules.
 */
export { MODULE_MANIFEST_SCHEMA, validateManifest, localized } from "./manifest.js";
export { createKernel, toolName, DOCK_CONTRACT, FILES_CONTRACT, WEB_CONTRACT, JOBS_CONTRACT, webPageText, RESERVED_IDS } from "./kernel.js";
export { CAPABILITY_SCHEMA, capabilityIssues, checkCapabilities, capabilityPrompt, capabilitiesPrompt, composeCapabilities } from "./capability.js";
export { fileLocationContract, memoryLocation, browserLocation, serveFileLocation, fileAnswer, typeOfName, MAX_INLINE_BYTES, FILE_ENTRY_SCHEMA, fileBytesToBase64, fileBase64ToBytes } from "./files.js";
export { STATE_CONTRACT, memoryStore, webStorageStore, contractStore } from "./state.js";
export { APPS_KEY, scopesOf, originOf, isLocalOrigin, consentNeeded } from "./consent.js";
export { OS_CONTRACT, MODULE_CONTRACT, PROPOSAL_SCHEMA, DECISION_SCHEMA, systemContracts, CONNECT, HELLO, KEY, FOCUS, PROTOCOL } from "./contracts.js";
export { DOCK_SCHEMA, emptyDock, dockIcons, folderTitles, normalizeDock, arrangeDock, moveInDock, hideInDock, showInDock, groupInDock, renameDockFolder, dockChanges } from "./dock.js";
export { HEADER_SCHEMA, HEADER_CONTRACT, HEADER_GLYPHS, headerItems, headerFor, activateHeader, duplicateHeaderId, fitHeader } from "./header.js";
export { emptyDesktop, openWindow, focusWindow, closeWindow, moveWindow, resizeWindow, resizeWindowFrom, toggleMaximize, minimizeWindow, setTitle, setViewport, setCompact, resizeDesktop, isVisible, stacked, fit, } from "./windows.js";
export { DEFAULT_THEMES, AURORA, checkTheme } from "./theme.js";
export { weaveSvg, weaveBackground, PATTERNS, patternBackground } from "./wallpaper.js";
export { THEME_KITS, composeTheme } from "./themes.js";
export { osMessagesEn, createOsMessages, format } from "./messages.js";
export { MENU_SCHEMA, checkMenu } from "./menu.js";
export { WEB_READER_CONTRACT, WEB_PAGE_SCHEMA, WEB_CODES, unconfiguredWebReader } from "./web.js";
export { httpWebReader } from "./web-client.js";
export { JOB_QUEUE_CONTRACT, JOB_ITEM_SCHEMA, JOB_CODES, unconfiguredJobQueue, httpJobQueue } from "./jobs.js";
export { jobsModule, describeRule, nextRuns, STATE_ORDER } from "./jobs-app.js";
