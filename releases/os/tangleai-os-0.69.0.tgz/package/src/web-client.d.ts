import { type WebReader } from './web.ts';
/** A reader over the contract a host serves at `baseUrl` (for example `http://127.0.0.1:4700/api/web-reader`). */
export declare function httpWebReader(baseUrl: string, options?: {
    fetch?: typeof globalThis.fetch;
    timeoutMs?: number;
}): WebReader;
