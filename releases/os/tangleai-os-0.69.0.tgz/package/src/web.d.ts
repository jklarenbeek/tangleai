/**
 * Web reading: how the desktop, and its assistant, read websites. A page in a
 * browser cannot fetch most of the web (cross-origin rules, and no address
 * lookup to refuse private hosts), so a HOST reads for it: it serves the
 * `web_reader` provider contract from its server (built on a safe static
 * fetcher and an HTML extractor), and the desktop draws what comes back in
 * its own look. A third-party page is never framed: the reader shows the
 * page's extracted blocks, and "open original" is a new tab.
 *
 * The assistant reads through the kernel's `tangle_os_web` contract, under
 * grants, in the ledger and within a budget (a rolling window per caller),
 * and every answer it gets frames the page's text as untrusted data, never
 * instructions.
 */
/** A link a page carries: its text and the absolute address it points to. */
export type WebLink = {
    text: string;
    href: string;
};
/** One readable block of a page, in reading order. */
export type WebBlock = {
    kind: 'heading';
    level: 1 | 2 | 3 | 4 | 5 | 6;
    text: string;
} | {
    kind: 'paragraph';
    text: string;
    links?: WebLink[];
} | {
    kind: 'list';
    ordered: boolean;
    items: string[];
} | {
    kind: 'quote';
    text: string;
} | {
    kind: 'code';
    text: string;
} | {
    kind: 'table';
    rows: string[][];
};
/** A page as the reader shows it. `finalUrl` is where the redirects ended; `truncated` when the byte cap cut it. */
export type WebPage = {
    url: string;
    finalUrl: string;
    title: string;
    lang?: string;
    blocks: WebBlock[];
    links: WebLink[];
    fetchedAt: string;
    redirects: string[];
    truncated?: boolean;
};
/** One search result. */
export type WebResult = {
    title: string;
    url: string;
    snippet?: string;
};
/** What a host's reader does: the desktop's Web app and the kernel's `tangle_os_web` call it. */
export type WebReader = {
    read(input: {
        url: string;
    }): Promise<WebPage>;
    search(input: {
        query: string;
        limit?: number;
    }): Promise<{
        results: WebResult[];
    }>;
};
/**
 * Refusals a reader answers, each a coded error:
 * `OS0180` no web access is configured on this desktop; `OS0181` the address is
 * refused (not http(s), a private or local host, a policy, robots); `OS0182` the
 * site could not be read (unreachable, a timeout, an HTTP error, not a page it
 * can read); `OS0183` the caller's web budget is spent (see `WebBudget`).
 */
export declare const WEB_CODES: {
    readonly unconfigured: "OS0180";
    readonly refused: "OS0181";
    readonly unreadable: "OS0182";
    readonly budget: "OS0183";
};
export declare const WEB_PAGE_SCHEMA: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly required: readonly ["url", "finalUrl", "title", "blocks", "links", "fetchedAt", "redirects"];
    readonly properties: {
        readonly url: {
            readonly type: "string";
            readonly minLength: 1;
            readonly maxLength: 2048;
        };
        readonly finalUrl: {
            readonly type: "string";
            readonly minLength: 1;
            readonly maxLength: 2048;
        };
        readonly title: {
            type: string;
            maxLength: number;
        };
        readonly lang: {
            type: string;
            maxLength: number;
        };
        readonly blocks: {
            readonly type: "array";
            readonly maxItems: 2000;
            readonly items: {
                readonly type: "object";
                readonly required: readonly ["kind"];
                readonly properties: {
                    readonly kind: {
                        readonly enum: readonly ["heading", "paragraph", "list", "quote", "code", "table"];
                    };
                };
            };
        };
        readonly links: {
            readonly type: "array";
            readonly maxItems: 1000;
            readonly items: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["text", "href"];
                readonly properties: {
                    readonly text: {
                        type: string;
                        maxLength: number;
                    };
                    readonly href: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 2048;
                    };
                };
            };
        };
        readonly fetchedAt: {
            readonly type: "string";
            readonly maxLength: 40;
        };
        readonly redirects: {
            readonly type: "array";
            readonly maxItems: 20;
            readonly items: {
                readonly type: "string";
                readonly minLength: 1;
                readonly maxLength: 2048;
            };
        };
        readonly truncated: {
            readonly type: "boolean";
        };
    };
};
/** The provider contract a host serves (over HTTP from its server, or locally in a test). */
export declare const WEB_READER_CONTRACT: {
    readonly $contract: "0.1";
    readonly id: "web_reader";
    readonly operations: {
        readonly 'web.read': {
            readonly kind: "read";
            readonly doc: "Read one web page: its title, its readable blocks in order and its links, with the address the redirects ended at.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["url"];
                readonly properties: {
                    readonly url: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 2048;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["url", "finalUrl", "title", "blocks", "links", "fetchedAt", "redirects"];
                readonly properties: {
                    readonly url: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 2048;
                    };
                    readonly finalUrl: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 2048;
                    };
                    readonly title: {
                        type: string;
                        maxLength: number;
                    };
                    readonly lang: {
                        type: string;
                        maxLength: number;
                    };
                    readonly blocks: {
                        readonly type: "array";
                        readonly maxItems: 2000;
                        readonly items: {
                            readonly type: "object";
                            readonly required: readonly ["kind"];
                            readonly properties: {
                                readonly kind: {
                                    readonly enum: readonly ["heading", "paragraph", "list", "quote", "code", "table"];
                                };
                            };
                        };
                    };
                    readonly links: {
                        readonly type: "array";
                        readonly maxItems: 1000;
                        readonly items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["text", "href"];
                            readonly properties: {
                                readonly text: {
                                    type: string;
                                    maxLength: number;
                                };
                                readonly href: {
                                    readonly type: "string";
                                    readonly minLength: 1;
                                    readonly maxLength: 2048;
                                };
                            };
                        };
                    };
                    readonly fetchedAt: {
                        readonly type: "string";
                        readonly maxLength: 40;
                    };
                    readonly redirects: {
                        readonly type: "array";
                        readonly maxItems: 20;
                        readonly items: {
                            readonly type: "string";
                            readonly minLength: 1;
                            readonly maxLength: 2048;
                        };
                    };
                    readonly truncated: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly errors: {
                readonly refused: {
                    readonly status: 403;
                };
                readonly unreadable: {
                    readonly status: 502;
                };
            };
        };
        readonly 'web.search': {
            readonly kind: "read";
            readonly doc: "Search the web: titles, addresses and snippets of the results, best first.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["query"];
                readonly properties: {
                    readonly query: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 400;
                    };
                    readonly limit: {
                        readonly type: "integer";
                        readonly minimum: 1;
                        readonly maximum: 20;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["results"];
                readonly properties: {
                    readonly results: {
                        readonly type: "array";
                        readonly maxItems: 20;
                        readonly items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["title", "url"];
                            readonly properties: {
                                readonly title: {
                                    type: string;
                                    maxLength: number;
                                };
                                readonly url: {
                                    readonly type: "string";
                                    readonly minLength: 1;
                                    readonly maxLength: 2048;
                                };
                                readonly snippet: {
                                    type: string;
                                    maxLength: number;
                                };
                            };
                        };
                    };
                };
            };
            readonly errors: {
                readonly refused: {
                    readonly status: 403;
                };
                readonly unreadable: {
                    readonly status: 502;
                };
            };
        };
    };
};
/** A reader that answers `OS0180` for everything: the desktop with no web access configured. */
export declare const unconfiguredWebReader: () => WebReader;
