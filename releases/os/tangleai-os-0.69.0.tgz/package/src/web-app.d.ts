/**
 * The desktop's Web: a reader of web pages, never a browser frame. A host
 * reads a page for it (a page cannot fetch most of the web itself; see
 * `./web.ts`), and the reader draws the page's extracted blocks in the
 * desktop's own look: headings, paragraphs with their links, lists, quotes,
 * code and tables. Nothing a page carries runs or is drawn as markup, and no
 * third-party page is ever framed: "Open original" is a new tab.
 *
 * The address bar takes an address or search words. A link on a page opens
 * in the reader (only http and https); back and forward walk what the person
 * read and searched.
 */
import { type OsCatalogue } from './messages.ts';
import { type WebBlock, type WebLink, type WebReader } from './web.ts';
import type { ModuleManifest } from './manifest.ts';
import type { ShippedMount } from './shell.ts';
export type WebOptions = {
    /** Reads and searches for the desktop: the host's, or `unconfiguredWebReader()` where it has none. */
    reader: WebReader;
    /** Where the person sets up web access (the host's own Settings section); the desktop's Settings by default. */
    configure?: () => void;
    messages?: Partial<OsCatalogue>;
    /** The language `messages` is in: the desktop's own title of Web in it. */
    locale?: string;
    id?: string;
};
/** What the address bar holds: an address to read, words to search for, or nothing. */
export type AddressIntent = {
    kind: 'read';
    url: string;
} | {
    kind: 'search';
    query: string;
} | {
    kind: 'empty';
};
/** An address when it is one (`https://…`, or a bare host such as `example.org/page`), else a search. */
export declare function classifyAddress(text: string): AddressIntent;
/** A link the reader may follow: an absolute http(s) address (resolved against `base`), or null. */
export declare function admitLink(href: string, base?: string): string | null;
/** A paragraph's text with its links placed where their words stand; a link whose words are not in it follows at the end. */
export declare function linkify(text: string, links?: readonly WebLink[]): (string | WebLink)[];
/** A block as the desktop draws it: a tag, its text or children; never a page's markup. */
export type ReaderNode = {
    tag: string;
    text?: string;
    link?: WebLink;
    children?: ReaderNode[];
};
export declare function blockNodes(blocks: readonly WebBlock[]): ReaderNode[];
/** The Web module: its manifest and its mount. */
export declare function webModule(options: WebOptions): {
    manifest: ModuleManifest;
    mount: ShippedMount;
};
