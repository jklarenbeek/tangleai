/**
 * Background work on the desktop: what a host's job queue holds and what its
 * recurring schedules will do, read through one contract, `job_queue`, that a
 * host serves from its own store (Jaren's durable queue and its schedules).
 * The work itself runs in the host's background process, never in the page
 * that shows it; the desktop observes it and the person steers it with the
 * queue's own fenced calls (cancel, requeue, unschedule).
 *
 * What a job carries for its handler (`payload`) and what it answered
 * (`result`) never cross this contract: they are the host's data, often a
 * customer's. A job is its kind, its state, its attempts, its instants and its
 * last error. Every call takes an optional `scope`, the part of a host a
 * desktop asks about (a product); a host that serves one store ignores it or
 * refuses another.
 */
import { compileContract } from '@jarenjs/contract';
import { openHttpClient } from '@jarenjs/contract/client';
/**
 * Refusals, each a coded error: `OS0190` no job host is configured; `OS0191`
 * no such job or schedule; `OS0192` its state forbids the call (a done job, a
 * live lease on requeue); `OS0193` a claimed job whose lease this host does not
 * hold (another process runs it); `OS0194` a scope this host does not serve.
 */
export const JOB_CODES = { unconfigured: 'OS0190', unknown: 'OS0191', refused: 'OS0192', held: 'OS0193', scope: 'OS0194' };
const ID = { type: 'string', minLength: 1, maxLength: 512 };
const SCOPE = { type: 'string', minLength: 1, maxLength: 120 };
const MS = { type: 'number' };
const MS_OR_NULL = { type: ['number', 'null'] };
const TEXT_OR_NULL = { type: ['string', 'null'], maxLength: 200 };
const STATE = { enum: ['pending', 'leased', 'done', 'failed', 'dead', 'cancelled'] };
const COUNT = { type: 'integer', minimum: 0 };
const scoped = (properties = {}, required = []) => ({ type: 'object', additionalProperties: false, required, properties: { scope: SCOPE, ...properties } });
export const JOB_ITEM_SCHEMA = {
    type: 'object', additionalProperties: false,
    required: ['id', 'kind', 'state', 'runAt', 'attempts', 'maxAttempts', 'leaseUntil', 'lastError', 'createdAt', 'updatedAt'],
    properties: {
        id: ID, kind: { type: 'string', maxLength: 200 }, state: STATE,
        runAt: MS, attempts: COUNT, maxAttempts: COUNT, leaseUntil: MS_OR_NULL,
        lastError: { oneOf: [{ type: 'null' }, { type: 'object', additionalProperties: false, required: ['message'], properties: { message: { type: 'string', maxLength: 2000 }, code: { type: 'string', maxLength: 40 } } }] },
        createdAt: MS, updatedAt: MS,
    },
};
const SCHEDULE_SCHEMA = {
    type: 'object', additionalProperties: false,
    required: ['id', 'kind', 'series', 'zone', 'policy', 'missed', 'latenessMs', 'state', 'nextRunAt', 'nextRecurrenceId', 'lastRunAt', 'lastRecurrenceId', 'counts', 'stall', 'createdAt', 'updatedAt'],
    properties: {
        id: ID, kind: { type: 'string', maxLength: 200 }, series: { type: 'object' },
        zone: TEXT_OR_NULL, policy: TEXT_OR_NULL,
        missed: { oneOf: [{ enum: ['skip', 'once'] }, { type: 'object', additionalProperties: false, required: ['catchUp'], properties: { catchUp: COUNT } }] },
        latenessMs: MS_OR_NULL, state: { enum: ['active', 'unresolved', 'stalled', 'ended'] },
        nextRunAt: MS_OR_NULL, nextRecurrenceId: TEXT_OR_NULL, lastRunAt: MS_OR_NULL, lastRecurrenceId: TEXT_OR_NULL,
        counts: { type: 'object', additionalProperties: false, required: ['fired', 'skipped'], properties: { fired: COUNT, skipped: COUNT, uncounted: COUNT } },
        stall: { type: ['object', 'null'] }, createdAt: MS, updatedAt: MS,
    },
};
const KIND = { type: 'string', minLength: 1, maxLength: 200 };
const TEXTS = { type: 'object', additionalProperties: { type: 'string', maxLength: 2000 } };
const EVENT_SCHEMA = {
    type: 'object', additionalProperties: false, required: ['id', 'at', 'event'],
    properties: {
        id: { type: 'string', minLength: 1, maxLength: 600 }, at: MS,
        event: { enum: ['started', 'completed', 'failed', 'lost', 'cancelled', 'not-repeated', 'budget'] },
        kind: KIND, jobId: ID, attempt: COUNT, durationMs: { type: 'number', minimum: 0 },
        code: { type: 'string', maxLength: 40 }, message: { type: 'string', maxLength: 500 }, simulated: { type: 'boolean' },
    },
};
const HEALTH_SCHEMA = { type: 'object', additionalProperties: false, required: ['runtime', 'at', 'stats'], properties: { runtime: { type: 'string', minLength: 1, maxLength: 200 }, at: MS, stats: { type: 'object', additionalProperties: { type: 'number' } } } };
const REGISTERED_SCHEMA = {
    type: 'object', additionalProperties: false, required: ['kind', 'title', 'safety', 'scheduled'],
    properties: { kind: KIND, title: TEXTS, description: TEXTS, safety: { enum: ['safe-read', 'provider-idempotent', 'single-send'] }, scheduled: { type: 'boolean' }, schedule: ID, owner: { type: 'string', maxLength: 200 } },
};
const CHANGED = { type: 'object', additionalProperties: false, required: ['changed'], properties: { changed: { type: 'boolean' } } };
const ERRORS = { unknown: { status: 404 }, refused: { status: 409 }, held: { status: 423 }, scope: { status: 400 } };
/** The provider contract a host serves (over HTTP from its server, or in a worker). */
export const JOB_QUEUE_CONTRACT = {
    $contract: '0.1',
    id: 'job_queue',
    operations: {
        'jobs.counts': { kind: 'read', doc: 'How many jobs are in each state, and how many wait per kind.', input: scoped(),
            output: { type: 'object', additionalProperties: false, required: ['pending', 'leased', 'done', 'failed', 'dead', 'cancelled', 'pendingKinds'],
                properties: { pending: COUNT, leased: COUNT, done: COUNT, failed: COUNT, dead: COUNT, cancelled: COUNT, pendingKinds: { type: 'object', additionalProperties: COUNT } } }, errors: ERRORS },
        'jobs.page': { kind: 'read', doc: 'A page of jobs by id, filtered by state and kind; `next` continues after the last one.',
            input: scoped({ state: STATE, kind: { type: 'string', minLength: 1, maxLength: 200 }, after: ID, limit: { type: 'integer', minimum: 1, maximum: 200 } }),
            output: { type: 'object', additionalProperties: false, required: ['items'], properties: { items: { type: 'array', maxItems: 200, items: JOB_ITEM_SCHEMA }, next: ID } }, errors: ERRORS },
        'jobs.get': { kind: 'read', doc: 'One job: its kind, state, attempts, instants and last error.', input: scoped({ id: ID }, ['id']), output: JOB_ITEM_SCHEMA, errors: ERRORS },
        'jobs.schedules': { kind: 'read', doc: 'Every recurring schedule: its rule, zone, state, next and last run, and how many it fired and skipped.', input: scoped(),
            output: { type: 'object', additionalProperties: false, required: ['schedules'], properties: { schedules: { type: 'array', maxItems: 1000, items: SCHEDULE_SCHEMA } } }, errors: ERRORS },
        'jobs.cancel': { kind: 'command', doc: 'Cancel a waiting job, or a running one this host holds the lease of.', input: scoped({ id: ID }, ['id']), output: CHANGED, errors: ERRORS },
        'jobs.requeue': { kind: 'command', doc: 'Return a failed, dead or cancelled job to the queue; its attempts are kept.', input: scoped({ id: ID }, ['id']), output: CHANGED, errors: ERRORS },
        'jobs.unschedule': { kind: 'command', doc: 'Remove a recurring schedule; the jobs it fired stay.', input: scoped({ id: ID }, ['id']), output: CHANGED, errors: ERRORS },
        'jobs.events': { kind: 'read', doc: 'The attempts the host\'s runtime recorded, newest first: started, completed, failed, lost, cancelled, not repeated, or refused by its budget; filtered by job, kind, and time (`after`, exclusive).',
            input: scoped({ jobId: ID, kind: KIND, after: MS, limit: { type: 'integer', minimum: 1, maximum: 200 } }),
            output: { type: 'object', additionalProperties: false, required: ['events'], properties: { events: { type: 'array', maxItems: 200, items: EVENT_SCHEMA } } }, errors: ERRORS },
        'jobs.health': { kind: 'read', doc: 'When each of the host\'s runtimes last reported, with its worker\'s counts, and the host\'s own time.', input: scoped(),
            output: { type: 'object', additionalProperties: false, required: ['now', 'runtimes'], properties: { now: MS, runtimes: { type: 'array', maxItems: 100, items: HEALTH_SCHEMA } } }, errors: ERRORS },
        'jobs.registry': { kind: 'read', doc: 'The jobs the host\'s registry declares: their titles, how safe each is to repeat, and their schedules.', input: scoped(),
            output: { type: 'object', additionalProperties: false, required: ['jobs'], properties: { jobs: { type: 'array', maxItems: 500, items: REGISTERED_SCHEMA } } }, errors: ERRORS },
        'jobs.run': { kind: 'command', doc: 'Run a registered job now, once; refused while a job of that kind waits or runs.', input: scoped({ kind: KIND }, ['kind']),
            output: { type: 'object', additionalProperties: false, required: ['id'], properties: { id: ID } }, errors: ERRORS },
    },
};
const coded = (code, message) => Object.assign(new Error(message), { code });
/** A queue that answers `OS0190` for everything: a desktop with no job host. */
export const unconfiguredJobQueue = () => {
    const refuse = async () => { throw coded(JOB_CODES.unconfigured, 'no job host is configured on this desktop'); };
    return { counts: refuse, page: refuse, get: refuse, schedules: refuse, cancel: refuse, requeue: refuse, unschedule: refuse, events: refuse, health: refuse, registry: refuse, run: refuse };
};
let compiled = null;
/**
 * The queue a host serves at `baseUrl` (for example `http://127.0.0.1:4700/api/job-queue`). Its declared
 * answers become the codes above; a host that cannot be reached, or answers outside the contract, is
 * `OS0190` marked `unanswered: true`.
 */
export function httpJobQueue(baseUrl, options = {}) {
    compiled ??= compileContract(JOB_QUEUE_CONTRACT);
    const client = openHttpClient(compiled, { baseUrl: baseUrl.replace(/\/+$/, ''), timeoutMs: options.timeoutMs ?? 15_000, ...(options.fetch ? { fetch: options.fetch } : {}) });
    const invoke = async (op, input) => {
        const outcome = await client.invoke(op, input ?? {});
        if (outcome.ok)
            return outcome.value;
        const detail = String(outcome.error?.details?.detail ?? outcome.error?.message ?? outcome.kind);
        const declared = outcome.kind === 'failure' ? JOB_CODES[outcome.error?.code] : undefined;
        if (declared)
            throw coded(declared, detail);
        throw Object.assign(coded(JOB_CODES.unconfigured, `the job host at ${baseUrl} did not answer: ${detail}`), { unanswered: true });
    };
    return {
        counts: (input) => invoke('jobs.counts', input), page: (input) => invoke('jobs.page', input),
        get: (input) => invoke('jobs.get', input), schedules: (input) => invoke('jobs.schedules', input),
        cancel: (input) => invoke('jobs.cancel', input), requeue: (input) => invoke('jobs.requeue', input),
        unschedule: (input) => invoke('jobs.unschedule', input),
        events: (input) => invoke('jobs.events', input), health: (input) => invoke('jobs.health', input),
        registry: (input) => invoke('jobs.registry', input), run: (input) => invoke('jobs.run', input),
    };
}
