/**
 * The module side of the desktop: what an application page calls to join a
 * Tangle OS desktop that frames it. It waits for the shell's ports, serves the
 * module's own contracts and the module control contract on them, opens a
 * client for the kernel's `tangle_os` contract, and applies the theme and
 * language the shell pushes. An application on its own origin keeps its
 * server, its keys and its sign-in; the desktop sees only its contracts.
 */
import { compileContract } from '@jarenjs/contract';
import { servePort, openPortClient } from '@jarenjs/contract/port';
import { CONNECT, FOCUS, HELLO, PROTOCOL, systemContracts } from "./contracts.js";
/** A refused connection: `OS0401` no desktop answered in time, `OS0402` the page is not framed, `OS0403` abandoned. */
export class OsConnectError extends Error {
    code;
    constructor(code, message, options) { super(`${code}: ${message}`, options); this.code = code; this.name = 'OsConnectError'; }
}
/** Set token values as custom properties on a root element, and the colour scheme. */
export function applyTheme(root, theme) {
    if (!root?.style)
        return;
    for (const [name, value] of Object.entries(theme.tokens)) {
        if (/^--[a-z0-9-]+$/.test(name))
            root.style.setProperty(name, value);
    }
    if (theme.scheme) {
        root.style.colorScheme = theme.scheme;
        root.dataset && (root.dataset.scheme = theme.scheme);
    }
}
export function applyLocale(root, locale) {
    if (!root?.setAttribute)
        return;
    root.setAttribute('lang', locale.locale);
    root.setAttribute('dir', locale.dir);
}
/**
 * Join the desktop that frames this page. Resolves once the shell has handed
 * over its ports; a message from a window that is not the parent, or from an
 * origin not listed, is ignored. A page that is not framed is refused at once
 * (`OS0402`); `connectTimeoutMs` and `signal` bound the wait, and a refused
 * or abandoned connection leaves no listener behind.
 */
export function connectToOs(options) {
    const host = options.host ?? globalThis;
    const presentation = options.presentation ?? 'root';
    const root = presentation === 'none' ? null : presentation === 'root' ? host.document?.documentElement : presentation.root;
    return new Promise((resolve, reject) => {
        if (!host.parent || host.parent === host) {
            reject(new OsConnectError('OS0402', 'this page is not framed by a desktop'));
            return;
        }
        if (options.signal?.aborted) {
            reject(new OsConnectError('OS0403', 'the connection was abandoned', { cause: options.signal.reason }));
            return;
        }
        let timer;
        const settle = () => { clearTimeout(timer); host.removeEventListener('message', listener); options.signal?.removeEventListener?.('abort', abandon); };
        const abandon = () => { settle(); reject(new OsConnectError('OS0403', 'the connection was abandoned', { cause: options.signal?.reason })); };
        const listener = (event) => {
            const data = event?.data;
            if (data?.type !== CONNECT || data.protocol !== PROTOCOL)
                return;
            if (event.source !== host.parent)
                return;
            if (options.origins !== 'parent' && !options.origins.includes(event.origin))
                return;
            settle();
            const ports = [...(event.ports ?? [])];
            const named = new Map(data.ports.map((name, index) => [name, ports[index]]));
            const { os, module } = systemContracts();
            const disposers = [];
            const moduleServer = servePort(module, {
                'module.theme': (theme) => { applyTheme(root, theme); options.onTheme?.(theme); return {}; },
                'module.locale': (locale) => { applyLocale(root, locale); options.onLocale?.(locale); return {}; },
                'module.context': () => (options.context?.() ?? {}),
            }, { channel: named.get('module') });
            disposers.push(() => moduleServer?.close?.());
            named.get('module')?.start?.();
            for (const served of options.serve ?? []) {
                const contract = compileContract(served.contract);
                const id = contract.doc?.id ?? served.contract.id;
                const port = named.get(id);
                if (!port)
                    continue;
                const server = servePort(contract, served.handlers, { channel: port });
                port.start?.();
                disposers.push(() => server?.close?.());
            }
            const osPort = named.get('os');
            const client = openPortClient(os, { channel: osPort, timeoutMs: options.timeoutMs ?? 30_000 });
            osPort?.start?.();
            // a press anywhere in this page raises its window on the desktop
            const raise = () => host.parent?.postMessage?.({ type: FOCUS }, '*');
            host.document?.addEventListener?.('pointerdown', raise, true);
            disposers.push(() => host.document?.removeEventListener?.('pointerdown', raise, true));
            applyTheme(root, data.theme);
            applyLocale(root, data.locale);
            options.onTheme?.(data.theme);
            options.onLocale?.(data.locale);
            resolve({
                module: data.module,
                connect: data,
                call: (contract, op, input = {}) => client.invoke('os.call', { contract, op, input }),
                sendMail: (envelope) => client.invoke('mail.send', envelope),
                setTitle: (title) => client.invoke('window.title', { title }),
                close() { for (const dispose of disposers)
                    dispose(); client.close?.(); for (const port of ports)
                    port.close?.(); },
            });
        };
        host.addEventListener('message', listener);
        options.signal?.addEventListener?.('abort', abandon, { once: true });
        if (options.connectTimeoutMs !== undefined)
            timer = setTimeout(() => { settle(); reject(new OsConnectError('OS0401', `no desktop answered within ${options.connectTimeoutMs} ms`)); }, options.connectTimeoutMs);
        // announce this page; the shell answers with the ports
        host.parent?.postMessage?.({ type: HELLO, protocol: PROTOCOL }, '*');
    });
}
