/**
 * The module manifest: one JSON document saying what a module is called, how
 * it is hosted (shipped component, sandboxed document, or an application on
 * its own origin), which contracts it serves and needs, its stylesheet and
 * its window. Validation is closed: an undeclared member is refused, so a key
 * or a script has nowhere to hide in a manifest.
 */
import { JarenValidator } from '@jarenjs/validate';
import { cloneJson, deepFreeze } from '@jarenjs/core/object';
import moduleSchema from '../schemas/module.schema.json' with { type: 'json' };
export { moduleSchema as MODULE_MANIFEST_SCHEMA };
const HOST_KINDS = ['shipped', 'document', 'origin'];
let validateShape = null;
function shape() {
    if (validateShape === null) {
        const validator = new JarenValidator({ skipErrors: false, collectErrors: true, unknownFormats: 'ignore' });
        validateShape = validator.compile(moduleSchema);
    }
    return validateShape;
}
/**
 * Validate a module manifest. Returns a frozen copy on success, so a caller
 * holding the input cannot change an installed module behind the kernel's
 * back; refusals carry a JSON pointer and a code (`OS0001` shape, `OS0002`
 * host kind, `OS0003` duplicate contract).
 */
export function validateManifest(value) {
    const issues = [];
    const host = value?.host;
    if (host !== null && typeof host === 'object' && !HOST_KINDS.includes(host.kind)) {
        issues.push({ code: 'OS0002', path: '/host/kind', message: `the host kind must be one of ${HOST_KINDS.join(', ')}` });
        return { ok: false, issues };
    }
    const outcome = shape()(value);
    if (!outcome.valid) {
        const seen = new Set();
        for (const error of outcome.errors ?? []) {
            const path = error.instancePath ?? '';
            const message = error.keyword === 'additionalProperties'
                ? `undeclared member '${error.params?.additionalProperty ?? ''}'`
                : error.message ?? 'does not match the module manifest schema';
            const key = `${path} ${message}`;
            if (!seen.has(key)) {
                seen.add(key);
                issues.push({ code: 'OS0001', path, message });
            }
        }
        return { ok: false, issues: issues.slice(0, 16) };
    }
    const ids = new Set();
    for (const [index, contract] of (value.provides ?? []).entries()) {
        if (ids.has(contract.id))
            issues.push({ code: 'OS0003', path: `/provides/${index}/id`, message: `the contract '${contract.id}' is provided twice` });
        ids.add(contract.id);
    }
    if (issues.length > 0)
        return { ok: false, issues };
    return { ok: true, manifest: deepFreeze(cloneJson(value)) };
}
/** The text for a locale, falling back to English. */
export function localized(text, locale) {
    if (text === undefined)
        return '';
    return text[locale] ?? text[locale.split('-')[0]] ?? text.en;
}
