/**
 * A proposal a module files for the person to accept or reject. Plain JSON,
 * bounded: the desktop shows it as text, links only to http(s) pages, and
 * never runs anything from it. The module keeps the proposal and decides what
 * accepting it does; `revision` is what it expects to still be true then.
 */
export declare const PROPOSAL_SCHEMA: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly required: readonly ["id", "kind", "title"];
    readonly properties: {
        readonly id: {
            readonly type: "string";
            readonly pattern: "^[A-Za-z0-9._:-]{1,128}$";
        };
        readonly kind: {
            readonly type: "string";
            readonly pattern: "^[a-z][a-z0-9.-]{0,63}$";
        };
        readonly title: {
            readonly type: "string";
            readonly minLength: 1;
            readonly maxLength: 200;
        };
        readonly summary: {
            readonly type: "string";
            readonly maxLength: 2000;
        };
        readonly payload: {};
        readonly evidence: {
            readonly type: "array";
            readonly maxItems: 12;
            readonly items: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["label"];
                readonly properties: {
                    readonly label: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 200;
                    };
                    readonly href: {
                        readonly type: "string";
                        readonly maxLength: 2000;
                        readonly pattern: "^https?://";
                    };
                };
            };
        };
        readonly revision: {
            readonly type: "string";
            readonly maxLength: 128;
        };
    };
};
/** What the desktop carries back to the module that filed a proposal. */
export declare const DECISION_SCHEMA: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly required: readonly ["id", "kind", "decision"];
    readonly properties: {
        readonly id: {
            readonly type: "string";
            readonly pattern: "^[A-Za-z0-9._:-]{1,128}$";
        };
        readonly kind: {
            readonly type: "string";
            readonly pattern: "^[a-z][a-z0-9.-]{0,63}$";
        };
        readonly decision: {
            readonly enum: readonly ["accept", "reject"];
        };
        readonly revision: {
            readonly type: "string";
            readonly maxLength: 128;
        };
        readonly payload: {};
    };
};
export declare const OS_CONTRACT: {
    readonly $contract: "0.1";
    readonly id: "tangle_os";
    readonly operations: {
        readonly 'os.call': {
            readonly kind: "command";
            readonly doc: "Call an operation another module serves. Refused unless this module was granted it.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["contract", "op"];
                readonly properties: {
                    readonly contract: {
                        readonly type: "string";
                        readonly pattern: "^[A-Za-z_][A-Za-z0-9_-]*$";
                    };
                    readonly op: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 128;
                    };
                    readonly input: {};
                };
            };
            readonly output: {};
        };
        readonly 'mail.send': {
            readonly kind: "command";
            readonly doc: "Send a message to the person, or to another module, through the desktop mail.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["subject"];
                readonly properties: {
                    readonly to: {
                        readonly type: "string";
                        readonly pattern: "^(person|[a-z][a-z0-9-]{0,63})$";
                    };
                    readonly subject: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 200;
                    };
                    readonly body: {
                        type: string;
                        maxLength: number;
                    };
                    readonly data: {};
                };
            };
            readonly output: {
                readonly type: "object";
                readonly required: readonly ["id"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                    };
                };
            };
        };
        readonly 'window.title': {
            readonly kind: "command";
            readonly doc: "Set the title of this module's window.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["title"];
                readonly properties: {
                    readonly title: {
                        readonly type: "string";
                        readonly maxLength: 200;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
            };
        };
        readonly 'window.header': {
            readonly kind: "command";
            readonly doc: "Set the header bar of this module's window: its buttons, toggles, menus, tabs and search field, drawn by the desktop. null takes it away.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["header"];
                readonly properties: {
                    readonly header: {
                        readonly anyOf: readonly [{
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly properties: {
                                readonly start: {
                                    readonly type: "array";
                                    readonly maxItems: 4;
                                    readonly items: {
                                        readonly anyOf: readonly [{
                                            type: string;
                                            additionalProperties: boolean;
                                            required: string[];
                                            properties: {
                                                primary: {
                                                    type: string;
                                                };
                                                shortcut: {
                                                    type: string;
                                                    minLength: number;
                                                    maxLength: number;
                                                };
                                                id: {
                                                    type: string;
                                                    pattern: string;
                                                };
                                                label: {
                                                    type: string;
                                                    minLength: number;
                                                    maxLength: number;
                                                };
                                                glyph: {
                                                    enum: string[];
                                                };
                                                disabled: {
                                                    type: string;
                                                };
                                                assistant: {
                                                    type: string;
                                                };
                                                kind: {
                                                    const: string;
                                                };
                                            };
                                        }, {
                                            type: string;
                                            additionalProperties: boolean;
                                            required: string[];
                                            properties: {
                                                pressed: {
                                                    type: string;
                                                };
                                                shortcut: {
                                                    type: string;
                                                    minLength: number;
                                                    maxLength: number;
                                                };
                                                id: {
                                                    type: string;
                                                    pattern: string;
                                                };
                                                label: {
                                                    type: string;
                                                    minLength: number;
                                                    maxLength: number;
                                                };
                                                glyph: {
                                                    enum: string[];
                                                };
                                                disabled: {
                                                    type: string;
                                                };
                                                assistant: {
                                                    type: string;
                                                };
                                                kind: {
                                                    const: string;
                                                };
                                            };
                                        }, {
                                            type: string;
                                            additionalProperties: boolean;
                                            required: string[];
                                            properties: {
                                                entries: {
                                                    type: string;
                                                    minItems: number;
                                                    maxItems: number;
                                                    items: {
                                                        anyOf: ({
                                                            type: string;
                                                            additionalProperties: boolean;
                                                            required: string[];
                                                            properties: {
                                                                separator: {
                                                                    const: boolean;
                                                                };
                                                                id?: undefined;
                                                                label?: undefined;
                                                                checked?: undefined;
                                                                disabled?: undefined;
                                                                shortcut?: undefined;
                                                                assistant?: undefined;
                                                            };
                                                        } | {
                                                            type: string;
                                                            additionalProperties: boolean;
                                                            required: string[];
                                                            properties: {
                                                                id: {
                                                                    type: string;
                                                                    pattern: string;
                                                                };
                                                                label: {
                                                                    type: string;
                                                                    minLength: number;
                                                                    maxLength: number;
                                                                };
                                                                checked: {
                                                                    type: string;
                                                                };
                                                                disabled: {
                                                                    type: string;
                                                                };
                                                                shortcut: {
                                                                    type: string;
                                                                    minLength: number;
                                                                    maxLength: number;
                                                                };
                                                                assistant: {
                                                                    type: string;
                                                                };
                                                                separator?: undefined;
                                                            };
                                                        })[];
                                                    };
                                                };
                                                id: {
                                                    type: string;
                                                    pattern: string;
                                                };
                                                label: {
                                                    type: string;
                                                    minLength: number;
                                                    maxLength: number;
                                                };
                                                glyph: {
                                                    enum: string[];
                                                };
                                                disabled: {
                                                    type: string;
                                                };
                                                assistant: {
                                                    type: string;
                                                };
                                                kind: {
                                                    const: string;
                                                };
                                            };
                                        }];
                                    };
                                };
                                readonly center: {
                                    readonly anyOf: readonly [{
                                        type: string;
                                        additionalProperties: boolean;
                                        required: string[];
                                        properties: {
                                            kind: {
                                                const: string;
                                            };
                                            id: {
                                                type: string;
                                                pattern: string;
                                            };
                                            label: {
                                                type: string;
                                                minLength: number;
                                                maxLength: number;
                                            };
                                            selected: {
                                                type: string;
                                                pattern: string;
                                            };
                                            assistant: {
                                                type: string;
                                            };
                                            items: {
                                                type: string;
                                                minItems: number;
                                                maxItems: number;
                                                items: {
                                                    type: string;
                                                    additionalProperties: boolean;
                                                    required: string[];
                                                    properties: {
                                                        id: {
                                                            type: string;
                                                            pattern: string;
                                                        };
                                                        label: {
                                                            type: string;
                                                            minLength: number;
                                                            maxLength: number;
                                                        };
                                                        glyph: {
                                                            enum: string[];
                                                        };
                                                        disabled: {
                                                            type: string;
                                                        };
                                                    };
                                                };
                                            };
                                        };
                                    }, {
                                        type: string;
                                        additionalProperties: boolean;
                                        required: string[];
                                        properties: {
                                            kind: {
                                                const: string;
                                            };
                                            id: {
                                                type: string;
                                                pattern: string;
                                            };
                                            label: {
                                                type: string;
                                                minLength: number;
                                                maxLength: number;
                                            };
                                            placeholder: {
                                                type: string;
                                                minLength: number;
                                                maxLength: number;
                                            };
                                            value: {
                                                type: string;
                                                maxLength: number;
                                            };
                                            disabled: {
                                                type: string;
                                            };
                                            assistant: {
                                                type: string;
                                            };
                                        };
                                    }];
                                };
                                readonly end: {
                                    readonly type: "array";
                                    readonly maxItems: 4;
                                    readonly items: {
                                        readonly anyOf: readonly [{
                                            type: string;
                                            additionalProperties: boolean;
                                            required: string[];
                                            properties: {
                                                primary: {
                                                    type: string;
                                                };
                                                shortcut: {
                                                    type: string;
                                                    minLength: number;
                                                    maxLength: number;
                                                };
                                                id: {
                                                    type: string;
                                                    pattern: string;
                                                };
                                                label: {
                                                    type: string;
                                                    minLength: number;
                                                    maxLength: number;
                                                };
                                                glyph: {
                                                    enum: string[];
                                                };
                                                disabled: {
                                                    type: string;
                                                };
                                                assistant: {
                                                    type: string;
                                                };
                                                kind: {
                                                    const: string;
                                                };
                                            };
                                        }, {
                                            type: string;
                                            additionalProperties: boolean;
                                            required: string[];
                                            properties: {
                                                pressed: {
                                                    type: string;
                                                };
                                                shortcut: {
                                                    type: string;
                                                    minLength: number;
                                                    maxLength: number;
                                                };
                                                id: {
                                                    type: string;
                                                    pattern: string;
                                                };
                                                label: {
                                                    type: string;
                                                    minLength: number;
                                                    maxLength: number;
                                                };
                                                glyph: {
                                                    enum: string[];
                                                };
                                                disabled: {
                                                    type: string;
                                                };
                                                assistant: {
                                                    type: string;
                                                };
                                                kind: {
                                                    const: string;
                                                };
                                            };
                                        }, {
                                            type: string;
                                            additionalProperties: boolean;
                                            required: string[];
                                            properties: {
                                                entries: {
                                                    type: string;
                                                    minItems: number;
                                                    maxItems: number;
                                                    items: {
                                                        anyOf: ({
                                                            type: string;
                                                            additionalProperties: boolean;
                                                            required: string[];
                                                            properties: {
                                                                separator: {
                                                                    const: boolean;
                                                                };
                                                                id?: undefined;
                                                                label?: undefined;
                                                                checked?: undefined;
                                                                disabled?: undefined;
                                                                shortcut?: undefined;
                                                                assistant?: undefined;
                                                            };
                                                        } | {
                                                            type: string;
                                                            additionalProperties: boolean;
                                                            required: string[];
                                                            properties: {
                                                                id: {
                                                                    type: string;
                                                                    pattern: string;
                                                                };
                                                                label: {
                                                                    type: string;
                                                                    minLength: number;
                                                                    maxLength: number;
                                                                };
                                                                checked: {
                                                                    type: string;
                                                                };
                                                                disabled: {
                                                                    type: string;
                                                                };
                                                                shortcut: {
                                                                    type: string;
                                                                    minLength: number;
                                                                    maxLength: number;
                                                                };
                                                                assistant: {
                                                                    type: string;
                                                                };
                                                                separator?: undefined;
                                                            };
                                                        })[];
                                                    };
                                                };
                                                id: {
                                                    type: string;
                                                    pattern: string;
                                                };
                                                label: {
                                                    type: string;
                                                    minLength: number;
                                                    maxLength: number;
                                                };
                                                glyph: {
                                                    enum: string[];
                                                };
                                                disabled: {
                                                    type: string;
                                                };
                                                assistant: {
                                                    type: string;
                                                };
                                                kind: {
                                                    const: string;
                                                };
                                            };
                                        }, {
                                            type: string;
                                            additionalProperties: boolean;
                                            required: string[];
                                            properties: {
                                                kind: {
                                                    const: string;
                                                };
                                                id: {
                                                    type: string;
                                                    pattern: string;
                                                };
                                                label: {
                                                    type: string;
                                                    minLength: number;
                                                    maxLength: number;
                                                };
                                                placeholder: {
                                                    type: string;
                                                    minLength: number;
                                                    maxLength: number;
                                                };
                                                value: {
                                                    type: string;
                                                    maxLength: number;
                                                };
                                                disabled: {
                                                    type: string;
                                                };
                                                assistant: {
                                                    type: string;
                                                };
                                            };
                                        }];
                                    };
                                };
                                readonly subtitle: {
                                    readonly type: "string";
                                    readonly maxLength: 120;
                                };
                            };
                        }, {
                            readonly type: "null";
                        }];
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly properties: {
                    readonly refused: {
                        readonly type: "object";
                        readonly required: readonly ["code", "message"];
                        readonly properties: {
                            readonly code: {
                                readonly type: "string";
                            };
                            readonly message: {
                                readonly type: "string";
                            };
                        };
                    };
                };
            };
        };
        readonly 'mail.propose': {
            readonly kind: "command";
            readonly doc: "File a proposal in the desktop's inbox for the person to accept or reject; filing the same id again replaces it.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["id", "kind", "title"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                        readonly pattern: "^[A-Za-z0-9._:-]{1,128}$";
                    };
                    readonly kind: {
                        readonly type: "string";
                        readonly pattern: "^[a-z][a-z0-9.-]{0,63}$";
                    };
                    readonly title: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 200;
                    };
                    readonly summary: {
                        readonly type: "string";
                        readonly maxLength: 2000;
                    };
                    readonly payload: {};
                    readonly evidence: {
                        readonly type: "array";
                        readonly maxItems: 12;
                        readonly items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["label"];
                            readonly properties: {
                                readonly label: {
                                    readonly type: "string";
                                    readonly minLength: 1;
                                    readonly maxLength: 200;
                                };
                                readonly href: {
                                    readonly type: "string";
                                    readonly maxLength: 2000;
                                    readonly pattern: "^https?://";
                                };
                            };
                        };
                    };
                    readonly revision: {
                        readonly type: "string";
                        readonly maxLength: 128;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly required: readonly ["id"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                    };
                };
            };
        };
        readonly 'mail.withdraw': {
            readonly kind: "command";
            readonly doc: "Take back one of this module's proposals that is still pending.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["id"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                        readonly pattern: "^[A-Za-z0-9._:-]{1,128}$";
                    };
                };
            };
            readonly output: {
                readonly type: "object";
            };
        };
        readonly 'settings.get': {
            readonly kind: "read";
            readonly doc: "This module's settings as the person set them in the desktop's Settings (a form module's values; empty for one that keeps its own).";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly properties: {};
            };
            readonly output: {
                readonly type: "object";
                readonly properties: {
                    readonly values: {};
                };
            };
        };
        readonly 'settings.open': {
            readonly kind: "command";
            readonly doc: "Open the desktop's Settings at this module's own section.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly properties: {};
            };
            readonly output: {
                readonly type: "object";
            };
        };
    };
};
export declare const MODULE_CONTRACT: {
    readonly $contract: "0.1";
    readonly id: "tangle_os_module";
    readonly operations: {
        readonly 'module.theme': {
            readonly kind: "command";
            readonly doc: "The desktop theme: token values to set on the module's root.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["tokens"];
                readonly properties: {
                    readonly tokens: {
                        readonly type: "object";
                        readonly additionalProperties: {
                            readonly type: "string";
                            readonly maxLength: 400;
                        };
                    };
                    readonly scheme: {
                        readonly enum: readonly ["light", "dark"];
                    };
                };
            };
            readonly output: {
                readonly type: "object";
            };
        };
        readonly 'module.locale': {
            readonly kind: "command";
            readonly doc: "The person's language and writing direction.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["locale", "dir"];
                readonly properties: {
                    readonly locale: {
                        readonly type: "string";
                        readonly maxLength: 16;
                    };
                    readonly dir: {
                        readonly enum: readonly ["ltr", "rtl"];
                    };
                };
            };
            readonly output: {
                readonly type: "object";
            };
        };
        readonly 'module.settings': {
            readonly kind: "command";
            readonly doc: "The module's settings changed in the desktop's Settings: its new values.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly properties: {
                    readonly values: {};
                };
            };
            readonly output: {
                readonly type: "object";
            };
        };
        readonly 'module.decide': {
            readonly kind: "command";
            readonly doc: "The person accepted or rejected one of the module's proposals. The module carries it out, or refuses with the reason (`refused`), for example when the revision moved.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["id", "kind", "decision"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                        readonly pattern: "^[A-Za-z0-9._:-]{1,128}$";
                    };
                    readonly kind: {
                        readonly type: "string";
                        readonly pattern: "^[a-z][a-z0-9.-]{0,63}$";
                    };
                    readonly decision: {
                        readonly enum: readonly ["accept", "reject"];
                    };
                    readonly revision: {
                        readonly type: "string";
                        readonly maxLength: 128;
                    };
                    readonly payload: {};
                };
            };
            readonly output: {
                readonly type: "object";
                readonly properties: {
                    readonly refused: {
                        readonly type: "string";
                        readonly maxLength: 400;
                    };
                };
            };
        };
        readonly 'module.header': {
            readonly kind: "command";
            readonly doc: "An item of the window's header bar was used: by the person (`by: person`) or by a caller the desktop granted it (`assistant`, a module id). Carry it out, or refuse with the reason.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["item", "by"];
                readonly properties: {
                    readonly item: {
                        readonly type: "string";
                        readonly maxLength: 64;
                    };
                    readonly value: {
                        readonly anyOf: readonly [{
                            readonly type: "string";
                            readonly maxLength: 200;
                        }, {
                            readonly type: "boolean";
                        }];
                    };
                    readonly by: {
                        readonly type: "string";
                        readonly maxLength: 64;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly properties: {
                    readonly refused: {
                        readonly type: "string";
                        readonly maxLength: 400;
                    };
                };
            };
        };
        readonly 'module.context': {
            readonly kind: "read";
            readonly doc: "A compact description of what the module shows now, for the assistant.";
            readonly input: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly properties: {};
            };
            readonly output: {
                readonly type: "object";
            };
        };
    };
};
/** Compiled once on first use, so importing the package compiles nothing. */
export declare function systemContracts(): {
    os: any;
    module: any;
};
/** The message a host posts with the ports, and the module side checks. */
export declare const CONNECT = "tangle-os.connect";
/** What a framed page posts to its parent when it is ready for the ports. */
export declare const HELLO = "tangle-os.hello";
/** A pointer pressed inside a frame: raise its window. */
export declare const FOCUS = "tangle-os.focus";
/** A desktop shortcut pressed inside a frame. */
export declare const KEY = "tangle-os.key";
export declare const PROTOCOL = 1;
export type ConnectMessage = {
    type: typeof CONNECT;
    protocol: typeof PROTOCOL;
    module: string;
    /** Names of the transferred ports, in transfer order: `os`, `module`, then one per provided contract id. */
    ports: string[];
    theme: {
        tokens: Record<string, string>;
        scheme: 'light' | 'dark';
    };
    locale: {
        locale: string;
        dir: 'ltr' | 'rtl';
    };
    /** Only for a document module: what the module host boots. */
    document?: {
        app: Record<string, unknown>;
        styles?: string;
        provides?: unknown[];
    };
};
