import { type ConnectMessage } from './contracts.ts';
import type { Header, HeaderActivation } from './header.ts';
export type ModuleHandlers = Record<string, (input: any) => unknown>;
export type ConnectOptions = {
    /** Contract documents this page serves, by contract id, with their handlers. */
    serve?: {
        contract: unknown;
        handlers: ModuleHandlers;
    }[];
    /** Origins of desktops allowed to frame this page: exact origins, or `'parent'` to accept the framing window whatever its origin (the sandboxed module host). */
    origins: string[] | 'parent';
    /** Called with token values after they are applied to the document root. */
    onTheme?: (theme: {
        tokens: Record<string, string>;
        scheme?: 'light' | 'dark';
    }) => void;
    onLocale?: (locale: {
        locale: string;
        dir: 'ltr' | 'rtl';
    }) => void;
    /** Called when the person changes this module's settings in the desktop's Settings (a `form` module's values). */
    onSettings?: (values: unknown) => void;
    /**
     * The person accepted or rejected one of this module's proposals. Carry it
     * out, or return `{ refused: reason }` (the revision moved, say) and the
     * proposal stays pending with that reason. A module with no handler refuses.
     */
    onDecision?: (decision: {
        id: string;
        kind: string;
        decision: 'accept' | 'reject';
        revision?: string;
        payload?: unknown;
    }) => {
        refused?: string;
    } | void | Promise<{
        refused?: string;
    } | void>;
    /**
     * An item of this page's header bar was used, by the person (`by: 'person'`)
     * or by a caller the desktop granted it (`'assistant'`, a module id). Carry
     * it out, or return `{ refused: reason }`. Without a handler every
     * activation is refused.
     */
    onHeader?: (activation: HeaderActivation) => {
        refused?: string;
    } | void | Promise<{
        refused?: string;
    } | void>;
    /** A compact description of what the page shows now, for the assistant. */
    context?: () => unknown;
    /** The window that sends the ports; the page's parent by default. */
    host?: {
        parent: any;
        addEventListener: (type: string, listener: (event: any) => void) => void;
        removeEventListener: (type: string, listener: (event: any) => void) => void;
        document?: any;
    };
    /** How long a call to the desktop may take once connected (30 s by default). */
    timeoutMs?: number;
    /**
     * How long to wait for a desktop to answer the page's hello. Without it the
     * page waits as long as it is framed; past it the connection is refused
     * with `OS0401` and the page stops listening.
     */
    connectTimeoutMs?: number;
    /** Abandons a connection not yet made: refused with the signal's reason, the page stops listening. */
    signal?: AbortSignal;
    /**
     * Where the desktop's theme and language land: the page's root (`'root'`,
     * the default), an element of the page's own (`{ root }`), or nowhere
     * (`'none'`: an application that keeps its own look, and still hears
     * `onTheme` and `onLocale`).
     */
    presentation?: 'root' | 'none' | {
        root: any;
    };
};
/** A refused connection: `OS0401` no desktop answered in time, `OS0402` the page is not framed, `OS0403` abandoned. */
export declare class OsConnectError extends Error {
    readonly code: 'OS0401' | 'OS0402' | 'OS0403';
    constructor(code: 'OS0401' | 'OS0402' | 'OS0403', message: string, options?: {
        cause?: unknown;
    });
}
export type OsConnection = {
    module: string;
    connect: ConnectMessage;
    call(contract: string, op: string, input?: unknown): Promise<any>;
    sendMail(envelope: {
        to?: string;
        subject: string;
        body?: string;
        data?: unknown;
    }): Promise<any>;
    setTitle(title: string): Promise<any>;
    /**
     * Put buttons, toggles, menus, tabs and a search field in this window's
     * title bar, drawn by the desktop (`null` takes them away). Set it again
     * whenever its state changes in the page; uses arrive at `onHeader`.
     */
    setHeader(header: Header | null): Promise<void>;
    /** This module's settings as the person set them in the desktop's Settings (a `form` module's values). */
    settings(): Promise<unknown>;
    /** Open the desktop's Settings at this module's own section: the one place the person finds every application's settings. */
    openSettings(): Promise<void>;
    /** File a proposal in the desktop's inbox (filing the same id again replaces it); the module keeps it and refiles after a reload. */
    propose(proposal: {
        id: string;
        kind: string;
        title: string;
        summary?: string;
        payload?: unknown;
        evidence?: {
            label: string;
            href?: string;
        }[];
        revision?: string;
    }): Promise<void>;
    /** Take back a pending proposal. */
    withdraw(id: string): Promise<void>;
    close(): void;
};
/** Set token values as custom properties on a root element, and the colour scheme. */
export declare function applyTheme(root: any, theme: {
    tokens: Record<string, string>;
    scheme?: 'light' | 'dark';
}): void;
export declare function applyLocale(root: any, locale: {
    locale: string;
    dir: 'ltr' | 'rtl';
}): void;
/**
 * Join the desktop that frames this page. Resolves once the shell has handed
 * over its ports; a message from a window that is not the parent, or from an
 * origin not listed, is ignored. A page that is not framed is refused at once
 * (`OS0402`); `connectTimeoutMs` and `signal` bound the wait, and a refused
 * or abandoned connection leaves no listener behind.
 */
export declare function connectToOs(options: ConnectOptions): Promise<OsConnection>;
