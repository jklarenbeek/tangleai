import { type ModuleManifest } from './manifest.ts';
import { type ThemeDocument } from './theme.ts';
import { type OsCatalogue } from './messages.ts';
import { type Desktop, type WindowState } from './windows.ts';
import type { Kernel, Decider } from './kernel.ts';
import { type Header, type HeaderHandler } from './header.ts';
export type ShippedContext = {
    module: ModuleManifest;
    window: string;
    call(contract: string, op: string, input?: unknown): ReturnType<Kernel['call']>;
    sendMail(envelope: {
        to?: string;
        subject: string;
        body?: string;
        data?: unknown;
    }): void;
    setTitle(title: string): void;
    provide(contract: unknown, handlers: Record<string, (input: any) => unknown>): void;
    locale: string;
    dir: 'ltr' | 'rtl';
    /** Whether the window is on screen: not minimized, and on a compact desktop the focused one. */
    readonly visible: boolean;
    /** Called when the window is hidden or shown again, so a module can pause what only matters on screen. */
    onVisibility(listener: (visible: boolean) => void): () => void;
    /** The desktop's theme now: tokens and scheme. */
    readonly theme: {
        tokens: Record<string, string>;
        scheme?: 'light' | 'dark';
    };
    /** Open the desktop's Settings at this module's own section. */
    openSettings(): void;
    /** File a proposal in the desktop's inbox (the same id again replaces it). */
    propose(proposal: {
        id: string;
        kind: string;
        title: string;
        summary?: string;
        payload?: unknown;
        evidence?: {
            label: string;
            href?: string;
        }[];
        revision?: string;
    }): ReturnType<Kernel['propose']>;
    /** Take back a pending proposal. */
    withdraw(id: string): ReturnType<Kernel['withdrawProposal']>;
    /** Where the person's decisions on this module's proposals arrive while its window is open; return `{ refused }` to keep one pending. */
    onDecision(handler: Decider): () => void;
    /** Put buttons, toggles, menus, tabs and a search field in the window's title bar (`null` takes them away); refused with `OS0113` when it does not match the header schema. */
    setHeader(header: Header | null): void;
    /** Where uses of the header bar arrive (by the person or a granted caller); return `{ refused }` to say it was not done. */
    onHeader(handler: HeaderHandler): () => void;
};
/**
 * What happened to a window, with its state after it: a host that subscribes
 * before the first `open` can rebuild `state().windows` and `focus` from these
 * alone. `restored` is a window leaving minimized or maximized.
 */
export type DesktopEvent = {
    type: 'opened' | 'closed' | 'focused' | 'minimized' | 'restored' | 'maximized' | 'moved' | 'resized' | 'retitled'
    /** The module is running in it (a framed one has connected, again after it reloads); `failed`: it could not start, or did not answer in time. */
     | 'ready' | 'failed';
    window: string;
    module: string;
    state: WindowState;
};
/** A shipped component: mounts into a window's content node and returns its disposer. */
export type ShippedMount = (node: HTMLElement, context: ShippedContext) => (() => void) | void;
export type DesktopOptions = {
    kernel: Kernel;
    shipped?: Record<string, ShippedMount>;
    /** URL of the page that loads the document module host as a classic script. */
    documentHost?: string;
    theme?: ThemeDocument;
    /**
     * The theme the dock's light/dark switch moves to; defaults to the built-in
     * pair. A host with a person's own colours returns their variant here.
     */
    themeFor?: (scheme: 'light' | 'dark') => ThemeDocument;
    /** Called after the person switches between light and dark from the dock or a menu. */
    onSchemeSwitch?: (scheme: 'light' | 'dark') => void;
    locale?: string;
    dir?: 'ltr' | 'rtl';
    messages?: Partial<OsCatalogue>;
    /**
     * A desktop narrower than `below` pixels is compact (a phone): every
     * window opens maximized and only the focused one is shown. The dock never
     * leaves the desktop at any width: its tiles shrink to fit, then it scrolls.
     */
    compact?: {
        below: number;
    };
    /**
     * What the dock carries after the modules: the mail tile and the light/dark
     * switch (both by default), and a brand mark at its start, which is not a
     * module and takes no keyboard stop.
     */
    tray?: {
        mail?: boolean;
        theme?: boolean;
        brand?: {
            label: string;
            src?: string;
            node?: HTMLElement;
        };
    };
    /**
     * How long a framed module has to say hello (15 s by default). Past it the
     * window says so and offers to try again, and the shell holds nothing open
     * for it; a module that answers later still connects.
     */
    connectTimeoutMs?: number;
    /** The module that is the desktop's Settings (`settings` by default, as `@tangleai/os/settings` installs it). */
    settings?: string;
    /** Defaults to the node's owner window. */
    window?: Window;
    onError?: (error: unknown) => void;
};
/**
 * Why an application page may not be framed as an origin module, or null.
 * A page on the desktop's own origin would be framed with that origin's
 * rights and could read the desktop's storage and keys (all project sites of
 * one GitHub Pages account share an origin), so it is refused.
 */
export declare function originHostProblem(url: string, desktopOrigin: string | undefined): string | null;
export declare function mountDesktop(node: HTMLElement, options: DesktopOptions): {
    open: (moduleId: string) => string | null;
    close: (id: string) => void;
    focus: (id: string) => void;
    minimize: (id: string) => void;
    maximize: (id: string) => void;
    move: (id: string, x: number, y: number) => void;
    state: () => Desktop;
    /** Open the desktop's Settings, at a module's own section when one is named. */
    openSettings: (moduleId?: string) => void;
    /** Every window change, as it happens; returns the unsubscribe. */
    subscribe(listener: (event: DesktopEvent) => void): () => void;
    setTheme: (next: ThemeDocument) => void;
    setLocale: (next: {
        locale: string;
        dir: "ltr" | "rtl";
    }) => void;
    theme: () => ThemeDocument;
    /** The framed module's own context row, for the assistant. */
    context: (id: string) => any;
    dispose(): void;
};
export type DesktopHandle = ReturnType<typeof mountDesktop>;
