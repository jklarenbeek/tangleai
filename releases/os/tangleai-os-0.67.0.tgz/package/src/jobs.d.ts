/** The states a job passes through (Jaren JOBS-FORMAT §2, §10). */
export type JobState = 'pending' | 'leased' | 'done' | 'failed' | 'dead' | 'cancelled';
/** One job as the desktop sees it: no payload, no result, no lease internals. */
export type JobItem = {
    id: string;
    kind: string;
    state: JobState;
    runAt: number;
    attempts: number;
    maxAttempts: number;
    leaseUntil: number | null;
    lastError: {
        message: string;
        code?: string;
    } | null;
    createdAt: number;
    updatedAt: number;
};
/** How many jobs are in each state; `pendingKinds` counts the waiting ones by kind. */
export type JobCounts = Record<JobState, number> & {
    pendingKinds: Record<string, number>;
};
/** A recurring schedule (Jaren JOBS-FORMAT §11): its rule as the document Jaren stored, and where it stands. */
export type JobSchedule = {
    id: string;
    kind: string;
    series: Record<string, unknown>;
    zone: string | null;
    policy: string | null;
    missed: 'skip' | 'once' | {
        catchUp: number;
    };
    latenessMs: number | null;
    state: 'active' | 'unresolved' | 'stalled' | 'ended';
    nextRunAt: number | null;
    nextRecurrenceId: string | null;
    lastRunAt: number | null;
    lastRecurrenceId: string | null;
    counts: {
        fired: number;
        skipped: number;
        uncounted?: number;
    };
    stall: Record<string, unknown> | null;
    createdAt: number;
    updatedAt: number;
};
type Scoped = {
    scope?: string;
};
/** What a host's job queue does: the desktop's Jobs app and the assistant's contract call it. */
export type JobQueue = {
    counts(input?: Scoped): Promise<JobCounts>;
    page(input?: Scoped & {
        state?: JobState;
        kind?: string;
        after?: string;
        limit?: number;
    }): Promise<{
        items: JobItem[];
        next?: string;
    }>;
    get(input: Scoped & {
        id: string;
    }): Promise<JobItem>;
    schedules(input?: Scoped): Promise<{
        schedules: JobSchedule[];
    }>;
    cancel(input: Scoped & {
        id: string;
    }): Promise<{
        changed: boolean;
    }>;
    requeue(input: Scoped & {
        id: string;
    }): Promise<{
        changed: boolean;
    }>;
    unschedule(input: Scoped & {
        id: string;
    }): Promise<{
        changed: boolean;
    }>;
};
/**
 * Refusals, each a coded error: `OS0190` no job host is configured; `OS0191`
 * no such job or schedule; `OS0192` its state forbids the call (a done job, a
 * live lease on requeue); `OS0193` a claimed job whose lease this host does not
 * hold (another process runs it); `OS0194` a scope this host does not serve.
 */
export declare const JOB_CODES: {
    readonly unconfigured: "OS0190";
    readonly unknown: "OS0191";
    readonly refused: "OS0192";
    readonly held: "OS0193";
    readonly scope: "OS0194";
};
export declare const JOB_ITEM_SCHEMA: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly required: readonly ["id", "kind", "state", "runAt", "attempts", "maxAttempts", "leaseUntil", "lastError", "createdAt", "updatedAt"];
    readonly properties: {
        readonly id: {
            readonly type: "string";
            readonly minLength: 1;
            readonly maxLength: 512;
        };
        readonly kind: {
            readonly type: "string";
            readonly maxLength: 200;
        };
        readonly state: {
            readonly enum: readonly ["pending", "leased", "done", "failed", "dead", "cancelled"];
        };
        readonly runAt: {
            readonly type: "number";
        };
        readonly attempts: {
            readonly type: "integer";
            readonly minimum: 0;
        };
        readonly maxAttempts: {
            readonly type: "integer";
            readonly minimum: 0;
        };
        readonly leaseUntil: {
            readonly type: readonly ["number", "null"];
        };
        readonly lastError: {
            readonly oneOf: readonly [{
                readonly type: "null";
            }, {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["message"];
                readonly properties: {
                    readonly message: {
                        readonly type: "string";
                        readonly maxLength: 2000;
                    };
                    readonly code: {
                        readonly type: "string";
                        readonly maxLength: 40;
                    };
                };
            }];
        };
        readonly createdAt: {
            readonly type: "number";
        };
        readonly updatedAt: {
            readonly type: "number";
        };
    };
};
/** The provider contract a host serves (over HTTP from its server, or in a worker). */
export declare const JOB_QUEUE_CONTRACT: {
    readonly $contract: "0.1";
    readonly id: "job_queue";
    readonly operations: {
        readonly 'jobs.counts': {
            readonly kind: "read";
            readonly doc: "How many jobs are in each state, and how many wait per kind.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["pending", "leased", "done", "failed", "dead", "cancelled", "pendingKinds"];
                readonly properties: {
                    readonly pending: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly leased: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly done: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly failed: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly dead: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly cancelled: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly pendingKinds: {
                        readonly type: "object";
                        readonly additionalProperties: {
                            readonly type: "integer";
                            readonly minimum: 0;
                        };
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
            };
        };
        readonly 'jobs.page': {
            readonly kind: "read";
            readonly doc: "A page of jobs by id, filtered by state and kind; `next` continues after the last one.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["items"];
                readonly properties: {
                    readonly items: {
                        readonly type: "array";
                        readonly maxItems: 200;
                        readonly items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["id", "kind", "state", "runAt", "attempts", "maxAttempts", "leaseUntil", "lastError", "createdAt", "updatedAt"];
                            readonly properties: {
                                readonly id: {
                                    readonly type: "string";
                                    readonly minLength: 1;
                                    readonly maxLength: 512;
                                };
                                readonly kind: {
                                    readonly type: "string";
                                    readonly maxLength: 200;
                                };
                                readonly state: {
                                    readonly enum: readonly ["pending", "leased", "done", "failed", "dead", "cancelled"];
                                };
                                readonly runAt: {
                                    readonly type: "number";
                                };
                                readonly attempts: {
                                    readonly type: "integer";
                                    readonly minimum: 0;
                                };
                                readonly maxAttempts: {
                                    readonly type: "integer";
                                    readonly minimum: 0;
                                };
                                readonly leaseUntil: {
                                    readonly type: readonly ["number", "null"];
                                };
                                readonly lastError: {
                                    readonly oneOf: readonly [{
                                        readonly type: "null";
                                    }, {
                                        readonly type: "object";
                                        readonly additionalProperties: false;
                                        readonly required: readonly ["message"];
                                        readonly properties: {
                                            readonly message: {
                                                readonly type: "string";
                                                readonly maxLength: 2000;
                                            };
                                            readonly code: {
                                                readonly type: "string";
                                                readonly maxLength: 40;
                                            };
                                        };
                                    }];
                                };
                                readonly createdAt: {
                                    readonly type: "number";
                                };
                                readonly updatedAt: {
                                    readonly type: "number";
                                };
                            };
                        };
                    };
                    readonly next: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 512;
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
            };
        };
        readonly 'jobs.get': {
            readonly kind: "read";
            readonly doc: "One job: its kind, state, attempts, instants and last error.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["id", "kind", "state", "runAt", "attempts", "maxAttempts", "leaseUntil", "lastError", "createdAt", "updatedAt"];
                readonly properties: {
                    readonly id: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 512;
                    };
                    readonly kind: {
                        readonly type: "string";
                        readonly maxLength: 200;
                    };
                    readonly state: {
                        readonly enum: readonly ["pending", "leased", "done", "failed", "dead", "cancelled"];
                    };
                    readonly runAt: {
                        readonly type: "number";
                    };
                    readonly attempts: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly maxAttempts: {
                        readonly type: "integer";
                        readonly minimum: 0;
                    };
                    readonly leaseUntil: {
                        readonly type: readonly ["number", "null"];
                    };
                    readonly lastError: {
                        readonly oneOf: readonly [{
                            readonly type: "null";
                        }, {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["message"];
                            readonly properties: {
                                readonly message: {
                                    readonly type: "string";
                                    readonly maxLength: 2000;
                                };
                                readonly code: {
                                    readonly type: "string";
                                    readonly maxLength: 40;
                                };
                            };
                        }];
                    };
                    readonly createdAt: {
                        readonly type: "number";
                    };
                    readonly updatedAt: {
                        readonly type: "number";
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
            };
        };
        readonly 'jobs.schedules': {
            readonly kind: "read";
            readonly doc: "Every recurring schedule: its rule, zone, state, next and last run, and how many it fired and skipped.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["schedules"];
                readonly properties: {
                    readonly schedules: {
                        readonly type: "array";
                        readonly maxItems: 1000;
                        readonly items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["id", "kind", "series", "zone", "policy", "missed", "latenessMs", "state", "nextRunAt", "nextRecurrenceId", "lastRunAt", "lastRecurrenceId", "counts", "stall", "createdAt", "updatedAt"];
                            readonly properties: {
                                readonly id: {
                                    readonly type: "string";
                                    readonly minLength: 1;
                                    readonly maxLength: 512;
                                };
                                readonly kind: {
                                    readonly type: "string";
                                    readonly maxLength: 200;
                                };
                                readonly series: {
                                    readonly type: "object";
                                };
                                readonly zone: {
                                    readonly type: readonly ["string", "null"];
                                    readonly maxLength: 200;
                                };
                                readonly policy: {
                                    readonly type: readonly ["string", "null"];
                                    readonly maxLength: 200;
                                };
                                readonly missed: {
                                    readonly oneOf: readonly [{
                                        readonly enum: readonly ["skip", "once"];
                                    }, {
                                        readonly type: "object";
                                        readonly additionalProperties: false;
                                        readonly required: readonly ["catchUp"];
                                        readonly properties: {
                                            readonly catchUp: {
                                                readonly type: "integer";
                                                readonly minimum: 0;
                                            };
                                        };
                                    }];
                                };
                                readonly latenessMs: {
                                    readonly type: readonly ["number", "null"];
                                };
                                readonly state: {
                                    readonly enum: readonly ["active", "unresolved", "stalled", "ended"];
                                };
                                readonly nextRunAt: {
                                    readonly type: readonly ["number", "null"];
                                };
                                readonly nextRecurrenceId: {
                                    readonly type: readonly ["string", "null"];
                                    readonly maxLength: 200;
                                };
                                readonly lastRunAt: {
                                    readonly type: readonly ["number", "null"];
                                };
                                readonly lastRecurrenceId: {
                                    readonly type: readonly ["string", "null"];
                                    readonly maxLength: 200;
                                };
                                readonly counts: {
                                    readonly type: "object";
                                    readonly additionalProperties: false;
                                    readonly required: readonly ["fired", "skipped"];
                                    readonly properties: {
                                        readonly fired: {
                                            readonly type: "integer";
                                            readonly minimum: 0;
                                        };
                                        readonly skipped: {
                                            readonly type: "integer";
                                            readonly minimum: 0;
                                        };
                                        readonly uncounted: {
                                            readonly type: "integer";
                                            readonly minimum: 0;
                                        };
                                    };
                                };
                                readonly stall: {
                                    readonly type: readonly ["object", "null"];
                                };
                                readonly createdAt: {
                                    readonly type: "number";
                                };
                                readonly updatedAt: {
                                    readonly type: "number";
                                };
                            };
                        };
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
            };
        };
        readonly 'jobs.cancel': {
            readonly kind: "command";
            readonly doc: "Cancel a waiting job, or a running one this host holds the lease of.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["changed"];
                readonly properties: {
                    readonly changed: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
            };
        };
        readonly 'jobs.requeue': {
            readonly kind: "command";
            readonly doc: "Return a failed, dead or cancelled job to the queue; its attempts are kept.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["changed"];
                readonly properties: {
                    readonly changed: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
            };
        };
        readonly 'jobs.unschedule': {
            readonly kind: "command";
            readonly doc: "Remove a recurring schedule; the jobs it fired stay.";
            readonly input: {
                type: string;
                additionalProperties: boolean;
                required: string[];
                properties: {
                    scope: {
                        readonly type: "string";
                        readonly minLength: 1;
                        readonly maxLength: 120;
                    };
                };
            };
            readonly output: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["changed"];
                readonly properties: {
                    readonly changed: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly errors: {
                readonly unknown: {
                    readonly status: 404;
                };
                readonly refused: {
                    readonly status: 409;
                };
                readonly held: {
                    readonly status: 423;
                };
                readonly scope: {
                    readonly status: 400;
                };
            };
        };
    };
};
/** A queue that answers `OS0190` for everything: a desktop with no job host. */
export declare const unconfiguredJobQueue: () => JobQueue;
/**
 * The queue a host serves at `baseUrl` (for example `http://127.0.0.1:4700/api/job-queue`). Its declared
 * answers become the codes above; a host that cannot be reached, or answers outside the contract, is
 * `OS0190` marked `unanswered: true`.
 */
export declare function httpJobQueue(baseUrl: string, options?: {
    fetch?: typeof globalThis.fetch;
    timeoutMs?: number;
}): JobQueue;
export {};
