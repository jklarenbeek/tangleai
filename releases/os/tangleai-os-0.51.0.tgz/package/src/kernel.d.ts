import { type ModuleManifest, type ManifestIssue } from './manifest.ts';
export type Layer = 'shipped' | 'suite' | 'user';
export type JournalEntry = {
    seq: number;
    at: number;
    layer: Layer;
    module: string;
    kind: 'install' | 'patch' | 'remove';
    patch?: unknown[];
    inverse?: unknown[];
};
export type LedgerEntry = {
    seq: number;
    at: number;
    caller: string;
    contract: string;
    op: string;
    ok: boolean;
    code?: string;
    ms: number;
};
export type MailEnvelope = {
    id: string;
    at: number;
    from: string;
    to: string;
    subject: string;
    body?: string;
    data?: unknown;
    read: boolean;
};
export type Outcome = {
    ok: true;
    value: unknown;
} | {
    ok: false;
    error: {
        code: string;
        message: string;
    };
};
export type KernelEvent = {
    kind: 'modules' | 'mail' | 'ledger' | 'providers' | 'title' | 'settings';
    module?: string;
    title?: string;
};
/**
 * Where the desktop keeps the values of a `form` module's settings (a module
 * with no server of its own). A host passes its own storage; the default keeps
 * them for the page's lifetime. Never secrets: a form refuses them.
 */
export type SettingsStore = {
    read(module: string): unknown;
    write(module: string, values: unknown): void;
};
/** Any contract client: an object with `invoke`, as every Jaren binding returns. */
export type ContractClient = {
    invoke: (op: string, input: unknown, ctx?: unknown) => Promise<any>;
    close?: () => void;
};
/** A served contract: what `servePort` returns. */
export type ServedContract = {
    close?: () => void;
};
type Provider = {
    module: string;
    owner: string;
    contract: any;
    client: ContractClient;
};
/** One operation a caller may call, as plain data: what any agent stack needs to offer it as a tool. */
export type GrantedOperation = {
    tool: string;
    contract: string;
    op: string;
    kind: string;
    doc?: string;
    input?: unknown;
    output?: unknown;
};
/**
 * The host's tool builder, so the kernel names no agent runtime: Tangle's
 * `@tangleai/agents/toolbox` fits as it is (`createKernel({ tools: toolbox })`).
 */
export type ToolBuilder = {
    createToolbox: () => any;
    toolboxFromContract: (contract: any, client: {
        invoke: (op: string, input: unknown) => Promise<unknown>;
    }, options: {
        toolbox: any;
        ops: string[];
        name: (op: string) => string;
    }) => unknown;
};
/** A tool's name: `<contract>__<operation>` with every character outside [A-Za-z0-9_-] as `_`, at most 64. */
export declare const toolName: (contract: string, op: string) => string;
/**
 * `assistantGrants`: what the assistant may call — `'all'`, or scopes
 * (`contract.op`, `contract.*`). Nothing by default: a host decides.
 */
export declare function createKernel(options?: {
    recovery?: boolean;
    now?: () => number;
    assistantGrants?: 'all' | string[];
    tools?: ToolBuilder;
    settings?: SettingsStore;
}): {
    recovery: boolean;
    /**
     * Install a whole module in a layer. A shipped or suite module is granted
     * what it declares it requires, unless `grant: false`: a suite joined
     * from a link is installed without grants, so a link cannot hand a
     * module access. A contract another module already declares is refused.
     */
    install(value: unknown, layer?: Layer, install?: {
        grant?: boolean;
    }): {
        ok: true;
        manifest: ModuleManifest;
    } | {
        ok: false;
        issues: ManifestIssue[];
    };
    /**
     * Change an installed module with an RFC 6902 patch in a layer above its
     * own. The shipped document is never written; the result must still be a
     * valid manifest, or the patch is refused and nothing changes.
     */
    patch(id: string, patch: unknown[], layer?: Layer): Outcome;
    /** Remove a module a person installed. Shipped and suite modules are not removable, only hidden by a patch. */
    remove(id: string): Outcome;
    /** Undo the person's last change. */
    undo(): Outcome;
    effective(id: string): ModuleManifest | null;
    modules(): ModuleManifest[];
    layerOf(id: string): Layer | null;
    journal(): JournalEntry[];
    grant(caller: string, scope: string): void;
    revoke(caller: string, scope: string): void;
    grants(): Record<string, string[]>;
    /** A `form` module's settings as the person set them (`{}` until they do); `{}` for a module that keeps its own. */
    settings(module: string): unknown;
    /**
     * The person sets a `form` module's settings in the desktop's Settings:
     * checked against the module's schema, kept, and reported (`settings`).
     * Refused for a module that keeps its own (`OS0105`) or values its schema
     * refuses (`OS0106`).
     */
    setSettings(module: string, values: unknown): Outcome;
    allowed(caller: string, contract: string, op: string): boolean;
    /**
     * Make a contract callable: the client reaches the module that serves it.
     * Only the module whose manifest declares the contract may serve it
     * (`OS0011` otherwise), so one module cannot take over another's.
     */
    provide(module: string, contractDoc: unknown, client: Provider["client"], owner?: string): void;
    /** A shipped module serves a contract from inside the page. */
    provideLocal(module: string, contractDoc: unknown, handlers: Record<string, (input: any) => unknown>, owner?: string): void;
    /** Withdraw what one owner (a window) registered; another window of the same module keeps serving. */
    withdraw(module: string, owner?: string): void;
    providers(): {
        contract: string;
        module: string;
        operations: string[];
    }[];
    /** The bus: one operation of one contract, for one caller, under grants, into the ledger. */
    call(caller: string, contract: string, op: string, input?: unknown): Promise<Outcome>;
    ledger(): LedgerEntry[];
    sendMail(from: string, envelope: {
        to?: string;
        subject: string;
        body?: string;
        data?: unknown;
    }): MailEnvelope;
    mail(): MailEnvelope[];
    markRead(id: string): void;
    /**
     * Serve `tangle_os` to one module over its own port. The module's id is
     * bound here, by the port it was handed, never taken from its input.
     */
    serveModule(module: string, port: any, hooks?: {
        setTitle?: (title: string) => void;
        openSettings?: () => void;
    }): ServedContract;
    /** Open a client on a port where a module serves one of its contracts, and make it callable. */
    connectProvider(module: string, contractDoc: unknown, port: any, timeoutMs?: number, owner?: string): ContractClient;
    /**
     * Every served operation `caller` may call, as plain data (tool name,
     * contract, operation, kind, description, input and output schemas): an
     * application with its own agent runtime offers these as tools and calls
     * back through `call`, so grants and the ledger still apply.
     */
    operations(caller?: string): GrantedOperation[];
    /**
     * The assistant's tools: every served contract the assistant may call, as
     * model tools built by the host's tool builder, each routed through `call`
     * so grants and the ledger apply. Names are {@link toolName}.
     */
    tools(caller?: string): any;
    subscribe(listener: (event: KernelEvent) => void): () => boolean;
};
export type Kernel = ReturnType<typeof createKernel>;
export {};
