import moduleSchema from '../schemas/module.schema.json' with { type: "json" };
export { moduleSchema as MODULE_MANIFEST_SCHEMA };
export type LocalizedText = {
    en: string;
} & Partial<Record<'ar' | 'de' | 'es' | 'fr' | 'ja' | 'ko' | 'nl' | 'pt' | 'ru' | 'tr' | 'zh-TW', string>>;
export type ModuleHost = {
    kind: 'shipped';
    mount: string;
} | {
    kind: 'document';
    app: Record<string, unknown>;
} | {
    kind: 'origin';
    url: string;
};
export type ContractDocument = {
    $contract: string;
    id: string;
    operations: Record<string, unknown>;
    [member: string]: unknown;
};
export type ModuleManifest = {
    $module: '0.1';
    id: string;
    version: string;
    title: LocalizedText;
    description?: LocalizedText;
    icon?: {
        glyph: string;
        hue?: number;
    };
    category?: 'system' | 'productivity' | 'development' | 'data' | 'communication' | 'suite' | 'play' | 'custom';
    host: ModuleHost;
    provides?: ContractDocument[];
    requires?: {
        contract: string;
        operations?: string[];
    }[];
    styles?: string;
    window?: {
        width?: number;
        height?: number;
        minWidth?: number;
        minHeight?: number;
        singleton?: boolean;
        resizable?: boolean;
    };
    settings?: ModuleSettings;
};
/** Where a module's settings live in the desktop's Settings (see the schema's `settings`). */
export type ModuleSettings = {
    title?: LocalizedText;
    keywords?: string[];
} & ({
    kind: 'mount';
    mount: string;
} | {
    kind: 'page';
    url: string;
} | {
    kind: 'form';
    schema: Record<string, unknown>;
});
export type ManifestIssue = {
    code: string;
    path: string;
    message: string;
};
export type ManifestVerdict = {
    ok: true;
    manifest: ModuleManifest;
} | {
    ok: false;
    issues: ManifestIssue[];
};
/**
 * Validate a module manifest. Returns a frozen copy on success, so a caller
 * holding the input cannot change an installed module behind the kernel's
 * back; refusals carry a JSON pointer and a code (`OS0001` shape, `OS0002`
 * host kind, `OS0003` duplicate contract, `OS0004` settings that do not fit
 * the module).
 */
export declare function validateManifest(value: unknown): ManifestVerdict;
/** The text for a locale, falling back to English. */
export declare function localized(text: LocalizedText | undefined, locale: string): string;
